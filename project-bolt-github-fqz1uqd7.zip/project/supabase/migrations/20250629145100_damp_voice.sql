/*
  # Enhanced Scoring System

  1. New Columns
    - `professionalism` (integer) - Score for professional conduct and demeanor
    - `behavioral_appropriateness` (integer) - Score for appropriate behavior during interview
    - `engagement_level` (integer) - Score for candidate engagement and enthusiasm
    - `screen_sharing_quality` (integer) - Score for visual presentations if applicable
    - `presentation_skills` (integer) - Score for overall presentation abilities
    - `response_quality_trend` (text) - Whether responses improved, declined, or remained stable
    - `strengths` (jsonb array) - List of identified strengths
    - `improvements` (jsonb array) - List of areas needing improvement
    - `industry_comparison` (jsonb) - Comparison with industry benchmarks
    - `real_time_scores` (jsonb array) - Time-series scoring data
    - `behavioral_incidents` (jsonb array) - Any notable behavioral incidents
    - `screen_share_analysis` (jsonb array) - Analysis of screen sharing if used

  2. Constraints
    - Add check constraints for score ranges
    - Add check constraints for enum fields

  3. Indexes
    - Add GIN indexes for JSONB fields to optimize queries
    - Add B-Tree indexes for commonly queried score fields
*/

-- Add new columns to scores table
DO $$
BEGIN
  -- Professionalism
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'professionalism'
  ) THEN
    ALTER TABLE scores ADD COLUMN professionalism integer;
  END IF;

  -- Behavioral appropriateness
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'behavioral_appropriateness'
  ) THEN
    ALTER TABLE scores ADD COLUMN behavioral_appropriateness integer;
  END IF;

  -- Engagement level
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'engagement_level'
  ) THEN
    ALTER TABLE scores ADD COLUMN engagement_level integer;
  END IF;

  -- Screen sharing quality
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'screen_sharing_quality'
  ) THEN
    ALTER TABLE scores ADD COLUMN screen_sharing_quality integer;
  END IF;

  -- Presentation skills
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'presentation_skills'
  ) THEN
    ALTER TABLE scores ADD COLUMN presentation_skills integer;
  END IF;

  -- Response quality trend
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'response_quality_trend'
  ) THEN
    ALTER TABLE scores ADD COLUMN response_quality_trend text;
  END IF;

  -- Strengths (jsonb array)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'strengths'
  ) THEN
    ALTER TABLE scores ADD COLUMN strengths jsonb DEFAULT '[]'::jsonb;
  END IF;

  -- Improvements (jsonb array)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'improvements'
  ) THEN
    ALTER TABLE scores ADD COLUMN improvements jsonb DEFAULT '[]'::jsonb;
  END IF;

  -- Industry comparison
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'industry_comparison'
  ) THEN
    ALTER TABLE scores ADD COLUMN industry_comparison jsonb;
  END IF;

  -- Real-time scores
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'real_time_scores'
  ) THEN
    ALTER TABLE scores ADD COLUMN real_time_scores jsonb DEFAULT '[]'::jsonb;
  END IF;

  -- Behavioral incidents
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'behavioral_incidents'
  ) THEN
    ALTER TABLE scores ADD COLUMN behavioral_incidents jsonb DEFAULT '[]'::jsonb;
  END IF;

  -- Screen share analysis
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'screen_share_analysis'
  ) THEN
    ALTER TABLE scores ADD COLUMN screen_share_analysis jsonb DEFAULT '[]'::jsonb;
  END IF;
END $$;

-- Add check constraints for score ranges and enum values
DO $$
BEGIN
  -- Professionalism
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'scores_professionalism_check'
  ) THEN
    ALTER TABLE scores 
    ADD CONSTRAINT scores_professionalism_check 
    CHECK (professionalism BETWEEN 1 AND 10);
  END IF;

  -- Behavioral appropriateness
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'scores_behavioral_appropriateness_check'
  ) THEN
    ALTER TABLE scores 
    ADD CONSTRAINT scores_behavioral_appropriateness_check 
    CHECK (behavioral_appropriateness BETWEEN 1 AND 10);
  END IF;

  -- Engagement level
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'scores_engagement_level_check'
  ) THEN
    ALTER TABLE scores 
    ADD CONSTRAINT scores_engagement_level_check 
    CHECK (engagement_level BETWEEN 1 AND 10);
  END IF;

  -- Screen sharing quality
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'scores_screen_sharing_quality_check'
  ) THEN
    ALTER TABLE scores 
    ADD CONSTRAINT scores_screen_sharing_quality_check 
    CHECK (screen_sharing_quality BETWEEN 1 AND 10);
  END IF;

  -- Presentation skills
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'scores_presentation_skills_check'
  ) THEN
    ALTER TABLE scores 
    ADD CONSTRAINT scores_presentation_skills_check 
    CHECK (presentation_skills BETWEEN 1 AND 10);
  END IF;

  -- Response quality trend (enum-like constraint)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'scores_response_quality_trend_check'
  ) THEN
    ALTER TABLE scores 
    ADD CONSTRAINT scores_response_quality_trend_check 
    CHECK (response_quality_trend = ANY (ARRAY['improving', 'declining', 'stable']));
  END IF;
END $$;

-- Add indexes for new fields
CREATE INDEX IF NOT EXISTS idx_scores_professionalism ON scores(professionalism);
CREATE INDEX IF NOT EXISTS idx_scores_engagement_level ON scores(engagement_level);
CREATE INDEX IF NOT EXISTS idx_scores_response_trend ON scores(response_quality_trend);
CREATE INDEX IF NOT EXISTS idx_scores_real_time_scores_gin ON scores USING gin(real_time_scores);
CREATE INDEX IF NOT EXISTS idx_scores_behavioral_incidents_gin ON scores USING gin(behavioral_incidents);

-- Add optimized index for analytics queries
CREATE INDEX IF NOT EXISTS idx_scores_analytics ON scores(created_at, overall_score, professionalism, engagement_level);