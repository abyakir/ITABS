/*
  # Add additional profile and preference fields

  1. New Tables
    - None (modifying existing tables)
    
  2. Changes to existing tables
    - `user_profiles` table: Add phone_number, timezone, skills, certifications, social links, resume_url
    - `user_preferences` table: Add accessibility and audio/video settings
    
  3. Security
    - Add storage buckets for profile photos and resumes
    - Add RLS policies for file access (with existence checks)
    
  4. Constraints
    - Add validation constraints for new preference fields
*/

-- Add new columns to user_profiles
DO $$
BEGIN
  -- Phone number
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'phone_number'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN phone_number text;
  END IF;

  -- Timezone
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'timezone'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN timezone text;
  END IF;

  -- Skills array
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'skills'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN skills text[] DEFAULT '{}';
  END IF;

  -- Certifications array
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'certifications'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN certifications text[] DEFAULT '{}';
  END IF;

  -- LinkedIn URL
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'linkedin_url'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN linkedin_url text;
  END IF;

  -- GitHub URL
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'github_url'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN github_url text;
  END IF;

  -- Portfolio URL
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'portfolio_url'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN portfolio_url text;
  END IF;

  -- Resume URL
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'resume_url'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN resume_url text;
  END IF;
END $$;

-- Add new columns to user_preferences
DO $$
BEGIN
  -- Font size
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_preferences' AND column_name = 'font_size'
  ) THEN
    ALTER TABLE user_preferences ADD COLUMN font_size text DEFAULT 'medium';
  END IF;

  -- High contrast
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_preferences' AND column_name = 'high_contrast'
  ) THEN
    ALTER TABLE user_preferences ADD COLUMN high_contrast boolean DEFAULT false;
  END IF;

  -- Reduce motion
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_preferences' AND column_name = 'reduce_motion'
  ) THEN
    ALTER TABLE user_preferences ADD COLUMN reduce_motion boolean DEFAULT false;
  END IF;

  -- Live captions
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_preferences' AND column_name = 'live_captions'
  ) THEN
    ALTER TABLE user_preferences ADD COLUMN live_captions boolean DEFAULT false;
  END IF;

  -- Voice ID
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_preferences' AND column_name = 'voice_id'
  ) THEN
    ALTER TABLE user_preferences ADD COLUMN voice_id text DEFAULT '21m00Tcm4TlvDq8ikWAM';
  END IF;

  -- Speech speed
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_preferences' AND column_name = 'speech_speed'
  ) THEN
    ALTER TABLE user_preferences ADD COLUMN speech_speed numeric DEFAULT 1.0;
  END IF;

  -- Microphone sensitivity
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_preferences' AND column_name = 'microphone_sensitivity'
  ) THEN
    ALTER TABLE user_preferences ADD COLUMN microphone_sensitivity integer DEFAULT 75;
  END IF;

  -- Noise cancellation
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_preferences' AND column_name = 'noise_cancellation'
  ) THEN
    ALTER TABLE user_preferences ADD COLUMN noise_cancellation text DEFAULT 'auto';
  END IF;

  -- Video quality
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_preferences' AND column_name = 'video_quality'
  ) THEN
    ALTER TABLE user_preferences ADD COLUMN video_quality text DEFAULT 'auto';
  END IF;

  -- Mirror video
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_preferences' AND column_name = 'mirror_video'
  ) THEN
    ALTER TABLE user_preferences ADD COLUMN mirror_video boolean DEFAULT true;
  END IF;

  -- Date format
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_preferences' AND column_name = 'date_format'
  ) THEN
    ALTER TABLE user_preferences ADD COLUMN date_format text DEFAULT 'US';
  END IF;

  -- Time format
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_preferences' AND column_name = 'time_format'
  ) THEN
    ALTER TABLE user_preferences ADD COLUMN time_format text DEFAULT '12';
  END IF;

  -- Timezone for preferences
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_preferences' AND column_name = 'timezone'
  ) THEN
    ALTER TABLE user_preferences ADD COLUMN timezone text DEFAULT 'auto';
  END IF;
END $$;

-- Add constraints for new preference fields
DO $$
BEGIN
  -- Font size constraint
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'user_preferences_font_size_check'
  ) THEN
    ALTER TABLE user_preferences ADD CONSTRAINT user_preferences_font_size_check 
    CHECK (font_size = ANY (ARRAY['small'::text, 'medium'::text, 'large'::text, 'extra-large'::text]));
  END IF;

  -- Noise cancellation constraint
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'user_preferences_noise_cancellation_check'
  ) THEN
    ALTER TABLE user_preferences ADD CONSTRAINT user_preferences_noise_cancellation_check 
    CHECK (noise_cancellation = ANY (ARRAY['auto'::text, 'high'::text, 'medium'::text, 'low'::text, 'off'::text]));
  END IF;

  -- Video quality constraint
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'user_preferences_video_quality_check'
  ) THEN
    ALTER TABLE user_preferences ADD CONSTRAINT user_preferences_video_quality_check 
    CHECK (video_quality = ANY (ARRAY['auto'::text, 'hd'::text, 'standard'::text, 'low'::text]));
  END IF;

  -- Date format constraint
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'user_preferences_date_format_check'
  ) THEN
    ALTER TABLE user_preferences ADD CONSTRAINT user_preferences_date_format_check 
    CHECK (date_format = ANY (ARRAY['US'::text, 'UK'::text, 'ISO'::text, 'DE'::text]));
  END IF;

  -- Time format constraint
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'user_preferences_time_format_check'
  ) THEN
    ALTER TABLE user_preferences ADD CONSTRAINT user_preferences_time_format_check 
    CHECK (time_format = ANY (ARRAY['12'::text, '24'::text]));
  END IF;

  -- Microphone sensitivity constraint
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'user_preferences_microphone_sensitivity_check'
  ) THEN
    ALTER TABLE user_preferences ADD CONSTRAINT user_preferences_microphone_sensitivity_check 
    CHECK ((microphone_sensitivity >= 0) AND (microphone_sensitivity <= 100));
  END IF;

  -- Speech speed constraint
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'user_preferences_speech_speed_check'
  ) THEN
    ALTER TABLE user_preferences ADD CONSTRAINT user_preferences_speech_speed_check 
    CHECK ((speech_speed >= 0.5) AND (speech_speed <= 2.0));
  END IF;
END $$;

-- Create storage buckets if they don't exist
INSERT INTO storage.buckets (id, name, public)
VALUES 
  ('profile-photos', 'profile-photos', true),
  ('resumes', 'resumes', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for profile photos (with existence checks)
DO $$
BEGIN
  -- Profile photos upload policy
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Users can upload own profile photos'
  ) THEN
    CREATE POLICY "Users can upload own profile photos" ON storage.objects
    FOR INSERT TO authenticated
    WITH CHECK (bucket_id = 'profile-photos' AND auth.uid()::text = (storage.foldername(name))[1]);
  END IF;

  -- Profile photos view policy
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Users can view own profile photos'
  ) THEN
    CREATE POLICY "Users can view own profile photos" ON storage.objects
    FOR SELECT TO authenticated
    USING (bucket_id = 'profile-photos' AND auth.uid()::text = (storage.foldername(name))[1]);
  END IF;

  -- Profile photos update policy
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Users can update own profile photos'
  ) THEN
    CREATE POLICY "Users can update own profile photos" ON storage.objects
    FOR UPDATE TO authenticated
    USING (bucket_id = 'profile-photos' AND auth.uid()::text = (storage.foldername(name))[1]);
  END IF;

  -- Profile photos delete policy
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Users can delete own profile photos'
  ) THEN
    CREATE POLICY "Users can delete own profile photos" ON storage.objects
    FOR DELETE TO authenticated
    USING (bucket_id = 'profile-photos' AND auth.uid()::text = (storage.foldername(name))[1]);
  END IF;

  -- Resumes upload policy
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Users can upload own resumes'
  ) THEN
    CREATE POLICY "Users can upload own resumes" ON storage.objects
    FOR INSERT TO authenticated
    WITH CHECK (bucket_id = 'resumes' AND auth.uid()::text = (storage.foldername(name))[1]);
  END IF;

  -- Resumes view policy
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Users can view own resumes'
  ) THEN
    CREATE POLICY "Users can view own resumes" ON storage.objects
    FOR SELECT TO authenticated
    USING (bucket_id = 'resumes' AND auth.uid()::text = (storage.foldername(name))[1]);
  END IF;

  -- Resumes update policy
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Users can update own resumes'
  ) THEN
    CREATE POLICY "Users can update own resumes" ON storage.objects
    FOR UPDATE TO authenticated
    USING (bucket_id = 'resumes' AND auth.uid()::text = (storage.foldername(name))[1]);
  END IF;

  -- Resumes delete policy
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Users can delete own resumes'
  ) THEN
    CREATE POLICY "Users can delete own resumes" ON storage.objects
    FOR DELETE TO authenticated
    USING (bucket_id = 'resumes' AND auth.uid()::text = (storage.foldername(name))[1]);
  END IF;
END $$;