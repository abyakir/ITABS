/*
  # Add missing columns to interviews table

  1. Changes to existing tables
    - `interviews` table: Add missing columns that are referenced in the TypeScript interface
    
  2. New columns to add:
    - experience_level: Entry, mid, or senior level
    - industry: Industry type
    - custom_questions: Array of custom questions
    - focus_areas: Array of focus areas
    - interview_phase: Current phase of the interview
    
  3. Security
    - Maintain existing RLS policies
*/

-- Add missing columns to interviews table
DO $$
BEGIN
  -- Experience level
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'interviews' AND column_name = 'experience_level'
  ) THEN
    ALTER TABLE interviews ADD COLUMN experience_level text DEFAULT 'mid';
  END IF;

  -- Industry
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'interviews' AND column_name = 'industry'
  ) THEN
    ALTER TABLE interviews ADD COLUMN industry text;
  END IF;

  -- Custom questions array
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'interviews' AND column_name = 'custom_questions'
  ) THEN
    ALTER TABLE interviews ADD COLUMN custom_questions text[] DEFAULT '{}';
  END IF;

  -- Focus areas array
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'interviews' AND column_name = 'focus_areas'
  ) THEN
    ALTER TABLE interviews ADD COLUMN focus_areas text[] DEFAULT '{}';
  END IF;

  -- Interview phase
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'interviews' AND column_name = 'interview_phase'
  ) THEN
    ALTER TABLE interviews ADD COLUMN interview_phase text DEFAULT 'opening';
  END IF;
END $$;

-- Add constraints for new fields
DO $$
BEGIN
  -- Experience level constraint
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'interviews_experience_level_check'
  ) THEN
    ALTER TABLE interviews ADD CONSTRAINT interviews_experience_level_check 
    CHECK (experience_level = ANY (ARRAY['entry'::text, 'mid'::text, 'senior'::text]));
  END IF;

  -- Interview phase constraint
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'interviews_interview_phase_check'
  ) THEN
    ALTER TABLE interviews ADD CONSTRAINT interviews_interview_phase_check 
    CHECK (interview_phase = ANY (ARRAY['opening'::text, 'background'::text, 'experience'::text, 'skills'::text, 'motivation'::text, 'closing'::text]));
  END IF;
END $$;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_interviews_experience_level ON interviews(experience_level);
CREATE INDEX IF NOT EXISTS idx_interviews_industry ON interviews(industry);
CREATE INDEX IF NOT EXISTS idx_interviews_interview_phase ON interviews(interview_phase);

-- Add comments for documentation
COMMENT ON COLUMN interviews.experience_level IS 'Experience level: entry, mid, or senior';
COMMENT ON COLUMN interviews.industry IS 'Industry or field of work';
COMMENT ON COLUMN interviews.custom_questions IS 'Array of custom questions for the interview';
COMMENT ON COLUMN interviews.focus_areas IS 'Array of focus areas for the interview';
COMMENT ON COLUMN interviews.interview_phase IS 'Current phase of the interview process';
