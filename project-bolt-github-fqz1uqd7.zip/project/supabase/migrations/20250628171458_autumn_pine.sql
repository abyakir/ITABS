/*
  --------------------------------------------------------------------
  # Enhance Database Integration
  --------------------------------------------------------------------
  1. PERFORMANCE & INTEGRITY
     • Add/refresh helpful indexes  
     • Add / verify FK-CASCADE rules  
     • Views for analytics  
 2. SECURITY
     • Consistent RLS on messages  
     • Policies for SELECT / INSERT  
 3. MAINTENANCE
     • Generic updated_at trigger + function  
     • Descriptive COMMENTs  
  --------------------------------------------------------------------
*/

/*─────────────────────────────────────────────────────────────────────*
 * 1 A. INDEXES                                                        *
 *─────────────────────────────────────────────────────────────────────*/
-- interviews
CREATE INDEX IF NOT EXISTS idx_interviews_user_id               ON public.interviews(user_id);
CREATE INDEX IF NOT EXISTS idx_interviews_status_created_at     ON public.interviews(status, created_at);
CREATE INDEX IF NOT EXISTS idx_interviews_user_id_status        ON public.interviews(user_id, status);
CREATE INDEX IF NOT EXISTS idx_interviews_custom_questions_gin  ON public.interviews USING gin(custom_questions);
CREATE INDEX IF NOT EXISTS idx_interviews_focus_areas_gin       ON public.interviews USING gin(focus_areas);

-- messages
CREATE INDEX IF NOT EXISTS idx_messages_interview_id_created_at ON public.messages(interview_id, created_at);
CREATE INDEX IF NOT EXISTS idx_messages_role                    ON public.messages(role);

-- scores
CREATE INDEX IF NOT EXISTS idx_scores_overall_score             ON public.scores(overall_score);
CREATE INDEX IF NOT EXISTS idx_scores_created_at                ON public.scores(created_at);
CREATE INDEX IF NOT EXISTS idx_scores_real_time_scores_gin      ON public.scores USING gin(real_time_scores);
CREATE INDEX IF NOT EXISTS idx_scores_behavioral_incidents_gin  ON public.scores USING gin(behavioral_incidents);

-- user_profiles
CREATE INDEX IF NOT EXISTS idx_user_profiles_created_at         ON public.user_profiles(created_at);
CREATE INDEX IF NOT EXISTS idx_user_profiles_onboarding_completed
                                                                ON public.user_profiles(onboarding_completed);

/*─────────────────────────────────────────────────────────────────────*
 * 1 B. FK WITH ON DELETE CASCADE                                      *
 *─────────────────────────────────────────────────────────────────────*/
DO
$$
BEGIN
  IF NOT EXISTS (
      SELECT 1 FROM pg_constraint
      WHERE conname = 'interviews_user_id_fkey'
        AND contype = 'f'
        AND confdeltype = 'c'   -- c = CASCADE
  ) THEN
    -- Drop old FK (if any)
    IF EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'interviews_user_id_fkey') THEN
      ALTER TABLE public.interviews
        DROP CONSTRAINT interviews_user_id_fkey;
    END IF;

    -- Re-create with proper CASCADE
    ALTER TABLE public.interviews
      ADD CONSTRAINT interviews_user_id_fkey
      FOREIGN KEY (user_id)
      REFERENCES auth.users(id)
      ON DELETE CASCADE;
  END IF;
END;
$$;

/*─────────────────────────────────────────────────────────────────────*
 * 1 C. ANALYTICS VIEWS                                               *
 *─────────────────────────────────────────────────────────────────────*/
CREATE OR REPLACE VIEW interview_performance_stats AS
SELECT
  DATE_TRUNC('day', created_at)                                     AS date,
  COUNT(*)                                                          AS total_interviews,
  COUNT(*) FILTER (WHERE status = 'completed')                      AS completed_interviews,
  AVG(duration_minutes)                                             AS avg_duration,
  COUNT(*) FILTER (WHERE status = 'in_progress')                    AS active_interviews
FROM public.interviews
GROUP BY 1
ORDER BY 1 DESC;

CREATE OR REPLACE VIEW user_engagement_stats AS
SELECT
  u.id                                                              AS user_id,
  COUNT(i.*)                                                        AS total_interviews,
  AVG(s.overall_score)                                              AS avg_score,
  MAX(i.created_at)                                                 AS last_interview,
  COUNT(*) FILTER (WHERE i.status = 'completed')                    AS completed_count
FROM public.user_profiles u
LEFT JOIN public.interviews i ON i.user_id = u.id
LEFT JOIN public.scores     s ON s.interview_id = i.id
GROUP BY u.id;

/*─────────────────────────────────────────────────────────────────────*
 * 2. ROW-LEVEL SECURITY ON MESSAGES                                  *
 *─────────────────────────────────────────────────────────────────────*/
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can read messages from own interviews"  ON public.messages;
CREATE POLICY "Users can read messages from own interviews"
  ON public.messages
  FOR SELECT
  TO authenticated
  USING (
    interview_id IN (SELECT id FROM public.interviews WHERE user_id = auth.uid())
  );

DROP POLICY IF EXISTS "Users can create messages for own interviews" ON public.messages;
CREATE POLICY "Users can create messages for own interviews"
  ON public.messages
  FOR INSERT
  TO authenticated
  WITH CHECK (
    interview_id IN (SELECT id FROM public.interviews WHERE user_id = auth.uid())
  );

/*─────────────────────────────────────────────────────────────────────*
 * 3 A. updated_at AUTO-STAMP FUNCTION                                *
 *─────────────────────────────────────────────────────────────────────*/
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $func$
BEGIN
  NEW.updated_at := NOW();
  RETURN NEW;
END
$func$;

/*─────────────────────────────────────────────────────────────────────*
 * 3 B. Attach trigger to any table that has updated_at               *
 *─────────────────────────────────────────────────────────────────────*/
DO
$$
DECLARE
  tbl  text;
BEGIN
  FOR tbl IN
    SELECT format('%I.%I', table_schema, table_name)
    FROM information_schema.columns
    WHERE column_name = 'updated_at'
      AND table_schema = 'public'
  LOOP
    -- Skip if trigger already exists
    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger
        WHERE tgrelid = (tbl)::regclass
          AND tgname  = format('set_%I_updated_at', (tbl::text)::regclass)
    ) THEN
      EXECUTE format(
        'CREATE TRIGGER set_%I_updated_at
           BEFORE UPDATE ON %s
           FOR EACH ROW
           EXECUTE FUNCTION update_updated_at_column();',
        (tbl::text)::regclass, tbl
      );
    END IF;
  END LOOP;
END;
$$;

/*─────────────────────────────────────────────────────────────────────*
 * 4. COMMENTS                                        (doc-as-code)   *
 *─────────────────────────────────────────────────────────────────────*/
COMMENT ON TABLE  public.interviews        IS 'Interview sessions with metadata and config';
COMMENT ON TABLE  public.messages          IS 'Conversation history between user and AI interviewer';
COMMENT ON TABLE  public.scores            IS 'Scoring and feedback for completed interviews';
COMMENT ON TABLE  public.user_profiles     IS 'Extended user information beyond auth.users';
COMMENT ON TABLE  public.user_preferences  IS 'Per-user application preferences';
COMMENT ON TABLE  public.user_sessions     IS 'Session activity and verification tracking';

COMMENT ON INDEX public.idx_interviews_user_id              IS 'Filter by user_id';
COMMENT ON INDEX public.idx_interviews_status_created_at     IS 'Filter by status & date';
COMMENT ON INDEX public.idx_interviews_user_id_status        IS 'User-specific status filter';
COMMENT ON INDEX public.idx_messages_interview_id_created_at IS 'Retrieve messages chronologically';
