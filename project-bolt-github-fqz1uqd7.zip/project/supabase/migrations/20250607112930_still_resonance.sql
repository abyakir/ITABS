/*
  Interview AI Schema Setup

  1. New Tables
    - interviews: Store interview session data
    - messages: Store conversation history between user and AI
    - scores: Store evaluation results and feedback

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to access their own data
    - Add storage buckets for audio files and resumes
*/

-- Create interviews table
CREATE TABLE IF NOT EXISTS interviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  job_title text NOT NULL,
  company text NOT NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'cancelled')),
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  duration_minutes integer DEFAULT 0
);

-- Create messages table
CREATE TABLE IF NOT EXISTS messages (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  interview_id uuid REFERENCES interviews(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user', 'ai')),
  content text NOT NULL,
  audio_url text,
  created_at timestamptz DEFAULT now()
);

-- Create scores table
CREATE TABLE IF NOT EXISTS scores (
  interview_id uuid PRIMARY KEY REFERENCES interviews(id) ON DELETE CASCADE,
  clarity integer CHECK (clarity BETWEEN 1 AND 10),
  confidence integer CHECK (confidence BETWEEN 1 AND 10),
  relevance integer CHECK (relevance BETWEEN 1 AND 10),
  communication integer CHECK (communication BETWEEN 1 AND 10),
  technical_skills integer CHECK (technical_skills BETWEEN 1 AND 10),
  overall_score integer CHECK (overall_score BETWEEN 1 AND 10),
  summary text,
  recommendations text,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE interviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE scores ENABLE ROW LEVEL SECURITY;

-- Create policies for interviews
CREATE POLICY "Users can read own interviews"
  ON interviews
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own interviews"
  ON interviews
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own interviews"
  ON interviews
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create policies for messages
CREATE POLICY "Users can read messages from own interviews"
  ON messages
  FOR SELECT
  TO authenticated
  USING (
    interview_id IN (
      SELECT id FROM interviews WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create messages for own interviews"
  ON messages
  FOR INSERT
  TO authenticated
  WITH CHECK (
    interview_id IN (
      SELECT id FROM interviews WHERE user_id = auth.uid()
    )
  );

-- Create policies for scores
CREATE POLICY "Users can read scores from own interviews"
  ON scores
  FOR SELECT
  TO authenticated
  USING (
    interview_id IN (
      SELECT id FROM interviews WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create scores for own interviews"
  ON scores
  FOR INSERT
  TO authenticated
  WITH CHECK (
    interview_id IN (
      SELECT id FROM interviews WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update scores for own interviews"
  ON scores
  FOR UPDATE
  TO authenticated
  USING (
    interview_id IN (
      SELECT id FROM interviews WHERE user_id = auth.uid()
    )
  );

-- Create storage buckets
INSERT INTO storage.buckets (id, name, public) 
VALUES ('audio-files', 'audio-files', false)
ON CONFLICT (id) DO NOTHING;

INSERT INTO storage.buckets (id, name, public) 
VALUES ('resumes', 'resumes', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for audio files
CREATE POLICY "Users can upload their own audio files"
  ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'audio-files' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can read their own audio files"
  ON storage.objects
  FOR SELECT
  TO authenticated
  USING (bucket_id = 'audio-files' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Storage policies for resumes
CREATE POLICY "Users can upload their own resumes"
  ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'resumes' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can read their own resumes"
  ON storage.objects
  FOR SELECT
  TO authenticated
  USING (bucket_id = 'resumes' AND auth.uid()::text = (storage.foldername(name))[1]);