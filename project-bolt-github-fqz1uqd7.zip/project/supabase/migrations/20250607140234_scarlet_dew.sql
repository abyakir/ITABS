/*
  # Fix user signup trigger

  This migration fixes the handle_new_user trigger function that creates
  user profiles when new users sign up through Supabase Auth.

  ## Changes
  1. Create/update the handle_new_user function
  2. Ensure the trigger is properly configured
  3. Handle nullable fields correctly
  4. Set proper default values for required fields

  ## Security
  - Function runs with security definer privileges
  - Only creates profiles for authenticated users
*/

-- Create or replace the handle_new_user function
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.user_profiles (
    id,
    first_name,
    last_name,
    location,
    country,
    referral_source,
    professional_experience,
    profile_photo_url,
    onboarding_completed,
    created_at,
    updated_at
  )
  VALUES (
    NEW.id,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    FALSE,
    NOW(),
    NOW()
  );
  
  -- Also create default user preferences
  INSERT INTO public.user_preferences (
    user_id,
    email_notifications,
    interview_reminders,
    performance_insights,
    camera_verification_enabled,
    face_detection_enabled,
    privacy_mode,
    theme_preference,
    language,
    created_at,
    updated_at
  )
  VALUES (
    NEW.id,
    TRUE,
    TRUE,
    TRUE,
    TRUE,
    TRUE,
    'standard',
    'light',
    'en',
    NOW(),
    NOW()
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop the trigger if it exists and recreate it
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Create the trigger on the auth.users table
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Ensure the function has proper permissions
GRANT EXECUTE ON FUNCTION handle_new_user() TO authenticated;
GRANT EXECUTE ON FUNCTION handle_new_user() TO service_role;