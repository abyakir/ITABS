/*
  # Add improved indexing and debugging for user profiles

  1. New Indices
    - `idx_user_profiles_id` - Optimizes lookup by user ID
    - `idx_user_profiles_created_updated` - Helps track creation/update times

  2. SQL Functions
    - Add a function to log profile creation and updates
*/

-- Add improved indices
CREATE INDEX IF NOT EXISTS idx_user_profiles_id ON public.user_profiles(id);
CREATE INDEX IF NOT EXISTS idx_user_profiles_created_updated ON public.user_profiles(created_at, updated_at);

-- Add logging function for debugging
CREATE OR REPLACE FUNCTION log_profile_changes()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    RAISE NOTICE 'Created profile for user: %, Data: %', NEW.id, row_to_json(NEW);
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    RAISE NOTICE 'Updated profile for user: %, Data: %', NEW.id, row_to_json(NEW);
    RETURN NEW;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Add trigger to log profile changes
DROP TRIGGER IF EXISTS log_profile_changes_trigger ON public.user_profiles;
CREATE TRIGGER log_profile_changes_trigger
AFTER INSERT OR UPDATE ON public.user_profiles
FOR EACH ROW
EXECUTE FUNCTION log_profile_changes();