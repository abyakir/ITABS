/*
  # Enhance scores table for ElevenLabs integration
  
  1. Add missing columns to scores table to match TypeScript interface
  2. Add columns for enhanced scoring categories
  3. Add JSON columns for complex data structures
  4. Maintain backward compatibility
  
  ## New Columns
  - professionalism: integer (1-10)
  - behavioral_appropriateness: integer (1-10) 
  - engagement_level: integer (1-10)
  - screen_sharing_quality: integer (1-10, nullable)
  - presentation_skills: integer (1-10, nullable)
  - response_quality_trend: text enum
  - strengths: jsonb array
  - improvements: jsonb array
  - industry_comparison: jsonb object
  - real_time_scores: jsonb array
  - behavioral_incidents: jsonb array
  - screen_share_analysis: jsonb array
*/

-- Add enhanced scoring columns to scores table
DO $$
BEGIN
  -- Professionalism score
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'professionalism'
  ) THEN
    ALTER TABLE scores ADD COLUMN professionalism integer CHECK (professionalism BETWEEN 1 AND 10);
  END IF;

  -- Behavioral appropriateness score
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'behavioral_appropriateness'
  ) THEN
    ALTER TABLE scores ADD COLUMN behavioral_appropriateness integer CHECK (behavioral_appropriateness BETWEEN 1 AND 10);
  END IF;

  -- Engagement level score
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'engagement_level'
  ) THEN
    ALTER TABLE scores ADD COLUMN engagement_level integer CHECK (engagement_level BETWEEN 1 AND 10);
  END IF;

  -- Screen sharing quality (optional)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'screen_sharing_quality'
  ) THEN
    ALTER TABLE scores ADD COLUMN screen_sharing_quality integer CHECK (screen_sharing_quality BETWEEN 1 AND 10);
  END IF;

  -- Presentation skills (optional)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'presentation_skills'
  ) THEN
    ALTER TABLE scores ADD COLUMN presentation_skills integer CHECK (presentation_skills BETWEEN 1 AND 10);
  END IF;

  -- Response quality trend
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'response_quality_trend'
  ) THEN
    ALTER TABLE scores ADD COLUMN response_quality_trend text CHECK (response_quality_trend IN ('improving', 'declining', 'stable'));
  END IF;

  -- Strengths array
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'strengths'
  ) THEN
    ALTER TABLE scores ADD COLUMN strengths jsonb DEFAULT '[]'::jsonb;
  END IF;

  -- Improvements array
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'improvements'
  ) THEN
    ALTER TABLE scores ADD COLUMN improvements jsonb DEFAULT '[]'::jsonb;
  END IF;

  -- Industry comparison object
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'industry_comparison'
  ) THEN
    ALTER TABLE scores ADD COLUMN industry_comparison jsonb;
  END IF;

  -- Real-time scores array
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'real_time_scores'
  ) THEN
    ALTER TABLE scores ADD COLUMN real_time_scores jsonb DEFAULT '[]'::jsonb;
  END IF;

  -- Behavioral incidents array
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'behavioral_incidents'
  ) THEN
    ALTER TABLE scores ADD COLUMN behavioral_incidents jsonb DEFAULT '[]'::jsonb;
  END IF;

  -- Screen share analysis array
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scores' AND column_name = 'screen_share_analysis'
  ) THEN
    ALTER TABLE scores ADD COLUMN screen_share_analysis jsonb DEFAULT '[]'::jsonb;
  END IF;
END $$;

-- Add indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_scores_professionalism ON scores(professionalism);
CREATE INDEX IF NOT EXISTS idx_scores_engagement_level ON scores(engagement_level);
CREATE INDEX IF NOT EXISTS idx_scores_response_trend ON scores(response_quality_trend);

-- Add index for real-time scores JSON queries
CREATE INDEX IF NOT EXISTS idx_scores_real_time_scores_gin ON scores USING gin(real_time_scores);
