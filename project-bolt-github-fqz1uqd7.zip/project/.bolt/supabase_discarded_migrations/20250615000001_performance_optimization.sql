/*
  # Performance Optimization for ElevenLabs Interview System
  
  1. Add database indexes for frequently queried columns
  2. Optimize query performance for interview workflow
  3. Add composite indexes for complex queries
  4. Optimize real-time subscription performance
  
  ## Indexes Added
  - interviews: user_id, status, created_at combinations
  - messages: interview_id, created_at for chronological ordering
  - scores: interview_id for quick lookups
  - user_sessions: user_id, ended_at for active session queries
  - user_preferences: user_id for settings retrieval
*/

-- Interviews table indexes
CREATE INDEX IF NOT EXISTS idx_interviews_user_id_status 
  ON interviews(user_id, status);

CREATE INDEX IF NOT EXISTS idx_interviews_user_id_created_at 
  ON interviews(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_interviews_status_created_at 
  ON interviews(status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_interviews_user_status_created 
  ON interviews(user_id, status, created_at DESC);

-- Messages table indexes for real-time performance
CREATE INDEX IF NOT EXISTS idx_messages_interview_id_created_at 
  ON messages(interview_id, created_at ASC);

CREATE INDEX IF NOT EXISTS idx_messages_interview_role_created 
  ON messages(interview_id, role, created_at ASC);

-- Optimize message retrieval for conversations
CREATE INDEX IF NOT EXISTS idx_messages_created_at_desc 
  ON messages(created_at DESC);

-- Scores table indexes
CREATE INDEX IF NOT EXISTS idx_scores_interview_id 
  ON scores(interview_id);

CREATE INDEX IF NOT EXISTS idx_scores_overall_score 
  ON scores(overall_score);

CREATE INDEX IF NOT EXISTS idx_scores_created_at 
  ON scores(created_at DESC);

-- User sessions indexes for active session queries
CREATE INDEX IF NOT EXISTS idx_user_sessions_user_id_ended_at 
  ON user_sessions(user_id, ended_at);

CREATE INDEX IF NOT EXISTS idx_user_sessions_user_id_started_at 
  ON user_sessions(user_id, started_at DESC);

CREATE INDEX IF NOT EXISTS idx_user_sessions_session_type 
  ON user_sessions(session_type);

-- User preferences indexes
CREATE INDEX IF NOT EXISTS idx_user_preferences_user_id 
  ON user_preferences(user_id);

-- User profiles indexes
CREATE INDEX IF NOT EXISTS idx_user_profiles_created_at 
  ON user_profiles(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_user_profiles_onboarding_completed 
  ON user_profiles(onboarding_completed);

-- Composite indexes for complex queries
CREATE INDEX IF NOT EXISTS idx_interviews_user_status_experience 
  ON interviews(user_id, status, experience_level);

-- Partial indexes for active sessions (more efficient)
CREATE INDEX IF NOT EXISTS idx_user_sessions_active 
  ON user_sessions(user_id, started_at DESC) 
  WHERE ended_at IS NULL;

-- Partial indexes for completed interviews
CREATE INDEX IF NOT EXISTS idx_interviews_completed 
  ON interviews(user_id, completed_at DESC) 
  WHERE status = 'completed';

-- GIN indexes for JSON columns (if using PostgreSQL features)
CREATE INDEX IF NOT EXISTS idx_interviews_custom_questions_gin 
  ON interviews USING gin(custom_questions);

CREATE INDEX IF NOT EXISTS idx_interviews_focus_areas_gin 
  ON interviews USING gin(focus_areas);

CREATE INDEX IF NOT EXISTS idx_user_sessions_verification_gin 
  ON user_sessions USING gin(verification_screenshots);

-- Optimize for real-time subscriptions
CREATE INDEX IF NOT EXISTS idx_messages_realtime 
  ON messages(interview_id, id, created_at);

-- Statistics and analytics indexes
CREATE INDEX IF NOT EXISTS idx_scores_analytics 
  ON scores(created_at, overall_score, professionalism, engagement_level);

-- Performance monitoring views
CREATE OR REPLACE VIEW interview_performance_stats AS
SELECT 
  DATE_TRUNC('day', created_at) as date,
  COUNT(*) as total_interviews,
  COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_interviews,
  AVG(duration_minutes) as avg_duration,
  COUNT(CASE WHEN status = 'in_progress' THEN 1 END) as active_interviews
FROM interviews 
GROUP BY DATE_TRUNC('day', created_at)
ORDER BY date DESC;

CREATE OR REPLACE VIEW user_engagement_stats AS
SELECT 
  u.id as user_id,
  COUNT(i.id) as total_interviews,
  AVG(s.overall_score) as avg_score,
  MAX(i.created_at) as last_interview,
  COUNT(CASE WHEN i.status = 'completed' THEN 1 END) as completed_count
FROM user_profiles u
LEFT JOIN interviews i ON u.id = i.user_id
LEFT JOIN scores s ON i.id = s.interview_id
GROUP BY u.id;

-- Query optimization hints (PostgreSQL specific)
-- Enable parallel query execution for large datasets
ALTER TABLE interviews SET (parallel_workers = 4);
ALTER TABLE messages SET (parallel_workers = 4);
ALTER TABLE scores SET (parallel_workers = 2);

-- Update table statistics for better query planning
ANALYZE interviews;
ANALYZE messages;
ANALYZE scores;
ANALYZE user_sessions;
ANALYZE user_preferences;
ANALYZE user_profiles;

-- Add comments for documentation
COMMENT ON INDEX idx_interviews_user_id_status IS 'Optimizes user interview listing by status';
COMMENT ON INDEX idx_messages_interview_id_created_at IS 'Optimizes message retrieval for conversations';
COMMENT ON INDEX idx_user_sessions_active IS 'Optimizes active session queries';
COMMENT ON INDEX idx_scores_analytics IS 'Optimizes scoring analytics and reporting';

-- Performance monitoring function
CREATE OR REPLACE FUNCTION get_query_performance_stats()
RETURNS TABLE(
  query_type text,
  avg_execution_time_ms numeric,
  total_calls bigint,
  cache_hit_ratio numeric
) AS $$
BEGIN
  -- This would integrate with pg_stat_statements if available
  -- For now, return placeholder data
  RETURN QUERY
  SELECT
    'interview_queries'::text,
    15.5::numeric,
    1000::bigint,
    0.95::numeric;
END;
$$ LANGUAGE plpgsql;

-- Function to check index usage
CREATE OR REPLACE FUNCTION check_index_usage()
RETURNS TABLE(
  table_name text,
  index_name text,
  index_scans bigint,
  tuples_read bigint,
  tuples_fetched bigint
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    schemaname || '.' || tablename as table_name,
    indexname as index_name,
    idx_scan as index_scans,
    idx_tup_read as tuples_read,
    idx_tup_fetch as tuples_fetched
  FROM pg_stat_user_indexes
  WHERE schemaname = 'public'
  ORDER BY idx_scan DESC;
END;
$$ LANGUAGE plpgsql;
