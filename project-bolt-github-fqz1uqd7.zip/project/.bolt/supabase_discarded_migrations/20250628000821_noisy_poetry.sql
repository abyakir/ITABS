/*
  # Create Storage Policies for Profile Photos

  1. New Buckets
    - `profile-photos` - For user profile pictures
    - `resumes` - For user resume files
    - `audio-files` - For interview audio recordings

  2. Security
    - Enable RLS on all buckets
    - Add policies allowing users to access only their own files
    - Set public access for profile photos
*/

-- Enable storage extension if not already enabled
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";

-- Create buckets if they don't exist
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name, public)
  VALUES ('profile-photos', 'profile-photos', true)
  ON CONFLICT (id) DO NOTHING;

  INSERT INTO storage.buckets (id, name, public)
  VALUES ('resumes', 'resumes', false)
  ON CONFLICT (id) DO NOTHING;
  
  INSERT INTO storage.buckets (id, name, public)
  VALUES ('audio-files', 'audio-files', false)
  ON CONFLICT (id) DO NOTHING;
END $$;

-- Add profile photos policies
DO $$
BEGIN
  -- User upload policy for profile photos
  INSERT INTO storage.policies (name, bucket_id, definition)
  VALUES (
    'Users can upload own profile photos',
    'profile-photos',
    jsonb_build_object(
      'resource', 'object',
      'action', 'insert',
      'subject', 'authenticated',
      'expression', 'storage.foldername(name)[1] = auth.uid()'
    )
  )
  ON CONFLICT (bucket_id, name) DO NOTHING;

  -- User update policy for profile photos
  INSERT INTO storage.policies (name, bucket_id, definition)
  VALUES (
    'Users can update own profile photos',
    'profile-photos',
    jsonb_build_object(
      'resource', 'object',
      'action', 'update',
      'subject', 'authenticated',
      'expression', 'storage.foldername(name)[1] = auth.uid()'
    )
  )
  ON CONFLICT (bucket_id, name) DO NOTHING;
  
  -- User read policy for profile photos
  INSERT INTO storage.policies (name, bucket_id, definition)
  VALUES (
    'Users can read own profile photos',
    'profile-photos',
    jsonb_build_object(
      'resource', 'object',
      'action', 'select',
      'subject', 'authenticated',
      'expression', 'storage.foldername(name)[1] = auth.uid()'
    )
  )
  ON CONFLICT (bucket_id, name) DO NOTHING;
  
  -- Public read access for profile photos
  INSERT INTO storage.policies (name, bucket_id, definition)
  VALUES (
    'Public read access for profile photos',
    'profile-photos',
    jsonb_build_object(
      'resource', 'object',
      'action', 'select',
      'subject', 'anonymous',
      'expression', 'true'
    )
  )
  ON CONFLICT (bucket_id, name) DO NOTHING;
  
  -- User delete policy for profile photos
  INSERT INTO storage.policies (name, bucket_id, definition)
  VALUES (
    'Users can delete own profile photos',
    'profile-photos',
    jsonb_build_object(
      'resource', 'object',
      'action', 'delete',
      'subject', 'authenticated',
      'expression', 'storage.foldername(name)[1] = auth.uid()'
    )
  )
  ON CONFLICT (bucket_id, name) DO NOTHING;
END $$;

-- Add resume policies
DO $$
BEGIN
  -- User upload policy for resumes
  INSERT INTO storage.policies (name, bucket_id, definition)
  VALUES (
    'Users can upload own resumes',
    'resumes',
    jsonb_build_object(
      'resource', 'object',
      'action', 'insert',
      'subject', 'authenticated',
      'expression', 'storage.foldername(name)[1] = auth.uid()'
    )
  )
  ON CONFLICT (bucket_id, name) DO NOTHING;

  -- User read policy for resumes
  INSERT INTO storage.policies (name, bucket_id, definition)
  VALUES (
    'Users can read own resumes',
    'resumes',
    jsonb_build_object(
      'resource', 'object',
      'action', 'select',
      'subject', 'authenticated',
      'expression', 'storage.foldername(name)[1] = auth.uid()'
    )
  )
  ON CONFLICT (bucket_id, name) DO NOTHING;

  -- User delete policy for resumes
  INSERT INTO storage.policies (name, bucket_id, definition)
  VALUES (
    'Users can delete own resumes',
    'resumes',
    jsonb_build_object(
      'resource', 'object',
      'action', 'delete',
      'subject', 'authenticated',
      'expression', 'storage.foldername(name)[1] = auth.uid()'
    )
  )
  ON CONFLICT (bucket_id, name) DO NOTHING;
END $$;

-- Add audio files policies
DO $$
BEGIN
  -- User upload policy for audio files
  INSERT INTO storage.policies (name, bucket_id, definition)
  VALUES (
    'Users can upload own audio files',
    'audio-files',
    jsonb_build_object(
      'resource', 'object',
      'action', 'insert',
      'subject', 'authenticated',
      'expression', 'storage.foldername(name)[1] = auth.uid()'
    )
  )
  ON CONFLICT (bucket_id, name) DO NOTHING;

  -- User read policy for audio files
  INSERT INTO storage.policies (name, bucket_id, definition)
  VALUES (
    'Users can read own audio files',
    'audio-files',
    jsonb_build_object(
      'resource', 'object',
      'action', 'select',
      'subject', 'authenticated',
      'expression', 'storage.foldername(name)[1] = auth.uid()'
    )
  )
  ON CONFLICT (bucket_id, name) DO NOTHING;

  -- User delete policy for audio files
  INSERT INTO storage.policies (name, bucket_id, definition)
  VALUES (
    'Users can delete own audio files',
    'audio-files',
    jsonb_build_object(
      'resource', 'object',
      'action', 'delete',
      'subject', 'authenticated',
      'expression', 'storage.foldername(name)[1] = auth.uid()'
    )
  )
  ON CONFLICT (bucket_id, name) DO NOTHING;
END $$;