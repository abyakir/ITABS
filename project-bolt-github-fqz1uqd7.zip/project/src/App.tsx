import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Brain } from 'lucide-react';

// Import screens
import { Home } from './screens/Home';
import { Login } from './screens/Login';
import { Signup } from './screens/Signup';
import { ElevenLabsJobInterview } from './screens/ElevenLabsJobInterview';
import { ForgotPassword } from './screens/ForgotPassword';
import { ResetPassword } from './screens/ResetPassword';
import { Setup } from './screens/Setup';
import { ElevenLabsInterviewScreen } from './screens/ElevenLabsInterviewScreen';
import { Results } from './screens/Results';
import { Profile } from './screens/Profile';
import { Settings } from './screens/Settings';

// Import components
import { Navbar } from './components/Navbar';
import { useAuth } from './hooks/useAuth';
import { DevModeIndicator } from './components/ui/DevModeIndicator';

function App() {
  const { user, loading } = useAuth();
  
  console.log('ITABS App rendering - user:', user, 'loading:', loading);

  if (loading) {
    return (
      <div className="min-h-screen bg-black relative overflow-hidden flex items-center justify-center">
        {/* Animated Background */}
        <div className="absolute inset-0">
          {/* Gradient Orbs */}
          <motion.div
            className="absolute w-96 h-96 bg-gradient-to-r from-purple-600/30 to-pink-600/30 rounded-full blur-3xl"
            animate={{
              x: [0, 100, 0],
              y: [0, -100, 0],
              scale: [1, 1.2, 1],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: 'easeInOut'
            }}
          />
          <motion.div
            className="absolute bottom-0 right-0 w-80 h-80 bg-gradient-to-r from-cyan-600/20 to-blue-600/20 rounded-full blur-3xl"
            animate={{
              x: [0, -150, 0],
              y: [0, 150, 0],
              scale: [1, 0.8, 1],
            }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: 'easeInOut'
            }}
          />
          
          {/* Grid Pattern */}
          <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px]" />
        </div>

        {/* Loading Content */}
        <div className="relative z-10 text-center">
          <motion.div
            className="relative mb-8"
            animate={{ rotate: 360 }}
            transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
          >
            <div className="w-24 h-24 border-4 border-purple-500/30 border-t-purple-500 rounded-full mx-auto"></div>
            <motion.div
              className="absolute inset-0 w-24 h-24 border-4 border-pink-500/30 border-b-pink-500 rounded-full mx-auto"
              animate={{ rotate: -360 }}
              transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="flex items-center justify-center mb-4"
          >
            <Brain className="w-8 h-8 text-purple-400 mr-3" />
            <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              Maximum Interview
            </h2>
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="text-white/70 text-lg font-medium mb-6"
          >
            Initializing AI Interview Coach...
          </motion.p>

          {/* Loading Progress Dots */}
          <div className="flex justify-center space-x-2">
            {[0, 1, 2].map((index) => (
              <motion.div
                key={index}
                className="w-3 h-3 bg-purple-500 rounded-full"
                animate={{
                  scale: [1, 1.5, 1],
                  opacity: [0.5, 1, 0.5],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  delay: index * 0.2,
                }}
              />
            ))}
          </div>
        </div>
        
        {/* Dev Mode Indicator */}
        <DevModeIndicator />
      </div>
    );
  }

  return (
    <Router>
      <div className="App min-h-screen bg-black relative">
        {/* Global Background Effects */}
        <div className="fixed inset-0 z-0">
          {/* Subtle Grid Pattern */}
          <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.01)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.01)_1px,transparent_1px)] bg-[size:100px_100px]" />
          
          {/* Ambient Lighting */}
          <motion.div
            className="absolute top-0 left-1/4 w-96 h-96 bg-purple-600/5 rounded-full blur-3xl"
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.3, 0.5, 0.3],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: 'easeInOut'
            }}
          />
          <motion.div
            className="absolute bottom-0 right-1/4 w-80 h-80 bg-cyan-600/5 rounded-full blur-3xl"
            animate={{
              scale: [1, 0.8, 1],
              opacity: [0.2, 0.4, 0.2],
            }}
            transition={{
              duration: 12,
              repeat: Infinity,
              ease: 'easeInOut'
            }}
          />
        </div>

        <div className="relative z-10">
          <Navbar />
          
          <AnimatePresence mode="wait">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route
                path="/login"
                element={user ? <Navigate to="/dashboard" replace /> : <Login />}
              />
              <Route
                path="/signup"
                element={user ? <Navigate to="/dashboard" replace /> : <Signup />}
              />
              {/* Password reset routes */}
              <Route
                path="/forgot-password"
                element={
                  <ForgotPassword />
                }
              />
              <Route
                path="/reset-password"
                element={
                  <ResetPassword />
                }
              />
              
              {/* Protected routes */}
              <Route
                path="/dashboard"
                element={user ? <Navigate to="/setup" replace /> : <Navigate to="/login" replace />}
              />
              <Route
                path="/setup"
                element={user ? <Setup /> : <Navigate to="/login" replace />}
              />
              <Route
                path="/elevenlabs-interview/:id"
                element={user ? <ElevenLabsInterviewScreen /> : <Navigate to="/login" replace />}
              />
              <Route
                path="/job-interview/:id"
                element={user ? <ElevenLabsJobInterview /> : <Navigate to="/login" replace />}
              />
              <Route
                path="/results/:id"
                element={user ? <Results /> : <Navigate to="/login" replace />}
              />
              <Route
                path="/profile"
                element={user ? <Profile /> : <Navigate to="/login" replace />}
              />
              <Route
                path="/settings"
                element={user ? <Settings /> : <Navigate to="/login" replace />}
              />
            </Routes>
          </AnimatePresence>
        </div>

        {/* Enhanced Toaster */}
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: 'rgba(0, 0, 0, 0.8)',
              color: '#fff',
              border: '1px solid rgba(255, 255, 255, 0.1)',
              borderRadius: '12px',
              backdropFilter: 'blur(12px)',
              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
            },
            success: {
              iconTheme: {
                primary: '#10B981',
                secondary: '#fff',
              },
              style: {
                background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(16, 185, 129, 0.05))',
                border: '1px solid rgba(16, 185, 129, 0.2)',
              },
            },
            error: {
              iconTheme: {
                primary: '#EF4444',
                secondary: '#fff',
              },
              style: {
                background: 'linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(239, 68, 68, 0.05))',
                border: '1px solid rgba(239, 68, 68, 0.2)',
              },
            },
            loading: {
              iconTheme: {
                primary: '#8B5CF6',
                secondary: '#fff',
              },
              style: {
                background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(139, 92, 246, 0.05))',
                border: '1px solid rgba(139, 92, 246, 0.2)',
              },
            },
          }}
        />

        {/* Floating Action Elements */}
        <motion.div
          className="fixed bottom-8 right-8 z-50"
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, delay: 1 }}
        >
          <motion.div
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="w-14 h-14 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center shadow-2xl cursor-pointer group"
          >
            <Sparkles className="w-6 h-6 text-white group-hover:rotate-12 transition-transform duration-300" />
          </motion.div>
        </motion.div>
      </div>
    </Router>
  );
}

export default App;