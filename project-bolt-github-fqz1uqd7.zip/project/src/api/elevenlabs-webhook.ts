// ElevenLabs Webhook Handler for Client Data Initiation
// This endpoint provides interview context data when ElevenLabs requests it

export interface ElevenLabsWebhookRequest {
  call_id: string;
  agent_id: string;
  user_id?: string;
  phone_number?: string;
  sip_uri?: string;
  metadata?: Record<string, any>;
}

export interface InterviewClientData {
  candidate_name: string;
  job_title: string;
  company: string;
  experience_level: 'entry' | 'mid' | 'senior';
  interviewer_name: string;
  interview_id?: string;
  custom_questions?: string[];
  focus_areas?: string[];
}

export interface ElevenLabsWebhookResponse {
  client_data: InterviewClientData;
  success: boolean;
  error?: string;
}

// Mock interview data for demonstration
// In production, this would fetch from your database based on call_id or user_id
const mockInterviewData: Record<string, InterviewClientData> = {
  'default': {
    candidate_name: 'John Doe',
    job_title: 'Software Engineer',
    company: 'ITABS',
    experience_level: 'mid',
    interviewer_name: 'Alex',
    custom_questions: [
      'Tell me about a challenging project you worked on recently.',
      'How do you handle working in a team environment?'
    ],
    focus_areas: ['Technical Skills', 'Communication', 'Problem Solving']
  }
};

// Webhook handler function
export async function handleElevenLabsWebhook(
  request: ElevenLabsWebhookRequest
): Promise<ElevenLabsWebhookResponse> {
  try {
    console.log('📞 ElevenLabs webhook called:', request);

    // Extract interview context from the request
    const { call_id, agent_id, user_id, metadata } = request;

    // In production, you would:
    // 1. Look up the interview session by call_id or user_id
    // 2. Fetch candidate and job details from your database
    // 3. Return the appropriate interview context

    // For now, we'll use mock data or metadata if provided
    let clientData: InterviewClientData;

    if (metadata && metadata.interview_data) {
      // Use interview data passed from your application
      clientData = {
        candidate_name: metadata.interview_data.candidate_name || 'Candidate',
        job_title: metadata.interview_data.job_title || 'Software Engineer',
        company: metadata.interview_data.company || 'ITABS',
        experience_level: metadata.interview_data.experience_level || 'mid',
        interviewer_name: metadata.interview_data.interviewer_name || 'Alex',
        interview_id: metadata.interview_data.interview_id,
        custom_questions: metadata.interview_data.custom_questions || [],
        focus_areas: metadata.interview_data.focus_areas || []
      };
    } else {
      // Use default mock data
      clientData = mockInterviewData['default'];
    }

    console.log('✅ Returning client data:', clientData);

    return {
      client_data: clientData,
      success: true
    };

  } catch (error) {
    console.error('❌ Webhook error:', error);
    
    return {
      client_data: mockInterviewData['default'], // Fallback to default
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}

// Express.js route handler (if using Express)
export function createElevenLabsWebhookRoute() {
  return async (req: any, res: any) => {
    try {
      const webhookRequest: ElevenLabsWebhookRequest = req.body;
      const response = await handleElevenLabsWebhook(webhookRequest);
      
      res.status(200).json(response);
    } catch (error) {
      console.error('❌ Webhook route error:', error);
      res.status(500).json({
        client_data: mockInterviewData['default'],
        success: false,
        error: 'Internal server error'
      });
    }
  };
}

// Vercel/Netlify serverless function handler
export default async function handler(req: any, res: any) {
  // Handle CORS for browser requests
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  try {
    const webhookRequest: ElevenLabsWebhookRequest = req.body;
    const response = await handleElevenLabsWebhook(webhookRequest);
    
    res.status(200).json(response);
  } catch (error) {
    console.error('❌ Serverless webhook error:', error);
    res.status(500).json({
      client_data: mockInterviewData['default'],
      success: false,
      error: 'Internal server error'
    });
  }
}

// Example of how to integrate with your existing interview system
export function createInterviewWebhookData(
  interviewSetup: any,
  candidateName: string,
  interviewId?: string
): InterviewClientData {
  return {
    candidate_name: candidateName,
    job_title: interviewSetup.jobTitle || 'Software Engineer',
    company: interviewSetup.company || 'ITABS',
    experience_level: interviewSetup.experienceLevel || 'mid',
    interviewer_name: interviewSetup.interviewerName || 'Alex',
    interview_id: interviewId,
    custom_questions: interviewSetup.customQuestions || [],
    focus_areas: interviewSetup.focusAreas || []
  };
}

// Utility function to register webhook data for a call
export function registerCallData(callId: string, interviewData: InterviewClientData) {
  // In production, store this in a database or cache
  // For now, we'll add it to our mock data
  mockInterviewData[callId] = interviewData;
  console.log(`📝 Registered call data for ${callId}:`, interviewData);
}
