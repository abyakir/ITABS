import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useProfile } from '../hooks/useProfile';
import { db } from '../lib/supabase';
import toast from 'react-hot-toast';

// Import dashboard components
import { StatCard } from './dashboard/StatCard';
import { InterviewCard } from './dashboard/InterviewCard';
import { ActivityChart } from './dashboard/ActivityChart';
import { SkillsRadarChart, SkillData } from './dashboard/SkillsRadarChart';

// Import UI components
import { Button } from './ui/Button';
import DashboardLayout from './layout/DashboardLayout';

// Import icons
import { Mic, Users, Award, BarChart3, Clock, TrendingUp, Activity } from 'lucide-react';

/**
 * Dashboard Setup Configuration
 * This file provides a central setup for all dashboard components
 * and configures them to work together seamlessly.
 */

// Common interface for dashboard data
export interface DashboardData {
  stats: {
    totalInterviews: number;
    completedInterviews: number;
    averageScore: number;
    totalPracticeTime: number;
    improvementTrend: number;
  };
  activityData: Array<{
    date: string;
    value: number;
    label: string;
  }>;
  skillsData: SkillData[];
  interviews: any[];
}

// Default data for components when actual data is loading
export const defaultDashboardData: DashboardData = {
  stats: {
    totalInterviews: 0,
    completedInterviews: 0,
    averageScore: 0,
    totalPracticeTime: 0,
    improvementTrend: 0
  },
  activityData: [
    { date: '2023-01-01', value: 6.5, label: 'Score' },
    { date: '2023-01-15', value: 7.2, label: 'Score' },
    { date: '2023-02-01', value: 7.8, label: 'Score' },
    { date: '2023-02-15', value: 7.3, label: 'Score' },
    { date: '2023-03-01', value: 8.1, label: 'Score' },
    { date: '2023-03-15', value: 8.5, label: 'Score' }
  ],
  skillsData: [
    { subject: 'Clarity', value: 8, fullMark: 10 },
    { subject: 'Confidence', value: 7, fullMark: 10 },
    { subject: 'Relevance', value: 9, fullMark: 10 },
    { subject: 'Technical', value: 7, fullMark: 10 },
    { subject: 'Communication', value: 8, fullMark: 10 }
  ],
  interviews: []
};

// Dashboard Hook - Consolidates all dashboard data fetching
export function useDashboardData(): {
  data: DashboardData;
  loading: boolean;
  refreshData: () => Promise<void>;
  actions: {
    startInterview: () => void;
    viewResults: (id: string) => void;
    resumeInterview: (id: string) => void;
  };
} {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { stats, refreshStats } = useProfile();
  const [dashboardData, setDashboardData] = React.useState<DashboardData>(defaultDashboardData);
  const [loading, setLoading] = React.useState(true);

  // Fetch all dashboard data
  const fetchDashboardData = React.useCallback(async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      
      // Fetch interviews
      const { data: interviews, error } = await db.interviews.getAll(user.id);
      
      if (error) throw error;
      
      // Update stats
      await refreshStats();
      
      // Process stats data for charts
      let activityData = defaultDashboardData.activityData;
      let skillsData = defaultDashboardData.skillsData;
      
      if (stats?.recent_activity && stats.recent_activity.length > 0) {
        activityData = stats.recent_activity
          .map(activity => ({
            date: activity.date,
            value: activity.score || 0,
            label: 'Score'
          }))
          .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      }
      
      if (stats?.skill_progress && stats.skill_progress.length > 0) {
        skillsData = stats.skill_progress.map(skill => ({
          subject: skill.skill,
          value: skill.current_level,
          fullMark: 10
        }));
      }
      
      // Update dashboard data state
      setDashboardData({
        stats: {
          totalInterviews: stats?.total_interviews || 0,
          completedInterviews: stats?.completed_interviews || 0,
          averageScore: stats?.average_score || 0,
          totalPracticeTime: stats?.total_practice_time || 0,
          improvementTrend: stats?.improvement_trend || 0
        },
        activityData,
        skillsData,
        interviews: interviews || []
      });
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  }, [user, refreshStats, stats]);

  // Initialize data
  React.useEffect(() => {
    if (user) {
      fetchDashboardData();
    }
  }, [user, fetchDashboardData]);

  // Dashboard actions
  const actions = React.useMemo(() => ({
    startInterview: () => navigate('/setup'),
    viewResults: (id: string) => navigate(`/results/${id}`),
    resumeInterview: (id: string) => navigate(`/elevenlabs-interview/${id}`)
  }), [navigate]);

  return {
    data: dashboardData,
    loading,
    refreshData: fetchDashboardData,
    actions
  };
}

// Dashboard Components with common configuration
export const DashboardComponents = {
  // Configured StatCard component
  StatCard,
  
  // Configured InterviewCard component
  InterviewCard,
  
  // Configured ActivityChart component with default props
  ActivityChart: (props: Partial<React.ComponentProps<typeof ActivityChart>>) => (
    <ActivityChart
      title="Interview Performance"
      description="Your interview scores over time"
      yAxisLabel="Score"
      tooltipFormatter={(value) => `${value.toFixed(1)}/10`}
      {...props}
    />
  ),
  
  // Configured SkillsRadarChart component with default props
  SkillsRadarChart: (props: Partial<React.ComponentProps<typeof SkillsRadarChart>>) => (
    <SkillsRadarChart
      title="Skill Breakdown"
      description="Your performance across key interview competencies"
      {...props}
    />
  )
};

// Full Dashboard UI
export const DashboardUI: React.FC = () => {
  const { data, loading, actions } = useDashboardData();
  
  return (
    <DashboardLayout>
      {/* Page header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1">
            Monitor your interview performance and track your progress
          </p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button
            onClick={actions.startInterview}
            icon={<Mic className="w-5 h-5" />}
          >
            Start New Interview
          </Button>
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <DashboardComponents.StatCard
          title="Total Interviews"
          value={data.stats.totalInterviews}
          icon={<Users className="w-6 h-6" />}
          color="blue"
        />
        <DashboardComponents.StatCard
          title="Completed Interviews"
          value={data.stats.completedInterviews}
          icon={<Award className="w-6 h-6" />}
          color="purple"
        />
        <DashboardComponents.StatCard
          title="Average Score"
          value={data.stats.averageScore.toFixed(1)}
          icon={<BarChart3 className="w-6 h-6" />}
          color="green"
          trend={data.stats.improvementTrend > 0 ? {
            direction: 'up',
            value: `${data.stats.improvementTrend.toFixed(1)}%`
          } : data.stats.improvementTrend < 0 ? {
            direction: 'down',
            value: `${Math.abs(data.stats.improvementTrend).toFixed(1)}%`
          } : undefined}
        />
        <DashboardComponents.StatCard
          title="Practice Time"
          value={`${data.stats.totalPracticeTime} min`}
          icon={<Clock className="w-6 h-6" />}
          color="yellow"
        />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2">
          <DashboardComponents.ActivityChart
            data={data.activityData}
          />
        </div>
        <div>
          <DashboardComponents.SkillsRadarChart
            data={data.skillsData}
          />
        </div>
      </div>

      {/* Recent interviews */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-900 flex items-center">
            <Activity className="w-5 h-5 mr-2 text-indigo-600" />
            Recent Interviews
          </h2>
          {data.interviews.length > 5 && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => actions.startInterview()}
            >
              View All
            </Button>
          )}
        </div>

        {loading ? (
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, index) => (
              <div key={index} className="animate-pulse h-24 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        ) : data.interviews.length > 0 ? (
          <div className="space-y-4">
            {data.interviews
              .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
              .slice(0, 5)
              .map((interview) => (
                <DashboardComponents.InterviewCard
                  key={interview.id}
                  id={interview.id}
                  position={interview.job_title}
                  company={interview.company}
                  date={interview.created_at}
                  duration={interview.duration_minutes || 0}
                  status={interview.status}
                  score={interview.status === 'completed' ? 7.8 : undefined}
                  onViewResults={actions.viewResults}
                  onResume={actions.resumeInterview}
                />
              ))}
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
            <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Mic className="w-8 h-8 text-indigo-600" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No interviews yet</h3>
            <p className="text-gray-500 mb-6">
              Start practicing to see your interview history and performance metrics
            </p>
            <Button onClick={actions.startInterview}>
              Start Your First Interview
            </Button>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

// Export everything for use in the application
export default {
  // Components
  components: DashboardComponents,
  
  // Hooks
  useDashboardData,
  
  // Full UI
  DashboardUI,
  
  // Data
  defaultData: defaultDashboardData
};