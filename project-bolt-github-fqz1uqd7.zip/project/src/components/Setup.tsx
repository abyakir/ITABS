@@ .. @@
       });
       
       // Ask user which interview experience they want to try
-      const useEnhanced = window.confirm(
-        'Would you like to try the enhanced job interview experience with connection verification and assessment report? (Click OK for enhanced, Cancel for standard)'
-      );
-      
-      if (useEnhanced) {
-        // Navigate to the new job interview experience
-        navigate(`/job-interview/new`, {
-          replace: true,
-          state: {
-            fromSetup: true,
-            interviewData
-          }
-        });
-      } else {
-        // Navigate to standard ElevenLabs interview
-        navigate(`/elevenlabs-interview/new`, {
-          replace: true,
-          state: {
-            fromSetup: true,
-            interviewData
-          }
-        });
-      }
+      // Navigate to the job interview experience
+      navigate(`/job-interview/new`, {
+        replace: true,
+        state: {
+          fromSetup: true,
+          interviewData
+        }
+      });
     } catch (error: any) {
       console.error('Setup error:', error);
@@ .. @@
           <div className="text-center mb-6">
             <div className="w-24 h-24 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-lg transform transition-transform hover:scale-105 hover:rotate-3 relative">
               <div className="absolute inset-0 bg-white opacity-10 blur-xl rounded-3xl"></div>
-              <Target className="w-10 h-10 text-white" />
+              <Target className="w-10 h-10 text-white animate-pulse" />
             </div>
             <motion.h2 
               initial={{ opacity: 0, y: 10 }}
@@ -498,6 +480,18 @@
               className="text-lg text-gray-600"
             >
               Confirm your settings and begin the interview
+              
+              {/* New feature badge */}
+              <motion.span
+                initial={{ opacity: 0, scale: 0.8 }}
+                animate={{ opacity: 1, scale: 1 }}
+                transition={{ delay: 0.6, duration: 0.5 }}
+                className="inline-block ml-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-xs px-3 py-0.5 rounded-full shadow-sm"
+              >
+                New
+              </motion.span>
             </motion.p>
+            
+            
           </div>