import React, { useState, useEffect } from 'react';

export interface TabsProps {
  tabs: Array<{
    label: string;
    id: string;
    icon?: React.ReactNode;
    content: React.ReactNode;
  }>;
  defaultTab?: string;
  variant?: 'default' | 'boxed' | 'underline';
  orientation?: 'horizontal' | 'vertical';
  className?: string;
  onChange?: (tabId: string) => void;
}

export const Tabs = React.forwardRef<HTMLDivElement, TabsProps>(({
  tabs,
  defaultTab,
  variant = 'default',
  orientation = 'horizontal',
  className = '',
  onChange
}, ref) => {
  const [activeTab, setActiveTab] = useState<string>(() => defaultTab || tabs[0]?.id || '');

  // Effect to handle defaultTab updates
  useEffect(() => {
    if (defaultTab && defaultTab !== activeTab) {
      setActiveTab(defaultTab);
    }
  }, [defaultTab, activeTab]);
  
  const handleTabChange = (tabId: string) => {
    if (tabId !== activeTab) {
      setActiveTab(tabId);
      if (onChange) onChange(tabId);
    }
  };

  const baseTabStyles = 'flex items-center font-medium transition-all focus:outline-none';
  
  const tabVariants = {
    default: {
      container: 'border-b border-gray-200',
      tab: `px-4 py-2.5 text-gray-500 hover:text-gray-700`,
      active: 'text-blue-600 border-b-2 border-blue-600'
    },
    boxed: {
      container: 'flex p-1 bg-gray-100 rounded-lg',
      tab: 'px-4 py-2 text-gray-500 rounded-lg hover:text-gray-800',
      active: 'text-gray-900 bg-white shadow-sm'
    },
    underline: {
      container: '',
      tab: 'px-1 py-2.5 mr-6 text-gray-500 border-b-2 border-transparent hover:text-gray-700 hover:border-gray-300',
      active: 'text-blue-600 border-b-2 border-blue-600'
    }
  };

  const orientationStyles = {
    horizontal: 'flex space-x-1',
    vertical: 'flex flex-col space-y-1'
  };

  return (
    <div className={`${className}`} ref={ref}>
      <div className={`${orientationStyles[orientation]} ${tabVariants[variant].container}`}>
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => handleTabChange(tab.id)}
            className={`
              ${baseTabStyles} 
              ${tabVariants[variant].tab} 
              ${activeTab === tab.id ? tabVariants[variant].active : ''}
            `}
          >
            {tab.icon && <span className="mr-2">{tab.icon}</span>}
            {tab.label}
          </button>
        ))}
      </div>
      <div className="mt-4">
        {tabs.map((tab) => (
          <div key={tab.id} className={activeTab === tab.id ? 'block' : 'hidden'}>
            {tab.content}
          </div>
        ))}
      </div>
    </div>
  );
});

// Display name for devtools
Tabs.displayName = 'Tabs';