import React, { useState } from 'react';
import { User } from 'lucide-react';

export interface AvatarProps {
  src?: string;
  alt?: string;
  fallback?: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  status?: 'online' | 'offline' | 'away' | 'busy';
}

export const Avatar: React.FC<AvatarProps> = ({
  src,
  alt = 'Avatar',
  fallback,
  size = 'md',
  className = '',
  status
}) => {
  const [imageError, setImageError] = useState(false);
  
  const sizeStyles = {
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-16 h-16',
    xl: 'w-24 h-24'
  };

  const statusColors = {
    online: 'bg-green-500',
    offline: 'bg-gray-400',
    away: 'bg-yellow-500',
    busy: 'bg-red-500'
  };

  // URL validation for security
  const isValidImageUrl = (url?: string): boolean => {
    if (!url) return false;
    try {
      const urlObj = new URL(url);
      return ['http:', 'https:'].includes(urlObj.protocol);
    } catch {
      return false;
    }
  };

  const validSrc = isValidImageUrl(src) ? src : undefined;
  
  return (
    <div className={`relative rounded-full overflow-hidden ${sizeStyles[size]} ${className}`}>
      {validSrc && !imageError ? (
        <img
          src={validSrc}
          alt={alt}
          className="w-full h-full object-cover"
          onError={() => setImageError(true)}
        />
      ) : (
        <div className="w-full h-full flex items-center justify-center bg-gray-200 text-gray-600">
          {fallback || <User className="w-1/2 h-1/2" />}
        </div>
      )}
      
      {status && (
        <span className={`absolute bottom-0 right-0 block rounded-full ${statusColors[status]} ring-2 ring-white ${size === 'sm' ? 'w-2 h-2' : 'w-3 h-3'}`} />
      )}
    </div>
  );
};