import React, { useState } from 'react';
import { Info, X, User, Key, CheckCircle } from 'lucide-react';
import { shouldUseMockAuth } from '../../lib/mockAuth';

/**
 * DevModeIndicator - Shows a warning when the app is running in development mode
 */
export const DevModeIndicator: React.FC = () => {
  const isDevMode = shouldUseMockAuth();
  const [expanded, setExpanded] = useState(false);

  if (!isDevMode) return null;
  
  // Check if user is already logged in via localStorage
  const isLoggedIn = !!localStorage.getItem('mock-auth-user');

  // Custom styling to make it visually distinct
  const indicatorStyle = {
    boxShadow: '0 4px 12px rgba(249, 115, 22, 0.15)',
    backdropFilter: 'blur(8px)'
  };
  
  return (
    <div className="fixed bottom-4 left-4 z-50 max-w-xs bg-amber-50/95 border border-amber-300 rounded-lg p-3 transition-all" style={indicatorStyle}>
      <div className="flex items-start">
        <div className="flex-shrink-0">
          <Info className="h-5 w-5 text-amber-400" />
        </div>
        <div className="ml-3 flex-1">
          <h3 className="text-sm font-medium text-amber-800 flex items-center justify-between">
            <span>Development Mode</span>
            <button
              type="button"
              onClick={() => setExpanded(!expanded)} 
              className="text-amber-500 hover:text-amber-700"
            >
              {expanded ? <X size={14} /> : <span className="text-xs">Show</span>}
            </button>
          </h3>
          
          {expanded && <div className="mt-1 text-xs text-amber-700">
            <p className="font-medium">Using mock authentication system</p>

            <div className="mt-2 p-2 bg-amber-100/70 rounded border border-amber-200 text-[11px]">
              {isLoggedIn ? (
              <div className="flex items-center gap-1 mb-1 text-green-600">
                <CheckCircle size={12} className="text-green-600" />
                <span className="font-medium">You are signed in with mock auth</span>
              </div>
              ) : (
              <>
              <div className="flex items-center gap-1 mb-1">
                <User size={12} className="text-amber-500" />
                <span className="font-medium">Demo email:</span> 
                <code className="bg-white/70 px-1 rounded">demo@example.com</code>
              </div>
              <div className="flex items-center gap-1">
                <Key size={12} className="text-amber-500" />
                <span className="font-medium">Demo password:</span> 
                <code className="bg-white/70 px-1 rounded">password123</code>
              </div>
              </>
              )}
            </div>

            <p className="mt-2 text-[10px] text-amber-700">
              Or use any email/password to register a new account
            </p>
            
            <p className="mt-2 border-t border-amber-200 pt-2 text-[10px]">
              To enable real auth, add Supabase credentials to:
              <code className="bg-amber-100 px-1 rounded block mt-1">.env</code>
              <span className="mt-1 block">Environment variables required:</span>
              <code className="bg-amber-100/70 px-1 rounded block mt-1 text-[9px]">VITE_SUPABASE_URL=...</code>
              <code className="bg-amber-100/70 px-1 rounded block mt-1 text-[9px]">VITE_SUPABASE_ANON_KEY=...</code>
            </p>
          </div>}
        </div>
      </div>
    </div>
  );
};