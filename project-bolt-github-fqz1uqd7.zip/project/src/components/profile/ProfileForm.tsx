import React, { useState, useEffect } from 'react';
import { User, Mail, MapPin, Phone, Globe, Briefcase, Linkedin, Github } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Avatar } from '../ui/Avatar';
import { useProfile } from '../../hooks/useProfile';
import { useAuth } from '../../hooks/useAuth';
import toast from 'react-hot-toast';

export const ProfileForm: React.FC = () => {
  const { profile, loading, saving, updateProfile, uploadProfilePhoto } = useProfile();
  const { user } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    location: '',
    country: '',
    phone_number: '',
    professional_experience: '',
    timezone: '',
    linkedin_url: '',
    github_url: '',
    portfolio_url: ''
  });

  useEffect(() => {
    if (profile) {
      console.log('Loading existing profile data into form:', profile);
      setFormData({
        first_name: profile.first_name || '',
        last_name: profile.last_name || '',
        location: profile.location || '',
        country: profile.country || '',
        phone_number: profile.phone_number || '',
        professional_experience: profile.professional_experience || '',
        timezone: profile.timezone || '',
        linkedin_url: profile.linkedin_url || '',
        github_url: profile.github_url || '',
        portfolio_url: profile.portfolio_url || ''
      });
    }
  }, [profile]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = async () => {
    try {
      console.log('Saving profile data:', formData);
      const result = await updateProfile(formData);
      if (result) {
        setIsEditing(false);
        toast.success('Profile updated successfully');
      } else {
        toast.error('Failed to update profile - no data returned');
      }
    } catch (error) {
      console.error('Error saving profile:', error);
      toast.error('Failed to update profile');
    }
  };

  const handleCancel = () => {
    setFormData({
      first_name: profile?.first_name || '',
      last_name: profile?.last_name || '',
      location: profile?.location || '',
      country: profile?.country || '',
      phone_number: profile?.phone_number || '',
      professional_experience: profile?.professional_experience || '',
      timezone: profile?.timezone || '',
      linkedin_url: profile?.linkedin_url || '',
      github_url: profile?.github_url || '',
      portfolio_url: profile?.portfolio_url || ''
    });
    setIsEditing(false);
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        await uploadProfilePhoto(file);
        toast.success('Profile photo updated');
      } catch (error) {
        toast.error('Failed to upload photo');
      }
    }
  };

  if (loading) {
    return <div className="animate-pulse bg-gray-200 h-96 rounded-xl"></div>;
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Personal Information</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center mb-8">
          <div className="relative mb-4">
            <Avatar 
              src={profile?.profile_photo_url} 
              size="xl" 
              alt={`${formData.first_name} ${formData.last_name}`}
              fallback={
                <div className="text-2xl font-medium text-gray-600">
                  {formData.first_name && formData.last_name 
                    ? `${formData.first_name[0]}${formData.last_name[0]}`
                    : <User className="w-12 h-12" />
                  }
                </div>
              }
            />
            
            {isEditing && (
              <label 
                htmlFor="photo-upload" 
                className="absolute -bottom-1 -right-1 w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center cursor-pointer text-white border-2 border-white hover:bg-indigo-700"
              >
                <input 
                  id="photo-upload" 
                  type="file" 
                  accept="image/*" 
                  className="hidden" 
                  onChange={handlePhotoUpload} 
                />
                <span className="text-xl">+</span>
              </label>
            )}
          </div>
          
          {!isEditing ? (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsEditing(true)}
            >
              Edit Profile
            </Button>
          ) : (
            <div className="flex space-x-2">
              <Button
                size="sm"
                onClick={handleSave}
                loading={saving}
              >
                Save
              </Button>
              <Button
                variant="outline"
                className="inline-flex items-center justify-center px-4 py-2 bg-gradient-to-r from-indigo-500 to-purple-500 text-white font-medium rounded-lg shadow-sm hover:shadow-md transition-all duration-300 hover:from-indigo-600 hover:to-purple-600 focus:ring-2 focus:ring-indigo-400 focus:outline-none"
                onClick={handleCancel}
              >
                <span className="mr-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-edit"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg></span>
                Cancel
              </Button>
            </div>
          )}
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <Input
            label="First Name"
            name="first_name"
            value={formData.first_name}
            onChange={handleInputChange}
            disabled={!isEditing}
            leftIcon={<User className="w-5 h-5" />}
          />
          <Input
            label="Last Name"
            name="last_name"
            value={formData.last_name}
            onChange={handleInputChange}
            disabled={!isEditing}
            leftIcon={<User className="w-5 h-5" />}
          />
          <Input
            label="Email"
            value={user?.email || ''}
            disabled={true}
            leftIcon={<Mail className="w-5 h-5" />}
          />
          <Input
            label="Phone"
            name="phone_number"
            value={formData.phone_number}
            onChange={handleInputChange}
            disabled={!isEditing}
            leftIcon={<Phone className="w-5 h-5" />}
          />
          <Input
            label="Location"
            name="location"
            value={formData.location}
            onChange={handleInputChange}
            disabled={!isEditing}
            leftIcon={<MapPin className="w-5 h-5" />}
          />
          <Input
            label="Country"
            name="country"
            value={formData.country}
            onChange={handleInputChange}
            disabled={!isEditing}
            leftIcon={<Globe className="w-5 h-5" />}
          />
          
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">Professional Experience</label>
            <div className="relative">
              <Briefcase className="absolute left-3 top-3 text-gray-400 w-5 h-5" />
              <textarea
                name="professional_experience"
                value={formData.professional_experience}
                onChange={handleInputChange}
                disabled={!isEditing}
                className={`
                  w-full pl-10 pr-3 py-2 min-h-[100px] border rounded-lg shadow-sm 
                  ${isEditing 
                    ? 'border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200' 
                    : 'border-gray-200 bg-gray-50'}
                  resize-vertical
                `}
                placeholder="Describe your professional background"
              />
            </div>
          </div>
          
          <Input
            label="LinkedIn URL"
            name="linkedin_url"
            value={formData.linkedin_url}
            onChange={handleInputChange}
            disabled={!isEditing}
            leftIcon={<Linkedin className="w-5 h-5" />}
          />
          <Input
            label="GitHub URL"
            name="github_url"
            value={formData.github_url}
            onChange={handleInputChange}
            disabled={!isEditing}
            leftIcon={<Github className="w-5 h-5" />}
          />
        </div>
      </CardContent>
    </Card>
  );
};