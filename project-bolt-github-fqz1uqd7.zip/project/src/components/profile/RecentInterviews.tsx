import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Calendar, 
  Clock, 
  Building, 
  Briefcase,
  ChevronRight 
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { db } from '../../lib/supabase';
import { useAuth } from '../../hooks/useAuth';
import toast from 'react-hot-toast';

export const RecentInterviews: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [interviews, setInterviews] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchInterviews();
    }
  }, [user]);

  const fetchInterviews = async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      const { data, error } = await db.interviews.getAll(user.id);
      
      if (error) throw error;
      
      // Sort by created_at descending (newest first)
      const sortedInterviews = data.sort((a, b) => 
        new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      ).slice(0, 5); // Get only the 5 most recent
      
      setInterviews(sortedInterviews);
    } catch (error) {
      console.error('Failed to fetch interviews:', error);
      toast.error('Failed to load recent interviews');
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'completed': return 'success';
      case 'in_progress': return 'primary';
      case 'pending': return 'default';
      case 'cancelled': return 'error';
      default: return 'default';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    }).format(date);
  };

  const viewResults = (interviewId: string) => {
    navigate(`/results/${interviewId}`);
  };

  const viewAllInterviews = () => {
    navigate('/dashboard');
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Interviews</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, index) => (
              <div key={index} className="animate-pulse flex items-center p-4 border border-gray-200 rounded-lg">
                <div className="w-12 h-12 bg-gray-200 rounded-lg mr-4"></div>
                <div className="flex-1">
                  <div className="h-5 bg-gray-200 rounded w-1/3 mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div className="flex items-center">
          <LayoutDashboard className="w-5 h-5 mr-2 text-indigo-600" />
          <CardTitle>Recent Interviews</CardTitle>
        </div>
        <Button variant="outline" size="sm" onClick={viewAllInterviews}>
          View All
        </Button>
      </CardHeader>
      <CardContent>
        {interviews.length > 0 ? (
          <div className="space-y-3">
            {interviews.map((interview) => (
              <div
                key={interview.id}
                className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center">
                  <div className={`
                    w-12 h-12 rounded-lg flex items-center justify-center mr-4
                    ${interview.status === 'completed' 
                      ? 'bg-green-100' 
                      : interview.status === 'in_progress'
                      ? 'bg-blue-100'
                      : 'bg-gray-100'
                    }
                  `}>
                    <Briefcase className={`
                      w-6 h-6
                      ${interview.status === 'completed' 
                        ? 'text-green-600' 
                        : interview.status === 'in_progress'
                        ? 'text-blue-600'
                        : 'text-gray-500'
                      }
                    `} />
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-0.5">
                      {interview.job_title}
                    </h4>
                    <div className="flex flex-wrap items-center text-xs text-gray-500 gap-x-3 gap-y-1">
                      <span className="flex items-center">
                        <Building className="w-3.5 h-3.5 mr-1" />
                        {interview.company}
                      </span>
                      <span className="flex items-center">
                        <Calendar className="w-3.5 h-3.5 mr-1" />
                        {formatDate(interview.created_at)}
                      </span>
                      {interview.duration_minutes > 0 && (
                        <span className="flex items-center">
                          <Clock className="w-3.5 h-3.5 mr-1" />
                          {interview.duration_minutes} min
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Badge variant={getStatusBadgeVariant(interview.status) as any}>
                    {interview.status.charAt(0).toUpperCase() + interview.status.slice(1).replace('_', ' ')}
                  </Badge>
                  
                  {interview.status === 'completed' && (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => viewResults(interview.id)}
                    >
                      Results
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Briefcase className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-gray-500 mb-4">No interviews yet</p>
            <Button
              size="sm"
              onClick={() => navigate('/setup')}
            >
              Start Your First Interview
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};