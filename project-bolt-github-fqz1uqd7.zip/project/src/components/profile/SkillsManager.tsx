import React, { useState, useEffect } from 'react';
import { X, Plus, Award, Briefcase } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Badge } from '../ui/Badge';
import { useProfile } from '../../hooks/useProfile';
import toast from 'react-hot-toast';

export const SkillsManager: React.FC = () => {
  const { profile, saving, updateProfile } = useProfile();
  const [isEditing, setIsEditing] = useState(false);
  const [skills, setSkills] = useState<string[]>([]);
  const [certifications, setCertifications] = useState<string[]>([]);
  const [newSkill, setNewSkill] = useState('');
  const [newCertification, setNewCertification] = useState('');

  useEffect(() => {
    if (profile) {
      setSkills(profile.skills || []);
      setCertifications(profile.certifications || []);
    }
  }, [profile]);

  const handleAddSkill = () => {
    if (newSkill.trim()) {
      setSkills(prev => [...prev, newSkill.trim()]);
      setNewSkill('');
    }
  };

  const handleRemoveSkill = (index: number) => {
    setSkills(prev => prev.filter((_, i) => i !== index));
  };

  const handleAddCertification = () => {
    if (newCertification.trim()) {
      setCertifications(prev => [...prev, newCertification.trim()]);
      setNewCertification('');
    }
  };

  const handleRemoveCertification = (index: number) => {
    setCertifications(prev => prev.filter((_, i) => i !== index));
  };

  const handleSave = async () => {
    try {
      await updateProfile({
        skills,
        certifications
      });
      setIsEditing(false);
      toast.success('Skills and certifications updated successfully');
    } catch (error) {
      toast.error('Failed to update skills and certifications');
    }
  };

  const handleCancel = () => {
    setSkills(profile?.skills || []);
    setCertifications(profile?.certifications || []);
    setIsEditing(false);
    setNewSkill('');
    setNewCertification('');
  };

  return (
    <div className="grid md:grid-cols-2 gap-6">
      {/* Skills Card */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div className="flex items-center">
            <Briefcase className="w-5 h-5 mr-2 text-indigo-600" />
            <CardTitle>Skills</CardTitle>
          </div>
          
          {!isEditing ? (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsEditing(true)}
            >
              Edit
            </Button>
          ) : (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleCancel}
            >
              Cancel
            </Button>
          )}
        </CardHeader>
        <CardContent>
          {isEditing && (
            <div className="mb-4 flex space-x-2">
              <Input
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                placeholder="Add a skill..."
                className="flex-1"
                onKeyPress={(e) => e.key === 'Enter' && handleAddSkill()}
              />
              <Button onClick={handleAddSkill} disabled={!newSkill.trim()}>
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          )}
          
          <div className="flex flex-wrap gap-2">
            {skills.length > 0 ? (
              skills.map((skill, index) => (
                <Badge
                  key={`${skill}-${index}`}
                  variant="primary"
                  className="py-1.5"
                >
                  {skill}
                  {isEditing && (
                    <button
                      onClick={() => handleRemoveSkill(index)}
                      className="ml-2 text-blue-700 hover:text-blue-800"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </Badge>
              ))
            ) : (
              <p className="text-gray-500 text-sm">No skills added yet.</p>
            )}
          </div>
          
          {isEditing && (
            <p className="text-xs text-gray-500 mt-2">
              Add skills relevant to your profession to highlight your expertise.
            </p>
          )}
        </CardContent>
      </Card>

      {/* Certifications Card */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div className="flex items-center">
            <Award className="w-5 h-5 mr-2 text-indigo-600" />
            <CardTitle>Certifications</CardTitle>
          </div>
          
          {isEditing && (
            <Button
              onClick={handleSave}
              loading={saving}
              size="sm"
            >
              Save
            </Button>
          )}
        </CardHeader>
        <CardContent>
          {isEditing && (
            <div className="mb-4 flex space-x-2">
              <Input
                value={newCertification}
                onChange={(e) => setNewCertification(e.target.value)}
                placeholder="Add a certification..."
                className="flex-1"
                onKeyPress={(e) => e.key === 'Enter' && handleAddCertification()}
              />
              <Button onClick={handleAddCertification} disabled={!newCertification.trim()}>
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          )}
          
          <div className="space-y-2">
            {certifications.length > 0 ? (
              certifications.map((certification, index) => (
                <div
                  key={`${certification}-${index}`}
                  className="flex items-center justify-between p-2 bg-gray-50 rounded-lg"
                >
                  <span className="text-gray-800">{certification}</span>
                  {isEditing && (
                    <button
                      onClick={() => handleRemoveCertification(index)}
                      className="text-red-500 hover:text-red-600"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))
            ) : (
              <p className="text-gray-500 text-sm">No certifications added yet.</p>
            )}
          </div>
          
          {isEditing && (
            <p className="text-xs text-gray-500 mt-2">
              Add your professional certifications and qualifications.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};