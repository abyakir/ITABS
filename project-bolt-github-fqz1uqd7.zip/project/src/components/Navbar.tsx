import React from 'react';
import { Link, useLocation, useNavigate, NavLink } from 'react-router-dom';
import { Mic, User, Settings, LogOut, Home, Brain, Sparkles } from 'lucide-react';
import { Button } from './ui/Button';
import { useAuth } from '../hooks/useAuth';

export function Navbar() {
  const { user, signOut } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="bg-gradient-to-r from-indigo-900/95 to-purple-900/95 backdrop-blur-xl border-b border-indigo-800/30 sticky top-0 z-50 shadow-lg">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-1">
        <div className="flex justify-between items-center h-16">
          {/* Enhanced Logo */}
          <Link to="/" className="group flex items-center space-x-3">
            <div className="relative">
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-400 to-purple-500 rounded-xl flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-all duration-300 z-10">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div className="absolute -inset-1 bg-white/20 rounded-xl blur-md opacity-0 group-hover:opacity-70 transition-opacity duration-300"></div>
            </div>
            <div className="flex flex-col items-start">
              <span className="text-xl font-bold bg-gradient-to-r from-white to-indigo-200 bg-clip-text text-transparent">Maximum Interview</span>
              <span className="text-xs text-indigo-200/70">AI Interview Coach</span>
            </div>
          </Link>

          {/* Improved Navigation Links */}
          {user && (
            <div className="flex items-center space-x-1">
              <NavLink
                to="/dashboard"
                className={`flex items-center space-x-2 px-4 py-2 rounded-xl font-medium transition-all duration-200 ${
                  isActive('/dashboard')
                    ? 'bg-white/15 text-white shadow-md backdrop-blur-sm border border-white/10'
                    : 'text-indigo-100 hover:bg-white/10 hover:text-white'
                }`}
              >
                <Home className="w-5 h-5" />
                <span>Dashboard</span>
              </NavLink>

              <NavLink
                to="/profile"
                className={`flex items-center space-x-2 px-4 py-2 rounded-xl font-medium transition-all duration-200 ${
                  isActive('/profile')
                    ? 'bg-white/15 text-white shadow-md backdrop-blur-sm border border-white/10'
                    : 'text-indigo-100 hover:bg-white/10 hover:text-white'
                }`}
              >
                <User className="w-5 h-5" />
                <span>Profile</span>
              </NavLink>

              <NavLink
                to="/settings"
                className={`flex items-center space-x-2 px-4 py-2 rounded-xl font-medium transition-all duration-200 ${
                  isActive('/settings')
                    ? 'bg-white/15 text-white shadow-md backdrop-blur-sm border border-white/10'
                    : 'text-indigo-100 hover:bg-white/10 hover:text-white'
                }`}
              >
                <Settings className="w-5 h-5" />
                <span>Settings</span>
              </NavLink>

              <button
                onClick={handleSignOut}
                className="flex items-center space-x-2 px-4 py-2 rounded-xl font-medium text-indigo-100 hover:text-red-300 hover:bg-red-500/20 transition-all duration-200"
              >
                <LogOut className="w-5 h-5" />
                <span>Sign Out</span>
              </button>
            </div>
          )}

          {/* Modern Auth Buttons */}
          {!user && (
            <div className="flex items-center space-x-3">
              <Button 
                variant="outline"
                to="/login"
                className="text-indigo-100 hover:text-white font-medium border border-transparent hover:border-white/10"
                onClick={() => navigate('/login')}
              >
                Sign In
              </Button>
              <Link to="/signup">
                <button className="relative overflow-hidden group px-6 py-2.5 bg-gradient-to-r from-indigo-400 to-purple-500 text-white font-semibold rounded-xl shadow-md hover:shadow-indigo-500/30 transition-all duration-300">
                  <span className="absolute inset-0 flex items-center justify-center w-full h-full">
                    <Sparkles className="w-full h-full text-white/10 scale-150 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                  </span>
                  Get Started
                </button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}