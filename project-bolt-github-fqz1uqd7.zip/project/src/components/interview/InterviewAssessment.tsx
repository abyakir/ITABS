import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Award, 
  BarChart2,
  MessageSquare,
  Brain,
  Users,
  Code,
  Download,
  Share2,
  ChevronDown,
  ChevronUp,
  Clock
} from 'lucide-react';
import { Button } from '../ui/Button';

// Assessment data interface
export interface InterviewAssessment {
  communication: {
    score: number; // 1-10
    feedback: string;
    strengths: string[];
    areas_for_improvement: string[];
  };
  technical_knowledge: {
    score: number; // 1-10
    feedback: string;
    strengths: string[];
    areas_for_improvement: string[];
  };
  problem_solving: {
    score: number; // 1-10
    feedback: string;
    strengths: string[];
    areas_for_improvement: string[];
  };
  professional_demeanor: {
    score: number; // 1-10
    feedback: string;
    strengths: string[];
    areas_for_improvement: string[];
  };
  overall_grade: {
    letter: string; // A+ to F
    score: number; // 1-10
    feedback: string;
    recommendation: string;
  };
  interview_metrics: {
    duration: number; // in minutes
    questions_answered: number;
    average_response_time: number; // in seconds
    connection_quality: number; // 1-10
  };
}

interface InterviewAssessmentProps {
  assessment: InterviewAssessment;
  onExport: () => void;
  onRetake: () => void;
  onShare: () => void;
}

export function InterviewAssessment({ 
  assessment, 
  onExport, 
  onRetake,
  onShare
}: InterviewAssessmentProps) {
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    'communication': true,
    'technical': true,
    'problem': true,
    'professional': true,
    'overall': true
  });

  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  // Convert numerical score to letter grade
  const getLetterGrade = (score: number): string => {
    if (score >= 9.5) return 'A+';
    if (score >= 9.0) return 'A';
    if (score >= 8.5) return 'A-';
    if (score >= 8.0) return 'B+';
    if (score >= 7.5) return 'B';
    if (score >= 7.0) return 'B-';
    if (score >= 6.5) return 'C+';
    if (score >= 6.0) return 'C';
    if (score >= 5.5) return 'C-';
    if (score >= 5.0) return 'D+';
    if (score >= 4.5) return 'D';
    if (score >= 4.0) return 'D-';
    return 'F';
  };

  // Get color based on score
  const getScoreColor = (score: number) => {
    if (score >= 8.5) return 'text-green-600';
    if (score >= 7) return 'text-blue-600';
    if (score >= 5.5) return 'text-yellow-600';
    if (score >= 4) return 'text-orange-600';
    return 'text-red-600';
  };

  // Get background color based on score
  const getScoreBackground = (score: number) => {
    if (score >= 8.5) return 'bg-green-50 border-green-200';
    if (score >= 7) return 'bg-blue-50 border-blue-200';
    if (score >= 5.5) return 'bg-yellow-50 border-yellow-200';
    if (score >= 4) return 'bg-orange-50 border-orange-200';
    return 'bg-red-50 border-red-200';
  };

  return (
    <div className="w-full max-w-4xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6 text-white">
        <h1 className="text-2xl font-bold mb-2">Interview Assessment Report</h1>
        <div className="flex justify-between items-center">
          <p className="text-indigo-100">
            Comprehensive AI evaluation of your interview performance
          </p>
          <div className="flex items-center text-sm">
            <Clock className="w-4 h-4 mr-1" />
            <span>{assessment.interview_metrics.duration} minutes</span>
            <span className="mx-2">•</span>
            <span>{assessment.interview_metrics.questions_answered} questions</span>
          </div>
        </div>
      </div>

      {/* Overall Grade Card */}
      <div className="p-6">
        <div className={`${getScoreBackground(assessment.overall_grade.score)} p-6 rounded-xl border mb-8`}>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center">
              <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center shadow-md">
                <span className={`text-3xl font-bold ${getScoreColor(assessment.overall_grade.score)}`}>
                  {assessment.overall_grade.letter}
                </span>
              </div>
              <div className="ml-4">
                <h2 className="text-xl font-semibold text-gray-900">Overall Grade</h2>
                <p className={`text-sm ${getScoreColor(assessment.overall_grade.score)}`}>
                  {assessment.overall_grade.score}/10 - {assessment.overall_grade.feedback}
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button 
                size="sm"
                variant="outline"
                onClick={onShare}
                icon={<Share2 className="w-4 h-4" />}
              >
                Share
              </Button>
              <Button
                size="sm"
                onClick={onExport}
                icon={<Download className="w-4 h-4" />}
              >
                Export PDF
              </Button>
            </div>
          </div>
          
          <div className="mt-4 text-sm">
            <p className="font-medium">Recommendation:</p>
            <p className="mt-1">{assessment.overall_grade.recommendation}</p>
          </div>
        </div>

        {/* Interview Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-gray-50 rounded-lg p-4 text-center">
            <div className="text-3xl font-bold text-gray-800">{assessment.interview_metrics.duration}</div>
            <div className="text-sm text-gray-600">Minutes</div>
          </div>
          <div className="bg-gray-50 rounded-lg p-4 text-center">
            <div className="text-3xl font-bold text-gray-800">{assessment.interview_metrics.questions_answered}</div>
            <div className="text-sm text-gray-600">Questions</div>
          </div>
          <div className="bg-gray-50 rounded-lg p-4 text-center">
            <div className="text-3xl font-bold text-gray-800">{assessment.interview_metrics.average_response_time}s</div>
            <div className="text-sm text-gray-600">Avg. Response</div>
          </div>
          <div className="bg-gray-50 rounded-lg p-4 text-center">
            <div className="text-3xl font-bold text-gray-800">{assessment.interview_metrics.connection_quality}/10</div>
            <div className="text-sm text-gray-600">Connection</div>
          </div>
        </div>

        {/* Communication Skills */}
        <AssessmentSection
          title="Communication Skills"
          score={assessment.communication.score}
          feedback={assessment.communication.feedback}
          strengths={assessment.communication.strengths}
          improvements={assessment.communication.areas_for_improvement}
          icon={<MessageSquare className="w-5 h-5" />}
          isExpanded={expandedSections.communication}
          onToggle={() => toggleSection('communication')}
        />

        {/* Technical Knowledge */}
        <AssessmentSection
          title="Technical Knowledge"
          score={assessment.technical_knowledge.score}
          feedback={assessment.technical_knowledge.feedback}
          strengths={assessment.technical_knowledge.strengths}
          improvements={assessment.technical_knowledge.areas_for_improvement}
          icon={<Code className="w-5 h-5" />}
          isExpanded={expandedSections.technical}
          onToggle={() => toggleSection('technical')}
        />

        {/* Problem Solving */}
        <AssessmentSection
          title="Problem Solving"
          score={assessment.problem_solving.score}
          feedback={assessment.problem_solving.feedback}
          strengths={assessment.problem_solving.strengths}
          improvements={assessment.problem_solving.areas_for_improvement}
          icon={<Brain className="w-5 h-5" />}
          isExpanded={expandedSections.problem}
          onToggle={() => toggleSection('problem')}
        />

        {/* Professional Demeanor */}
        <AssessmentSection
          title="Professional Demeanor"
          score={assessment.professional_demeanor.score}
          feedback={assessment.professional_demeanor.feedback}
          strengths={assessment.professional_demeanor.strengths}
          improvements={assessment.professional_demeanor.areas_for_improvement}
          icon={<Users className="w-5 h-5" />}
          isExpanded={expandedSections.professional}
          onToggle={() => toggleSection('professional')}
        />

        {/* Action Buttons */}
        <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            size="lg"
            variant="outline" 
            className="flex-1"
            onClick={onRetake}
          >
            Start Another Interview
          </Button>
          <Button
            size="lg"
            className="bg-gradient-to-r from-indigo-600 to-purple-600 flex-1"
            onClick={onExport}
            icon={<Download className="w-5 h-5 mr-2" />}
          >
            Download Full Report
          </Button>
        </div>
      </div>
    </div>
  );
}

// Assessment section component
interface AssessmentSectionProps {
  title: string;
  score: number;
  feedback: string;
  strengths: string[];
  improvements: string[];
  icon: React.ReactNode;
  isExpanded: boolean;
  onToggle: () => void;
}

function AssessmentSection({
  title,
  score,
  feedback,
  strengths,
  improvements,
  icon,
  isExpanded,
  onToggle
}: AssessmentSectionProps) {
  // Get color based on score
  const getScoreColor = (score: number) => {
    if (score >= 8.5) return 'text-green-600';
    if (score >= 7) return 'text-blue-600';
    if (score >= 5.5) return 'text-yellow-600';
    if (score >= 4) return 'text-orange-600';
    return 'text-red-600';
  };

  return (
    <div className="border rounded-lg mb-4 overflow-hidden">
      <button 
        className="w-full flex items-center justify-between p-4 bg-gray-50 text-left"
        onClick={onToggle}
      >
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center mr-3">
            {icon}
          </div>
          <div>
            <h3 className="font-medium text-gray-900">{title}</h3>
            <div className="flex items-center">
              <div className={`font-semibold ${getScoreColor(score)}`}>{score}/10</div>
              <div className="w-20 h-1.5 bg-gray-200 rounded-full ml-2">
                <div 
                  className={`h-1.5 rounded-full ${score >= 8.5 ? 'bg-green-500' : score >= 7 ? 'bg-blue-500' : score >= 5.5 ? 'bg-yellow-500' : score >= 4 ? 'bg-orange-500' : 'bg-red-500'}`}
                  style={{ width: `${score * 10}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>
        {isExpanded ? (
          <ChevronUp className="w-5 h-5 text-gray-500" />
        ) : (
          <ChevronDown className="w-5 h-5 text-gray-500" />
        )}
      </button>
      
      {isExpanded && (
        <motion.div 
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="p-4"
        >
          <p className="text-gray-700 mb-4">{feedback}</p>
          
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-medium text-gray-900 mb-2 flex items-center">
                <Award className="w-4 h-4 text-green-500 mr-2" />
                Strengths
              </h4>
              <ul className="space-y-1">
                {strengths.map((strength, idx) => (
                  <li key={idx} className="text-sm flex items-start">
                    <span className="text-green-500 mr-2">•</span>
                    <span>{strength}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-gray-900 mb-2 flex items-center">
                <BarChart2 className="w-4 h-4 text-blue-500 mr-2" />
                Areas for Improvement
              </h4>
              <ul className="space-y-1">
                {improvements.map((improvement, idx) => (
                  <li key={idx} className="text-sm flex items-start">
                    <span className="text-blue-500 mr-2">•</span>
                    <span>{improvement}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}

// Generate a mock assessment for preview/testing
export function generateMockAssessment(
  communicationScore: number = 8,
  technicalScore: number = 7,
  problemSolvingScore: number = 8,
  professionalScore: number = 9
): InterviewAssessment {
  // Calculate overall score (weighted average)
  const overallScore = (
    communicationScore * 0.3 + 
    technicalScore * 0.3 + 
    problemSolvingScore * 0.25 + 
    professionalScore * 0.15
  );

  return {
    communication: {
      score: communicationScore,
      feedback: "You communicated your ideas clearly and maintained good eye contact throughout the interview. Your responses were well-structured and concise.",
      strengths: [
        "Clear articulation of complex concepts",
        "Excellent listening skills - you responded directly to questions asked",
        "Good use of technical terminology with appropriate explanations"
      ],
      areas_for_improvement: [
        "Sometimes rushed through answers to complex questions",
        "Could use more concrete examples in explanations",
        "Consider using more visual aids when explaining technical concepts"
      ]
    },
    technical_knowledge: {
      score: technicalScore,
      feedback: "You demonstrated strong technical knowledge in most areas. Your explanations of technical concepts were accurate, though some areas could use deeper exploration.",
      strengths: [
        "Strong understanding of core principles",
        "Good knowledge of industry best practices",
        "Applied technical knowledge to practical examples"
      ],
      areas_for_improvement: [
        "Could provide more depth in some specialized areas",
        "Strengthen knowledge of emerging technologies in the field",
        "Work on explaining complex technical concepts in simpler terms"
      ]
    },
    problem_solving: {
      score: problemSolvingScore,
      feedback: "Your problem-solving approach was methodical and effective. You broke down complex problems into manageable parts and considered multiple solutions.",
      strengths: [
        "Systematic approach to analyzing problems",
        "Creative thinking in solution development",
        "Considered multiple perspectives before finalizing solutions"
      ],
      areas_for_improvement: [
        "Could improve speed of problem analysis",
        "Consider exploring more innovative approaches to common problems",
        "Practice articulating your problem-solving process more clearly"
      ]
    },
    professional_demeanor: {
      score: professionalScore,
      feedback: "You maintained a highly professional demeanor throughout the interview. Your confidence and poise impressed the interviewer.",
      strengths: [
        "Excellent professional appearance and presence",
        "Poised and confident under pressure",
        "Responded thoughtfully to challenging questions"
      ],
      areas_for_improvement: [
        "Could show more enthusiasm for certain topics",
        "Consider using more industry-specific examples in responses",
        "Work on maintaining consistent energy levels throughout long interviews"
      ]
    },
    overall_grade: {
      letter: overallScore >= 9 ? "A" : overallScore >= 8 ? "B+" : overallScore >= 7 ? "B" : overallScore >= 6 ? "C+" : "C",
      score: overallScore,
      feedback: overallScore >= 8 ? 
        "Excellent interview performance. You would likely advance to the next round." : 
        overallScore >= 7 ? 
        "Good interview performance with some areas for improvement." : 
        "Satisfactory interview with several areas that need development.",
      recommendation: overallScore >= 8 ? 
        "Continue your strong interview preparation. Focus on deepening technical knowledge and developing more detailed examples of past experiences." : 
        overallScore >= 7 ? 
        "Practice more mock interviews focusing on technical depth and communication clarity. Record yourself to analyze your responses." : 
        "Consider working with a career coach on interview skills and deepen your technical knowledge in key areas."
    },
    interview_metrics: {
      duration: Math.floor(Math.random() * 20) + 25, // 25-45 minutes
      questions_answered: Math.floor(Math.random() * 10) + 12, // 12-22 questions
      average_response_time: Math.floor(Math.random() * 30) + 60, // 60-90 seconds
      connection_quality: Math.floor(Math.random() * 2) + 8 // 8-10 quality
    }
  };
}