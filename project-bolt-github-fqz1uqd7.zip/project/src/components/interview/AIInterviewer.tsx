import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, User, Bot } from 'lucide-react';

interface AIInterviewerProps {
  isActive: boolean;
  isSpeaking: boolean;
  interviewerName: string;
  companyName: string;
  statusText?: string;
  avatarUrl?: string;
  className?: string;
}

export function AIInterviewer({
  isActive,
  isSpeaking,
  interviewerName,
  companyName,
  statusText,
  avatarUrl,
  className = ''
}: AIInterviewerProps) {
  // Use a default professional avatar image from Pexels
  const defaultAvatarUrl = "https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=600";
  const [currentAvatarUrl, setCurrentAvatarUrl] = useState(avatarUrl || defaultAvatarUrl);

  // Fallback if the provided URL fails to load
  const handleImageError = () => {
    if (currentAvatarUrl !== defaultAvatarUrl) {
      setCurrentAvatarUrl(defaultAvatarUrl);
    }
  };

  // Simulate subtle head movements and blinking for the interviewer
  const [headPosition, setHeadPosition] = useState({ x: 0, y: 0 });
  const [isBlinking, setIsBlinking] = useState(false);
  const blinkIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const moveIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Setup animation intervals
  useEffect(() => {
    // Subtle random head movements
    moveIntervalRef.current = setInterval(() => {
      if (isSpeaking) {
        // More movement when speaking
        setHeadPosition({
          x: (Math.random() * 2 - 1) * 3,
          y: (Math.random() * 2 - 1) * 2
        });
      } else {
        // Subtle movement when listening
        setHeadPosition({
          x: (Math.random() * 2 - 1) * 1.5,
          y: (Math.random() * 2 - 1)
        });
      }
    }, 2000);

    // Random blinking
    blinkIntervalRef.current = setInterval(() => {
      setIsBlinking(true);
      setTimeout(() => setIsBlinking(false), 200);
    }, Math.random() * 3000 + 2000);

    return () => {
      if (moveIntervalRef.current) clearInterval(moveIntervalRef.current);
      if (blinkIntervalRef.current) clearInterval(blinkIntervalRef.current);
    };
  }, [isSpeaking]);

  // Status indicators
  const getStatusIndicator = () => {
    if (!isActive) return "Connecting...";
    return isSpeaking ? "Speaking" : statusText || "Listening";
  };

  return (
    <div className={`relative rounded-2xl overflow-hidden bg-gradient-to-b from-gray-900 to-gray-800 ${className}`}>
      {/* Main interviewer avatar */}
      <div className="absolute inset-0 flex items-center justify-center overflow-hidden">
        {isActive ? (
          <motion.div
            animate={{
              x: headPosition.x,
              y: headPosition.y,
              scale: isBlinking ? 0.995 : 1
            }}
            transition={{
              type: "spring",
              stiffness: 100,
              damping: 10
            }}
            className="relative w-full h-full"
          >
            {/* Avatar image with background blur for depth */}
            <div className="absolute inset-0 filter blur-sm opacity-50 transform scale-110">
              <img 
                src={currentAvatarUrl} 
                alt="Background" 
                className="w-full h-full object-cover"
                onError={handleImageError}
              />
            </div>
            
            {/* Sharper foreground avatar */}
            <img 
              src={currentAvatarUrl} 
              alt={interviewerName} 
              className="w-full h-full object-cover"
              onError={handleImageError}
              style={{ objectPosition: "center 20%" }}  // Focus more on face
            />
            
            {/* Overlay gradient for better text contrast */}
            <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent"></div>
          </motion.div>
        ) : (
          <div className="w-32 h-32 rounded-full bg-gray-800 flex items-center justify-center">
            <Bot className="w-16 h-16 text-gray-600" />
          </div>
        )}
      </div>

      {/* Audio wave animation when speaking */}
      <AnimatePresence>
        {isSpeaking && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute bottom-20 left-1/2 transform -translate-x-1/2 flex items-center justify-center space-x-1 z-10"
          >
            {[0, 1, 2, 3, 4].map((i) => (
              <motion.div
                key={i}
                className="w-1 bg-white rounded-full"
                animate={{ 
                  height: [3, Math.random() * 15 + 5, 3],
                  opacity: [0.5, 1, 0.5]
                }}
                transition={{
                  duration: 0.6,
                  repeat: Infinity,
                  repeatType: "reverse",
                  delay: i * 0.1
                }}
              />
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Name badge */}
      <div className="absolute bottom-6 left-0 right-0 px-6">
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="bg-black/60 backdrop-blur-sm rounded-lg p-3 text-white"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center mr-3">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="font-medium">{interviewerName}</div>
                <div className="text-xs text-white/70">{companyName}</div>
              </div>
            </div>
            <div className="flex items-center">
              {isSpeaking && (
                <div className="bg-green-500 w-2 h-2 rounded-full mr-2 animate-pulse"></div>
              )}
              <span className="text-xs font-medium">{getStatusIndicator()}</span>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}