import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Check, AlertCircle, Wifi, Play, Loader, Mic } from 'lucide-react';
import { Button } from '../ui/Button';
import { delayPromise } from '../../lib/utils';

interface ConnectionVerificationProps {
  onReady: () => void;
  onCancel: () => void;
}

export function ConnectionVerification({ onReady, onCancel }: ConnectionVerificationProps) {
  const [stage, setStage] = useState<'checking' | 'ready' | 'failed'>('checking');
  const [connectionStrength, setConnectionStrength] = useState(0);
  const [microphoneReady, setMicrophoneReady] = useState(false);
  const [speakerReady, setSpeakerReady] = useState(false);
  const [networkReady, setNetworkReady] = useState(false);
  const audioContext = useRef<AudioContext | null>(null);
  const audioElement = useRef<HTMLAudioElement | null>(null);

  // Simulate connection verification process
  useEffect(() => {
    // Function to check microphone
    const checkMicrophone = async (): Promise<boolean> => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        // Stop tracks after successful verification
        stream.getTracks().forEach(track => track.stop());
        return true;
      } catch (error) {
        console.error('Microphone access failed:', error);
        return false;
      }
    };

    // Function to check speakers
    const checkSpeakers = async (): Promise<boolean> => {
      try {
        // Initialize audio context if needed
        if (!audioContext.current) {
          audioContext.current = new (window.AudioContext || (window as any).webkitAudioContext)();
        }
        
        // Simple audio context test - just check if we can create an audio context
        // This is sufficient for testing basic audio capabilities
        return audioContext.current.state === 'running' || audioContext.current.state === 'suspended';
      } catch (error) {
        console.error('Speaker check failed:', error);
        return false;
      }
    };

    // Function to simulate network check
    const checkNetwork = async (): Promise<boolean> => {
      try {
        // This is a simple check - in a real implementation you'd test connection to your APIs
        const response = await fetch('https://httpbin.org/status/200');
        return response.status === 200;
      } catch (error) {
        console.error('Network check failed:', error);
        return false;
      }
    };

    // Combine all checks
    const runConnectionVerification = async () => {
      try {
        // Start with 0% connection strength
        setConnectionStrength(10);
        await delayPromise(500);
        
        // Check microphone
        setConnectionStrength(20);
        const micResult = await checkMicrophone();
        setMicrophoneReady(micResult);
        setConnectionStrength(40);
        await delayPromise(500);
        
        // Check speakers
        setConnectionStrength(60);
        const speakerResult = await checkSpeakers();
        setSpeakerReady(speakerResult);
        setConnectionStrength(80);
        await delayPromise(500);
        
        // Check network
        const networkResult = await checkNetwork();
        setNetworkReady(networkResult);
        setConnectionStrength(100);
        
        // Verify all systems are ready
        const allReady = micResult && networkResult; // Speaker test is optional due to autoplay policies
        setStage(allReady ? 'ready' : 'failed');
      } catch (error) {
        console.error('Connection verification failed:', error);
        setStage('failed');
      }
    };

    // Run verification with a small delay to allow UI to render
    const timer = setTimeout(() => {
      runConnectionVerification();
    }, 1000);

    return () => {
      clearTimeout(timer);
      // Cleanup audio context and element
      if (audioContext.current?.state !== 'closed') {
        audioContext.current?.close();
      }
      if (audioElement.current) {
        audioElement.current.pause();
        audioElement.current = null;
      }
    };
  }, []);

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 bg-black/80 backdrop-blur-sm">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 mx-4"
      >
        <h2 className="text-2xl font-semibold text-center mb-6">Interview Connection Setup</h2>
        
        {/* Connection verification progress */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-700">Connection Verification</span>
            <span className="text-sm font-medium text-gray-700">{connectionStrength}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <motion.div 
              className="h-2 rounded-full bg-gradient-to-r from-blue-500 to-indigo-600"
              initial={{ width: '0%' }}
              animate={{ width: `${connectionStrength}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
        </div>
        
        {/* Status indicators */}
        <div className="space-y-3 mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Mic className="w-5 h-5 text-gray-600 mr-3" />
              <span className="text-gray-700">Microphone Access</span>
            </div>
            <StatusIndicator status={microphoneReady ? 'success' : stage === 'checking' ? 'loading' : 'error'} />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Wifi className="w-5 h-5 text-gray-600 mr-3" />
              <span className="text-gray-700">Network Connection</span>
            </div>
            <StatusIndicator status={networkReady ? 'success' : stage === 'checking' ? 'loading' : 'error'} />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <svg className="w-5 h-5 text-gray-600 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M16 16a4 4 0 0 1-8 0" />
                <path d="M12 16v4" />
                <path d="M8 12H4a8 8 0 0 0 16 0h-4" />
                <path d="M12 4v8" />
              </svg>
              <span className="text-gray-700">Audio Output</span>
            </div>
            <StatusIndicator status={speakerReady ? 'success' : stage === 'checking' ? 'loading' : 'warning'} />
          </div>
        </div>

        {/* Action buttons based on stage */}
        {stage === 'checking' && (
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mb-4"></div>
            <p className="text-gray-600">Verifying connection components...</p>
          </div>
        )}

        {stage === 'ready' && (
          <div className="space-y-4">
            <div className="p-4 bg-green-50 rounded-lg border border-green-200">
              <div className="flex">
                <div className="flex-shrink-0">
                  <Check className="h-5 w-5 text-green-500" />
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-green-800">All systems ready</h3>
                  <p className="text-sm text-green-700 mt-1">Your connection is stable and all required components are working properly.</p>
                </div>
              </div>
            </div>
            
            <div className="text-center">
              <p className="text-gray-800 font-medium mb-4">Ready to begin your interview?</p>
              <div className="flex gap-3 justify-center">
                <Button 
                  onClick={onCancel} 
                  variant="outline" 
                  className="px-5"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={onReady} 
                  className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8"
                  icon={<Play className="w-4 h-4 mr-2" />}
                >
                  Begin Interview
                </Button>
              </div>
            </div>
          </div>
        )}

        {stage === 'failed' && (
          <div className="space-y-4">
            <div className="p-4 bg-red-50 rounded-lg border border-red-200">
              <div className="flex">
                <div className="flex-shrink-0">
                  <AlertCircle className="h-5 w-5 text-red-500" />
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-red-800">Connection issues detected</h3>
                  <div className="text-sm text-red-700 mt-1">
                    <p>Please check the following:</p>
                    <ul className="list-disc list-inside mt-1">
                      {!microphoneReady && <li>Microphone access is required</li>}
                      {!networkReady && <li>Network connection is unstable</li>}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="text-center">
              <div className="flex gap-3 justify-center">
                <Button 
                  onClick={onCancel} 
                  variant="outline" 
                  className="px-5"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={() => {
                    setStage('checking');
                    setConnectionStrength(0);
                    setMicrophoneReady(false);
                    setSpeakerReady(false);
                    setNetworkReady(false);
                    
                    // Re-run verification after a short delay
                    setTimeout(() => {
                      const runVerification = async () => {
                        try {
                          // Check microphone
                          setConnectionStrength(20);
                          const micResult = await navigator.mediaDevices.getUserMedia({ audio: true })
                            .then(stream => {
                              stream.getTracks().forEach(track => track.stop());
                              return true;
                            })
                            .catch(() => false);
                          
                          setMicrophoneReady(micResult);
                          await delayPromise(500);
                          setConnectionStrength(50);
                          
                          // Check network
                          const networkResult = await fetch('https://httpbin.org/status/200')
                            .then(res => res.status === 200)
                            .catch(() => false);
                          
                          setNetworkReady(networkResult);
                          setConnectionStrength(100);
                          
                          // Update stage based on results
                          const allReady = micResult && networkResult;
                          setStage(allReady ? 'ready' : 'failed');
                        } catch (error) {
                          console.error('Verification retry failed:', error);
                          setStage('failed');
                        }
                      };
                      
                      runVerification();
                    }, 1000);
                  }}
                >
                  Retry Connection
                </Button>
              </div>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
}

// Helper component for status indicators
function StatusIndicator({ status }: { status: 'success' | 'error' | 'warning' | 'loading' }) {
  switch (status) {
    case 'success':
      return (
        <span className="inline-flex items-center justify-center w-6 h-6 bg-green-100 rounded-full">
          <Check className="w-4 h-4 text-green-600" />
        </span>
      );
    case 'error':
      return (
        <span className="inline-flex items-center justify-center w-6 h-6 bg-red-100 rounded-full">
          <svg className="w-4 h-4 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </span>
      );
    case 'warning':
      return (
        <span className="inline-flex items-center justify-center w-6 h-6 bg-yellow-100 rounded-full">
          <AlertCircle className="w-4 h-4 text-yellow-600" />
        </span>
      );
    case 'loading':
      return (
        <span className="inline-flex items-center justify-center w-6 h-6">
          <Loader className="w-4 h-4 text-gray-400 animate-spin" />
        </span>
      );
  }
}