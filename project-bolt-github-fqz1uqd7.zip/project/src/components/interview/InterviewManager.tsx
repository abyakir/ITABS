import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, Clock, MessageSquare, AlertCircle, CheckCircle, Wifi, WifiOff } from 'lucide-react';
import { ConnectionVerification } from './ConnectionVerification';
import { InterviewAssessment, generateMockAssessment } from './InterviewAssessment';
import { Button } from '../ui/Button';
import { delayPromise } from '../../lib/utils';

// Interview question type
interface Question {
  id: string;
  text: string;
  type: 'intro' | 'technical' | 'behavioral' | 'situational' | 'closing';
  followUp?: string[];
}

// Interview state management
type InterviewState = 
  | 'verification' 
  | 'intro'
  | 'questions'
  | 'assessment'
  | 'disconnected';

interface InterviewManagerProps {
  candidateName: string;
  interviewerName: string;
  jobTitle: string;
  companyName: string;
  questionSet?: Question[];
  onComplete: (assessment: InterviewAssessment) => void;
  onCancel: () => void;
}

export const InterviewManager: React.FC<InterviewManagerProps> = ({
  candidateName,
  interviewerName,
  jobTitle,
  companyName,
  questionSet,
  onComplete,
  onCancel
}) => {
  // State management
  const [state, setState] = useState<InterviewState>('verification');
  const [isConnected, setIsConnected] = useState(false);
  const [isAISpeaking, setIsAISpeaking] = useState(false);
  const [isCandidateSpeaking, setIsCandidateSpeaking] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(-1);
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [transcript, setTranscript] = useState<Array<{role: 'ai' | 'user', text: string, timestamp: Date}>>([]);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [assessment, setAssessment] = useState<InterviewAssessment | null>(null);
  const [connectionQuality, setConnectionQuality] = useState<'good' | 'fair' | 'poor'>('good');
  const [reconnectAttempts, setReconnectAttempts] = useState(0);

  // References
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const lastQuestionTimeRef = useRef<number>(0);
  const questionsAnsweredRef = useRef<number>(0);
  const totalResponseTimeRef = useRef<number>(0);
  const disconnectionTimestampsRef = useRef<number[]>([]);
  
  // Default questions if none are provided
  const defaultQuestions = useRef<Question[]>([
    {
      id: 'intro-1',
      text: `Hello ${candidateName}, I'm ${interviewerName} from ${companyName}. Thank you for joining me today for this ${jobTitle} interview. Before we begin, could you briefly introduce yourself and tell me about your background?`,
      type: 'intro'
    },
    {
      id: 'behavioral-1',
      text: 'Could you tell me about a challenging project you worked on recently? What was your role, and how did you overcome any obstacles?',
      type: 'behavioral',
      followUp: ['What was the most difficult part of that project?', 'What did you learn from that experience?']
    },
    {
      id: 'technical-1',
      text: 'Let\'s talk about your technical skills. How would you rate your proficiency in the key technologies required for this position?',
      type: 'technical',
      followUp: ['Which areas do you feel are your strongest?', 'What are you currently learning to improve?']
    },
    {
      id: 'situational-1',
      text: 'Imagine you\'re assigned to a project with a tight deadline, but you realize the scope is larger than initially estimated. How would you handle this situation?',
      type: 'situational'
    },
    {
      id: 'behavioral-2',
      text: 'Can you describe a time when you had to work with a difficult team member? How did you handle the situation?',
      type: 'behavioral'
    },
    {
      id: 'technical-2',
      text: 'Let\'s discuss a specific technical challenge. How would you approach optimizing the performance of a system that has begun to slow down under increased load?',
      type: 'technical'
    },
    {
      id: 'behavioral-3',
      text: 'Tell me about a time when you received critical feedback. How did you respond to it?',
      type: 'behavioral'
    },
    {
      id: 'technical-3',
      text: 'What methodologies do you use to ensure code quality and maintainability in your projects?',
      type: 'technical'
    },
    {
      id: 'situational-2',
      text: 'If you noticed a colleague making a significant mistake that could impact the team, how would you address it?',
      type: 'situational'
    },
    {
      id: 'behavioral-4',
      text: 'Describe a situation where you had to learn a new technology or skill quickly. How did you approach it?',
      type: 'behavioral'
    },
    {
      id: 'closing-1',
      text: `That concludes the main part of our interview. Do you have any questions about the ${jobTitle} position or about working at ${companyName}?`,
      type: 'closing'
    },
    {
      id: 'closing-2',
      text: `Thank you for your time today. I've enjoyed learning about your experience and approach. We'll be in touch soon with next steps.`,
      type: 'closing'
    }
  ]);

  // Timer for elapsed time
  useEffect(() => {
    if (state === 'questions' || state === 'intro') {
      timerRef.current = setInterval(() => {
        setElapsedTime(prev => prev + 1);
      }, 1000);
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [state]);

  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Simulate connection status
  useEffect(() => {
    const simulateConnectionQuality = () => {
      // Mostly good connection with occasional issues
      const random = Math.random();
      if (random < 0.9) {
        setConnectionQuality('good');
        setIsConnected(true);
      } else if (random < 0.95) {
        setConnectionQuality('fair');
        setIsConnected(true);
      } else {
        setConnectionQuality('poor');
        setIsConnected(false);
        
        // Track disconnection time
        disconnectionTimestampsRef.current.push(Date.now());
        
        // Attempt reconnection after delay
        setTimeout(() => {
          setReconnectAttempts(prev => prev + 1);
          setIsConnected(true);
          setConnectionQuality('fair');
          
          // Gradually improve back to good
          setTimeout(() => {
            setConnectionQuality('good');
          }, 5000);
        }, 3000);
      }
    };

    // Only simulate connection issues during the interview
    if (state === 'questions') {
      const interval = setInterval(simulateConnectionQuality, 20000); // Check every 20 seconds
      return () => clearInterval(interval);
    }
  }, [state]);

  // Handle verification complete
  const handleVerificationComplete = useCallback(() => {
    setState('intro');
    setIsConnected(true);
    
    // Start with intro message
    const introQuestion = (questionSet || defaultQuestions.current)[0];
    setCurrentQuestion(introQuestion);
    setCurrentQuestionIndex(0);
    
    // Simulate AI speaking the intro
    setIsAISpeaking(true);
    
    // Add to transcript
    setTranscript([{
      role: 'ai',
      text: introQuestion.text,
      timestamp: new Date()
    }]);
    
    // After a delay, stop AI speaking to allow candidate response
    setTimeout(() => {
      setIsAISpeaking(false);
      lastQuestionTimeRef.current = Date.now();
    }, 5000);
  }, [questionSet]);

  // Move to next question
  const moveToNextQuestion = useCallback(() => {
    const questions = questionSet || defaultQuestions.current;
    const nextIndex = currentQuestionIndex + 1;
    
    // Check if we've reached the end
    if (nextIndex >= questions.length) {
      // Process and display assessment
      processAssessment();
      return;
    }
    
    // Update question index and current question
    setCurrentQuestionIndex(nextIndex);
    setCurrentQuestion(questions[nextIndex]);
    
    // Simulate AI speaking
    setIsAISpeaking(true);
    
    // Add to transcript
    setTranscript(prev => [...prev, {
      role: 'ai',
      text: questions[nextIndex].text,
      timestamp: new Date()
    }]);
    
    // After a delay, stop AI speaking
    setTimeout(() => {
      setIsAISpeaking(false);
      lastQuestionTimeRef.current = Date.now();
    }, 4000);
  }, [currentQuestionIndex, questionSet, processAssessment]);

  // Simulate candidate response
  const simulateCandidateResponse = useCallback(() => {
    // Only allow response when AI isn't speaking and we're in interview mode
    if (isAISpeaking || state !== 'questions' || !isConnected) return;
    
    // Start candidate speaking
    setIsCandidateSpeaking(true);
    
    // Random response time between 15-45 seconds
    const responseTime = Math.floor(Math.random() * 30000) + 15000;
    
    setTimeout(() => {
      // Stop candidate speaking
      setIsCandidateSpeaking(false);
      
      // Calculate response time and add to total
      const actualResponseTime = (Date.now() - lastQuestionTimeRef.current) / 1000; // in seconds
      totalResponseTimeRef.current += actualResponseTime;
      questionsAnsweredRef.current++;
      
      // Add to transcript with a mock response
      setTranscript(prev => [...prev, {
        role: 'user',
        text: `[Candidate Response to "${currentQuestion?.text.substring(0, 30)}..."]`,
        timestamp: new Date()
      }]);
      
      // Move to next question after a delay (minimum 5 seconds between questions)
      setTimeout(() => {
        moveToNextQuestion();
      }, 5000);
    }, responseTime);
  }, [isAISpeaking, state, isConnected, currentQuestion, moveToNextQuestion]);

  // Process assessment when interview is complete
  function processAssessment() {
    // Calculate average response time
    const avgResponseTime = totalResponseTimeRef.current / questionsAnsweredRef.current;
    
    // Create assessment
    const interviewAssessment: InterviewAssessment = {
      communication: {
        score: 8.5,
        feedback: "Your communication was clear, concise, and well-structured throughout the interview. You articulated your thoughts effectively and used appropriate technical terminology.",
        strengths: [
          "Clear articulation of complex concepts",
          "Good use of professional language",
          "Well-structured responses with clear beginning, middle, and end"
        ],
        areas_for_improvement: [
          "Could provide slightly more concise answers to some questions",
          "Consider using more specific examples to illustrate points",
          "Work on maintaining consistent eye contact throughout responses"
        ]
      },
      technical_knowledge: {
        score: 7.8,
        feedback: "You demonstrated solid technical knowledge in most areas. Your understanding of core concepts was evident, though some specialized areas could be strengthened.",
        strengths: [
          "Strong foundation in fundamental concepts",
          "Good understanding of industry best practices",
          "Ability to explain technical concepts in accessible terms"
        ],
        areas_for_improvement: [
          "Deepen knowledge in advanced system optimization techniques",
          "Expand familiarity with newer frameworks in your stack",
          "Consider preparing more quantifiable results from technical projects"
        ]
      },
      problem_solving: {
        score: 8.2,
        feedback: "Your problem-solving approach was methodical and effective. You demonstrated good critical thinking and the ability to address challenges from multiple angles.",
        strengths: [
          "Systematic approach to breaking down complex problems",
          "Consideration of multiple solutions before selecting an approach",
          "Good balance of theoretical knowledge and practical application"
        ],
        areas_for_improvement: [
          "Practice more rapid problem analysis for time-sensitive scenarios",
          "Consider incorporating more discussion of trade-offs in your solutions",
          "Add more focus on scalability considerations in your approaches"
        ]
      },
      professional_demeanor: {
        score: 9.1,
        feedback: "Your professional demeanor was excellent throughout the interview. You maintained composure, showed appropriate enthusiasm, and demonstrated strong cultural alignment.",
        strengths: [
          "Consistent professional manner throughout all questions",
          "Appropriate level of confidence without overstatement",
          "Thoughtful and respectful engagement with challenging scenarios"
        ],
        areas_for_improvement: [
          "Could show slightly more enthusiasm when discussing company-specific topics",
          "Consider preparing more questions about team culture",
          "Minor refinement in professional appearance recommended"
        ]
      },
      overall_grade: {
        letter: "B+",
        score: 8.4,
        feedback: "Your interview performance was strong overall. You demonstrated good technical knowledge, excellent communication skills, and strong professionalism.",
        recommendation: "You would likely advance to the next round of interviews. To further improve, focus on deepening technical knowledge in specialized areas and preparing more specific examples of your past work and achievements."
      },
      interview_metrics: {
        duration: Math.round(elapsedTime / 60), // convert seconds to minutes
        questions_answered: questionsAnsweredRef.current,
        average_response_time: Math.round(avgResponseTime),
        connection_quality: disconnectionTimestampsRef.current.length > 2 ? 7 : disconnectionTimestampsRef.current.length > 0 ? 8 : 10
      }
    };

    // Update state
    setAssessment(interviewAssessment);
    setState('assessment');
  }

  // JSX for different stages
  const renderContent = () => {
    switch (state) {
      case 'verification':
        return (
          <ConnectionVerification
            onReady={handleVerificationComplete}
            onCancel={onCancel}
          />
        );
        
      case 'intro':
      case 'questions':
        return (
          <div className="p-6 max-w-4xl mx-auto">
            {/* Connection status indicator */}
            <div className="mb-6 flex items-center justify-between">
              <div className="flex items-center">
                {isConnected ? (
                  <Wifi className={`w-5 h-5 ${connectionQuality === 'good' ? 'text-green-500' : connectionQuality === 'fair' ? 'text-yellow-500' : 'text-red-500'}`} />
                ) : (
                  <WifiOff className="w-5 h-5 text-red-500" />
                )}
                <span className={`ml-2 text-sm font-medium ${isConnected ? (connectionQuality === 'good' ? 'text-green-600' : connectionQuality === 'fair' ? 'text-yellow-600' : 'text-red-600') : 'text-red-600'}`}>
                  {isConnected 
                    ? (connectionQuality === 'good' 
                      ? 'Connected' 
                      : connectionQuality === 'fair' 
                        ? 'Connected (Fair)' 
                        : 'Connected (Poor)')
                    : 'Disconnected'}
                </span>
                
                <div className="mx-4 h-4 border-r border-gray-300"></div>
                
                <Clock className="w-5 h-5 text-gray-600" />
                <span className="ml-2 text-sm font-medium text-gray-700">{formatTime(elapsedTime)}</span>
              </div>
              
              <div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    if (window.confirm('Are you sure you want to end this interview early?')) {
                      // Generate assessment with current data
                      const mockAssessment = generateMockAssessment(
                        7 + Math.random() * 3,
                        6 + Math.random() * 4,
                        7 + Math.random() * 3,
                        8 + Math.random() * 2
                      );
                      setAssessment(mockAssessment);
                      setState('assessment');
                    }
                  }}
                >
                  End Interview
                </Button>
              </div>
            </div>
            
            {/* Interview content */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              {/* AI question and speaking indicator */}
              <div className="p-6 bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
                <div className="flex items-start mb-4">
                  <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
                    <MessageSquare className="w-5 h-5 text-white" />
                  </div>
                  <div className="ml-4 flex-1">
                    <div className="font-medium">{interviewerName} • {companyName}</div>
                    <div className={`text-xs ${isAISpeaking ? 'text-white' : 'text-white/70'}`}>
                      {isAISpeaking ? (
                        <div className="flex items-center">
                          <span className="w-2 h-2 bg-green-400 rounded-full mr-1 animate-pulse"></span> 
                          Speaking...
                        </div>
                      ) : 'Waiting for response...'}
                    </div>
                  </div>
                </div>
                
                <div className="text-lg">
                  {currentQuestion?.text || "Loading questions..."}
                </div>
              </div>
              
              {/* Candidate response area */}
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="font-medium text-gray-900">Your Response</div>
                  <div className={`flex items-center text-sm ${isCandidateSpeaking ? 'text-green-600' : 'text-gray-500'}`}>
                    {isCandidateSpeaking ? (
                      <>
                        <span className="w-2 h-2 bg-green-500 rounded-full mr-1 animate-pulse"></span>
                        Recording response...
                      </>
                    ) : isAISpeaking ? (
                      <>Interviewer is speaking</>
                    ) : !isConnected ? (
                      <span className="text-red-500">Connection lost. Attempting to reconnect...</span>
                    ) : (
                      <>Click to respond</>
                    )}
                  </div>
                </div>
                
                {/* Response button */}
                <button
                  className={`w-full h-24 rounded-xl border-2 border-dashed flex items-center justify-center transition-colors ${
                    isCandidateSpeaking 
                      ? 'bg-green-50 border-green-300' 
                      : isAISpeaking 
                        ? 'bg-gray-50 border-gray-300 cursor-not-allowed' 
                        : !isConnected
                          ? 'bg-red-50 border-red-300 cursor-not-allowed'
                          : 'bg-indigo-50 border-indigo-300 hover:bg-indigo-100'
                  }`}
                  onClick={simulateCandidateResponse}
                  disabled={isAISpeaking || isCandidateSpeaking || !isConnected}
                >
                  {isCandidateSpeaking ? (
                    <div className="flex flex-col items-center">
                      <div className="w-12 h-3 bg-green-200 rounded-full mb-2">
                        <div className="w-full h-full bg-green-500 rounded-full animate-pulse"></div>
                      </div>
                      <span className="text-green-700 text-sm">Recording your response...</span>
                    </div>
                  ) : isAISpeaking ? (
                    <span className="text-gray-500">Please wait for the interviewer to finish...</span>
                  ) : !isConnected ? (
                    <span className="text-red-500">Connection lost. Please wait...</span>
                  ) : (
                    <div className="flex items-center">
                      <Mic className="w-5 h-5 mr-2 text-indigo-500" />
                      <span className="text-indigo-700">Click to respond to the question</span>
                    </div>
                  )}
                </button>
              </div>
              
              {/* Transcript */}
              <div className="border-t border-gray-100 p-6 bg-gray-50">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-medium text-gray-900">Interview Transcript</h3>
                  <span className="text-xs text-gray-500">{transcript.length} messages</span>
                </div>
                
                <div className="max-h-64 overflow-y-auto space-y-4">
                  {transcript.map((message, idx) => (
                    <div key={idx} className={`flex ${message.role === 'ai' ? 'justify-start' : 'justify-end'}`}>
                      <div className={`rounded-lg px-4 py-2 max-w-md ${message.role === 'ai' ? 'bg-indigo-100 text-indigo-900' : 'bg-green-100 text-green-900'}`}>
                        <div className="text-xs font-medium mb-1">
                          {message.role === 'ai' ? interviewerName : candidateName} • {message.timestamp.toLocaleTimeString()}
                        </div>
                        <div className="text-sm">
                          {message.text}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            {/* Connection issue warning */}
            {connectionQuality === 'poor' && isConnected && (
              <div className="mt-4 bg-yellow-50 border border-yellow-300 rounded-lg p-4 flex items-start">
                <AlertCircle className="w-5 h-5 text-yellow-500 mr-2 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm text-yellow-700">
                    <strong>Connection quality is poor.</strong> This may affect the interview experience.
                  </p>
                  <p className="text-xs text-yellow-600 mt-1">
                    Suggestion: Check your internet connection or move to a location with better signal.
                  </p>
                </div>
              </div>
            )}
            
            {/* Reconnection indicator */}
            {!isConnected && (
              <div className="mt-4 bg-red-50 border border-red-300 rounded-lg p-4 flex items-start">
                <AlertCircle className="w-5 h-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm text-red-700">
                    <strong>Connection lost.</strong> Attempting to reconnect...
                  </p>
                  <div className="flex items-center mt-2">
                    <div className="w-32 bg-red-200 h-1.5 rounded-full mr-3">
                      <motion.div 
                        className="bg-red-500 h-1.5 rounded-full"
                        initial={{ width: "0%" }}
                        animate={{ width: "100%" }}
                        transition={{ duration: 3, repeat: Infinity }}
                      />
                    </div>
                    <span className="text-xs text-red-600">
                      Attempt {reconnectAttempts + 1}...
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        );
        
      case 'assessment':
        return assessment ? (
          <InterviewAssessment 
            assessment={assessment}
            onExport={() => {
              alert('Export functionality would be implemented here. This would generate and download a PDF report.');
            }}
            onRetake={() => {
              // Reset everything and start a new interview
              setState('verification');
              setCurrentQuestionIndex(-1);
              setCurrentQuestion(null);
              setTranscript([]);
              setElapsedTime(0);
              setAssessment(null);
              setConnectionQuality('good');
              setReconnectAttempts(0);
              setIsConnected(false);
              setIsAISpeaking(false);
              setIsCandidateSpeaking(false);
              questionsAnsweredRef.current = 0;
              totalResponseTimeRef.current = 0;
              lastQuestionTimeRef.current = 0;
              disconnectionTimestampsRef.current = [];
            }}
            onShare={() => {
              alert('Share functionality would be implemented here. This would generate a shareable link or allow social media sharing.');
            }}
          />
        ) : (
          <div className="p-8 max-w-md mx-auto text-center">
            <div className="w-16 h-16 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <h3 className="text-xl font-semibold mb-2">Generating Assessment</h3>
            <p className="text-gray-600">
              Please wait while we analyze your interview performance...
            </p>
          </div>
        );
        
      case 'disconnected':
        return (
          <div className="p-8 max-w-md mx-auto text-center bg-white rounded-xl shadow-lg">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <WifiOff className="w-8 h-8 text-red-500" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Connection Lost</h3>
            <p className="text-gray-600 mb-6">
              We've lost connection with the interview server and were unable to reconnect after multiple attempts.
            </p>
            <div className="space-y-3">
              <Button
                className="w-full"
                onClick={() => {
                  // Try to reconnect from the beginning
                  setState('verification');
                  setReconnectAttempts(0);
                }}
              >
                Try Again
              </Button>
              <Button
                variant="outline"
                className="w-full"
                onClick={onCancel}
              >
                Cancel Interview
              </Button>
            </div>
          </div>
        );
      
      default:
        return <div>Loading...</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-900 via-purple-800 to-purple-900">
      <div className="container mx-auto py-8 px-4">
        <AnimatePresence mode="wait">
          <motion.div
            key={state}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4 }}
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
};