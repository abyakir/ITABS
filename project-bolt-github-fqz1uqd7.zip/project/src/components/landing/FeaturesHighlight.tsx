import React from 'react';
import { motion } from 'framer-motion';
import { Mic, BarChart3, Brain, Zap, Clock, Check } from 'lucide-react';

export const FeaturesHighlight: React.FC = () => {
  const fadeInUp = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <section className="py-24 bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-4">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5 }}
          variants={fadeInUp}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Designed for Interview Success
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our AI-powered platform offers everything you need to prepare effectively and 
            build the confidence to ace your next interview.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-x-12 gap-y-16 lg:gap-x-24">
          {/* Feature 1: Real-time Feedback */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            variants={fadeInUp}
            className="relative"
          >
            <div className="absolute -left-6 top-0 w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center">
              <Mic className="w-6 h-6 text-indigo-600" />
            </div>
            <div className="pl-10">
              <h3 className="text-xl font-bold text-gray-900 mb-3">Interactive Voice Interviews</h3>
              <p className="text-gray-600 mb-4">
                Engage in natural, conversation-based interviews with our AI interviewer. 
                Practice your verbal communication skills in a realistic interview environment.
              </p>
              <ul className="space-y-2">
                {['Realistic conversation flow', 'Industry-specific questions', 'Adaptive follow-up questions'].map((item, i) => (
                  <li key={i} className="flex items-start">
                    <Check className="w-5 h-5 text-green-500 mr-2 flex-shrink-0" />
                    <span className="text-gray-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>

          {/* Feature 2: Analytics */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            variants={fadeInUp}
            className="relative"
          >
            <div className="absolute -left-6 top-0 w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
              <BarChart3 className="w-6 h-6 text-purple-600" />
            </div>
            <div className="pl-10">
              <h3 className="text-xl font-bold text-gray-900 mb-3">Comprehensive Performance Analytics</h3>
              <p className="text-gray-600 mb-4">
                Receive detailed metrics on your interview performance, identifying your strengths 
                and areas for improvement across multiple dimensions.
              </p>
              <ul className="space-y-2">
                {['Clarity and communication scoring', 'Technical knowledge assessment', 'Confidence and engagement metrics'].map((item, i) => (
                  <li key={i} className="flex items-start">
                    <Check className="w-5 h-5 text-green-500 mr-2 flex-shrink-0" />
                    <span className="text-gray-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>

          {/* Feature 3: AI Coaching */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            variants={fadeInUp}
            className="relative"
          >
            <div className="absolute -left-6 top-0 w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <Brain className="w-6 h-6 text-blue-600" />
            </div>
            <div className="pl-10">
              <h3 className="text-xl font-bold text-gray-900 mb-3">AI-Powered Coaching</h3>
              <p className="text-gray-600 mb-4">
                Get personalized recommendations and strategies to improve your interview skills 
                based on your unique strengths and weaknesses.
              </p>
              <ul className="space-y-2">
                {['Personalized improvement strategies', 'Sample answer frameworks', 'Industry-specific advice'].map((item, i) => (
                  <li key={i} className="flex items-start">
                    <Check className="w-5 h-5 text-green-500 mr-2 flex-shrink-0" />
                    <span className="text-gray-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>

          {/* Feature 4: Efficiency */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            variants={fadeInUp}
            className="relative"
          >
            <div className="absolute -left-6 top-0 w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <Clock className="w-6 h-6 text-green-600" />
            </div>
            <div className="pl-10">
              <h3 className="text-xl font-bold text-gray-900 mb-3">Practice On Your Schedule</h3>
              <p className="text-gray-600 mb-4">
                Flexible interview practice whenever you need it, available 24/7 with unlimited 
                sessions to help you prepare at your own pace.
              </p>
              <ul className="space-y-2">
                {['Available 24/7', 'No scheduling required', 'Unlimited practice sessions'].map((item, i) => (
                  <li key={i} className="flex items-start">
                    <Check className="w-5 h-5 text-green-500 mr-2 flex-shrink-0" />
                    <span className="text-gray-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};