import React from 'react';
import { motion } from 'framer-motion';
import { Brain, BarChart3, Mic, Users, MessageSquare, Award } from 'lucide-react';

export const FeatureSection: React.FC = () => {
  const features = [
    {
      title: 'AI-Powered Feedback',
      description: 'Get real-time feedback on your answers with advanced natural language processing that identifies strengths and areas for improvement.',
      icon: Brain,
      color: 'bg-indigo-500'
    },
    {
      title: 'Voice Interaction',
      description: 'Practice with a voice-first experience that simulates real interview conversations and improves your verbal communication skills.',
      icon: Mic,
      color: 'bg-purple-500'
    },
    {
      title: 'Performance Analytics',
      description: 'Track your progress over time with detailed metrics on clarity, relevance, confidence, and technical knowledge.',
      icon: BarChart3,
      color: 'bg-blue-500'
    },
    {
      title: 'Industry-Specific Questions',
      description: 'Prepare with tailored question sets for your specific industry, role level, and desired position.',
      icon: MessageSquare,
      color: 'bg-pink-500'
    },
    {
      title: 'Expert Interview Techniques',
      description: 'Learn proven strategies and frameworks for answering even the most challenging interview questions.',
      icon: Award,
      color: 'bg-teal-500'
    },
    {
      title: 'Community & Benchmarking',
      description: 'Compare your performance against industry benchmarks and connect with others in your field.',
      icon: Users,
      color: 'bg-amber-500'
    }
  ];

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Powerful Features to Ace Your Interviews
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our platform combines advanced AI technology with proven interview strategies 
            to help you prepare effectively and confidently.
          </p>
        </motion.div>
        
        <motion.div 
          className="grid gap-8 md:grid-cols-2 lg:grid-cols-3"
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-100px" }}
        >
          {features.map((feature, index) => (
            <motion.div
              key={index}
              variants={item}
              className="group"
            >
              <div className="bg-white border border-gray-200 rounded-2xl shadow-sm p-8 h-full hover:shadow-lg transition-shadow duration-300">
                <div className={`${feature.color} w-14 h-14 rounded-xl flex items-center justify-center mb-6 text-white transform group-hover:scale-110 transition-transform duration-300`}>
                  <feature.icon size={24} />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};