import React, { useState, useEffect } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, Mic, Check, Play } from 'lucide-react';
import { Button } from '../ui/Button';
import { useAuth } from '../../hooks/useAuth';

export const HeroSection: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { scrollYProgress } = useScroll();
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);
  const y = useTransform(scrollYProgress, [0, 0.5], [0, 100]);
  
  const [isLoaded, setIsLoaded] = useState(false);
  
  useEffect(() => {
    // Simulating content load
    const timer = setTimeout(() => {
      setIsLoaded(true);
    }, 300);
    
    return () => clearTimeout(timer);
  }, []);

  const features = [
    "AI-powered interview practice",
    "Real-time feedback & scoring",
    "Industry-specific question sets",
    "Voice interaction technology"
  ];

  return (
    <motion.section 
      className="relative overflow-hidden bg-gradient-to-b from-indigo-900 via-purple-900 to-purple-800 text-white min-h-screen flex flex-col justify-center"
      style={{ opacity, y }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      {/* Background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-indigo-500/20 via-transparent to-transparent"></div>
        
        {/* Grid pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px]"></div>
        
        {/* White circle image */}
        <motion.div
          className="absolute top-20 right-[10%] w-28 h-28 md:w-40 md:h-40 lg:w-48 lg:h-48 z-10"
          animate={{
            y: [0, -15, 0],
            rotate: [0, 5, 0],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <img 
            src="https://daily-story.org/white_circle_360x360.png" 
            alt="White circle" 
            className="w-full h-full object-contain"
          />
        </motion.div>
        
        {/* Animated orbs */}
        <motion.div
          className="absolute top-1/4 right-1/4 w-64 h-64 rounded-full bg-indigo-600/20 blur-3xl"
          animate={{
            x: [50, -50, 50],
            y: [20, -30, 20],
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <motion.div
          className="absolute bottom-1/3 left-1/4 w-80 h-80 rounded-full bg-purple-600/20 blur-3xl"
          animate={{
            x: [-50, 50, -50],
            y: [-20, 40, -20],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 18,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      </div>
      
      <div className="container mx-auto px-6 z-10 py-20">
        <div className="max-w-4xl mx-auto text-center mb-16">
          {/* Hero badge */}
          <motion.div
            className="inline-flex items-center px-3 py-1.5 rounded-full bg-white/10 backdrop-blur-sm mb-8 border border-white/20"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: isLoaded ? 1 : 0, y: isLoaded ? 0 : 20 }}
            transition={{ delay: 0.2, duration: 0.6 }}
          >
            <Mic className="w-4 h-4 text-indigo-300 mr-2" />
            <span className="text-sm font-medium">AI-Powered Interview Practice</span>
          </motion.div>
          
          {/* Hero title */}
          <motion.h1
            className="text-5xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight mb-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: isLoaded ? 1 : 0, y: isLoaded ? 0 : 30 }}
            transition={{ delay: 0.4, duration: 0.8 }}
          >
            Master Your Interview Skills with{' '}
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-violet-400">
              AI Coaching
            </span>
          </motion.h1>
          
          {/* Hero description */}
          <motion.p
            className="text-lg sm:text-xl text-indigo-100 mb-12 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: isLoaded ? 1 : 0, y: isLoaded ? 0 : 30 }}
            transition={{ delay: 0.6, duration: 0.8 }}
          >
            Practice interviews with our advanced AI system that provides real-time feedback, 
            personalized coaching, and detailed performance analytics to help you land your dream job.
          </motion.p>
          
          {/* Hero CTA */}
          <motion.div
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: isLoaded ? 1 : 0, y: isLoaded ? 0 : 30 }}
            transition={{ delay: 0.8, duration: 0.8 }}
          >
            {user ? (
              <Button 
                size="lg"
                icon={<Play className="w-5 h-5" />}
                onClick={() => navigate('/setup')}
                className="px-8 py-4 text-lg bg-white text-indigo-800 hover:bg-gray-100"
              >
                Start Practice Interview
              </Button>
            ) : (
              <>
                <Button 
                  size="lg"
                  onClick={() => navigate('/signup')}
                  className="px-8 py-4 text-lg bg-white text-indigo-800 hover:bg-gray-100"
                  icon={<ArrowRight className="w-5 h-5" />}
                  iconPosition="right"
                >
                  Get Started
                </Button>
                <Button 
                  size="lg" 
                  variant="outline"
                  onClick={() => navigate('/login')}
                  className="px-8 py-4 text-lg border-white text-white hover:bg-white/10"
                >
                  Sign In
                </Button>
              </>
            )}
          </motion.div>
        </div>
        
        {/* Features list */}
        <motion.div
          className="grid sm:grid-cols-2 md:grid-cols-4 gap-6 max-w-5xl mx-auto"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: isLoaded ? 1 : 0, y: isLoaded ? 0 : 50 }}
          transition={{ delay: 1, duration: 0.8 }}
        >
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="flex items-center space-x-3 backdrop-blur-sm bg-white/5 rounded-xl p-4 border border-white/10"
            >
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center">
                <Check className="w-4 h-4 text-indigo-300" />
              </div>
              <div className="absolute -bottom-4 left-1/2 transform -translate-x-1/2 w-full">
                <span className="bg-white/20 text-white/90 text-xs px-3 py-1 rounded-full backdrop-blur-sm">
                  Now with enhanced AI interviewer
                </span>
              </div>
              <span className="text-sm sm:text-base font-medium text-white">{feature}</span>
            </div>
          ))}
        </motion.div>
        
        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-10 left-1/2 transform -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <div className="flex flex-col items-center">
            <span className="text-sm text-indigo-200 mb-2">Scroll to explore</span>
            <div className="w-6 h-10 border-2 border-indigo-300 rounded-full flex justify-center">
              <motion.div 
                className="w-1.5 h-1.5 bg-white rounded-full mt-2"
                animate={{ y: [0, 15, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              />
            </div>
          </div>
        </motion.div>
      </div>
    </motion.section>
  );
};