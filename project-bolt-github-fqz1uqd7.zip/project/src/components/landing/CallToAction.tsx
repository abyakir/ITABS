import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Award } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '../ui/Button';
import { useAuth } from '../../hooks/useAuth';

export const CallToAction: React.FC = () => {
  const { user } = useAuth();

  return (
    <section className="py-20 bg-gradient-to-br from-indigo-900 via-blue-800 to-indigo-900 text-white overflow-hidden relative">
      {/* Background elements */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:40px_40px]"></div>
        
        <motion.div
          className="absolute -left-20 -bottom-20 w-80 h-80 rounded-full bg-blue-600/20 blur-3xl"
          animate={{
            x: [0, 40, 0],
            y: [0, -20, 0],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <motion.div
          className="absolute -right-20 -top-20 w-80 h-80 rounded-full bg-indigo-600/20 blur-3xl"
          animate={{
            x: [0, -30, 0],
            y: [0, 30, 0],
          }}
          transition={{
            duration: 18,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto text-center"
        >
          <div className="inline-flex items-center mb-6 px-4 py-2 bg-white/10 rounded-full backdrop-blur-sm">
            <Award className="w-5 h-5 text-indigo-300 mr-2" />
            <span className="text-indigo-100 font-medium">Start practicing today</span>
          </div>
          
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Ready to Ace Your Next Interview?
          </h2>
          
          <p className="text-xl text-indigo-100 mb-10 max-w-2xl mx-auto">
            Join thousands of professionals who are landing their dream jobs after 
            practicing with our AI interview coach.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {user ? (
              <Link to="/setup">
                <Button 
                  size="lg" 
                  className="px-8 py-4 text-lg font-medium bg-white text-indigo-700 hover:bg-gray-100"
                  icon={<ArrowRight className="w-5 h-5" />}
                  iconPosition="right"
                >
                  Start Practicing Now
                </Button>
              </Link>
            ) : (
              <>
                <Link to="/signup">
                  <Button 
                    size="lg" 
                    className="px-8 py-4 text-lg font-medium bg-white text-indigo-700 hover:bg-gray-100"
                    icon={<ArrowRight className="w-5 h-5" />}
                    iconPosition="right"
                  >
                    Get Started for Free
                  </Button>
                </Link>
                <Link to="/login">
                  <Button 
                    size="lg" 
                    variant="outline"
                    className="px-8 py-4 text-lg border-2 border-white/80 text-white hover:bg-white/10"
                  >
                    Sign In
                  </Button>
                </Link>
              </>
            )}
          </div>
          
          <p className="mt-6 text-indigo-200">
            No credit card required • Free basic plan • Cancel anytime
          </p>
        </motion.div>
      </div>
    </section>
  );
};