import React from 'react';
import { Shield, Lock, Database, Download } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { useSettings } from '../../hooks/useSettings';
import { useProfile } from '../../hooks/useProfile';
import toast from 'react-hot-toast';

export const PrivacySettings: React.FC = () => {
  const { preferences, loading, updatePreference } = useSettings();
  const { exportData } = useProfile();
  
  const handlePrivacyModeChange = async (mode: string) => {
    try {
      await updatePreference('privacy_mode', mode as any);
      toast.success('Privacy mode updated');
    } catch (error) {
      toast.error('Failed to update privacy mode');
    }
  };
  
  const handleToggleChange = async (key: string, value: boolean) => {
    try {
      await updatePreference(key as any, value);
    } catch (error) {
      toast.error(`Failed to update ${key}`);
    }
  };
  
  const handleExportData = async () => {
    try {
      await exportData();
    } catch (error) {
      toast.error('Failed to export data');
    }
  };
  
  if (loading) {
    return <div className="animate-pulse h-48 bg-gray-200 rounded-xl"></div>;
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div className="flex items-center">
            <Shield className="w-5 h-5 mr-2 text-indigo-600" />
            <CardTitle>Privacy Controls</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-3">Privacy Mode</h3>
            <div className="grid grid-cols-1 gap-3">
              {[
                { 
                  id: 'minimal', 
                  title: 'Minimal Data Collection', 
                  description: 'Only essential data is collected to provide the core interview functionality.' 
                },
                { 
                  id: 'standard', 
                  title: 'Standard (Recommended)', 
                  description: 'Balanced approach with enough data collection to provide personalized feedback and insights.' 
                },
                { 
                  id: 'enhanced', 
                  title: 'Enhanced Features', 
                  description: 'Full data collection for maximum personalization and advanced features.' 
                },
              ].map((mode) => (
                <div
                  key={mode.id}
                  onClick={() => handlePrivacyModeChange(mode.id)}
                  className={`
                    cursor-pointer rounded-lg border-2 p-4 transition-colors
                    ${preferences?.privacy_mode === mode.id 
                      ? 'border-indigo-600 bg-indigo-50' 
                      : 'border-gray-200 hover:border-gray-300'
                    }
                  `}
                >
                  <h4 className={`text-sm font-medium mb-1 ${preferences?.privacy_mode === mode.id ? 'text-indigo-700' : 'text-gray-900'}`}>
                    {mode.title}
                  </h4>
                  <p className="text-xs text-gray-500">{mode.description}</p>
                </div>
              ))}
            </div>
          </div>
          
          <div className="space-y-4 pt-2">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-medium text-gray-900">Camera Verification</h4>
                <p className="text-xs text-gray-500 mt-1">Verify camera is working before interviews</p>
              </div>
              <div className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-200">
                <input
                  type="checkbox"
                  className="peer sr-only"
                  checked={preferences?.camera_verification_enabled || false}
                  onChange={(e) => handleToggleChange('camera_verification_enabled', e.target.checked)}
                  id="camera-verification"
                />
                <span className={`
                  absolute inset-y-0.5 left-0.5 right-0.5 peer-checked:bg-indigo-600 rounded-full transition
                  ${preferences?.camera_verification_enabled ? 'bg-indigo-600' : 'bg-gray-200'}
                `} />
                <span className={`
                  absolute inset-y-1 left-1 h-4 w-4 rounded-full bg-white transition-all
                  ${preferences?.camera_verification_enabled ? 'translate-x-5' : 'translate-x-0'}
                `} />
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-medium text-gray-900">Face Detection</h4>
                <p className="text-xs text-gray-500 mt-1">Use AI to detect presence during video interviews</p>
              </div>
              <div className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-200">
                <input
                  type="checkbox"
                  className="peer sr-only"
                  checked={preferences?.face_detection_enabled || false}
                  onChange={(e) => handleToggleChange('face_detection_enabled', e.target.checked)}
                  id="face-detection"
                />
                <span className={`
                  absolute inset-y-0.5 left-0.5 right-0.5 peer-checked:bg-indigo-600 rounded-full transition
                  ${preferences?.face_detection_enabled ? 'bg-indigo-600' : 'bg-gray-200'}
                `} />
                <span className={`
                  absolute inset-y-1 left-1 h-4 w-4 rounded-full bg-white transition-all
                  ${preferences?.face_detection_enabled ? 'translate-x-5' : 'translate-x-0'}
                `} />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div className="flex items-center">
            <Database className="w-5 h-5 mr-2 text-indigo-600" />
            <CardTitle>Data Management</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="p-4 bg-indigo-50 rounded-lg border border-indigo-100">
            <div className="flex space-x-3">
              <Lock className="w-5 h-5 text-indigo-600 flex-shrink-0" />
              <div>
                <h4 className="text-sm font-medium text-indigo-900">Data Privacy Notice</h4>
                <p className="text-xs text-indigo-700 mt-1 mb-3">
                  Interview recordings and transcripts are processed to provide personalized feedback.
                  All data is encrypted and stored securely according to our privacy policy.
                </p>
                <div className="text-xs text-indigo-700">
                  <span className="font-medium">Data usage includes:</span>
                  <ul className="list-disc list-inside mt-1 space-y-1">
                    <li>Interview recordings for feedback generation</li>
                    <li>Performance metrics for progress tracking</li>
                    <li>User preferences for personalization</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          
          <Button 
            variant="outline"
            size="sm"
            onClick={handleExportData}
            icon={<Download className="w-4 h-4 mr-2" />}
          >
            Export My Data
          </Button>
          
          <div className="border-t border-gray-200 pt-5">
            <h4 className="text-sm font-medium text-gray-900 mb-2">Data Retention</h4>
            <p className="text-sm text-gray-500 mb-4">
              Interview recordings and transcripts are stored for 90 days by default. After this period, they are automatically anonymized.
            </p>
            
            <div className="text-xs text-gray-500">
              <p>For more information about how we handle your data, please read our:</p>
              <div className="flex space-x-4 mt-2">
                <a href="#" className="text-indigo-600 hover:text-indigo-800">Privacy Policy</a>
                <a href="#" className="text-indigo-600 hover:text-indigo-800">Terms of Service</a>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};