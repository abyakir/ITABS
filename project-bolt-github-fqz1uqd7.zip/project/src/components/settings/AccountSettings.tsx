import React, { useState } from 'react';
import { Lock, Mail, User, Shield, AlertCircle } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Badge } from '../ui/Badge';
import { Modal } from '../ui/Modal';
import { useAuth } from '../../hooks/useAuth';
import toast from 'react-hot-toast';

export const AccountSettings: React.FC = () => {
  const { user, updateEmail, updatePassword, deleteAccount } = useAuth();
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [newEmail, setNewEmail] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [deleteConfirmation, setDeleteConfirmation] = useState('');

  const handleEmailChange = async () => {
    if (!newEmail) {
      toast.error('Please enter a new email address');
      return;
    }

    try {
      setLoading(true);
      await updateEmail(newEmail);
      toast.success('Email updated successfully. Please check your inbox to confirm.');
      setIsEmailModalOpen(false);
    } catch (error) {
      console.error('Failed to update email:', error);
      toast.error('Failed to update email. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordChange = async () => {
    if (!currentPassword) {
      toast.error('Please enter your current password');
      return;
    }
    
    if (!newPassword) {
      toast.error('Please enter a new password');
      return;
    }
    
    if (newPassword !== confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    
    if (newPassword.length < 8) {
      toast.error('Password must be at least 8 characters');
      return;
    }

    try {
      setLoading(true);
      await updatePassword(currentPassword, newPassword);
      toast.success('Password updated successfully');
      setIsPasswordModalOpen(false);
    } catch (error) {
      console.error('Failed to update password:', error);
      toast.error('Failed to update password. Please check your current password.');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAccount = async () => {
    if (deleteConfirmation !== 'DELETE') {
      toast.error('Please type DELETE to confirm account deletion');
      return;
    }

    try {
      setLoading(true);
      await deleteAccount();
      toast.success('Account deleted successfully');
      // Redirect to home page will be handled by the auth hook
    } catch (error) {
      console.error('Failed to delete account:', error);
      toast.error('Failed to delete account. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="flex items-center">
            <User className="w-5 h-5 mr-2 text-indigo-600" />
            <CardTitle>Account Information</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-gray-200">
              <div>
                <h3 className="text-sm font-medium text-gray-900">Email Address</h3>
                <p className="text-gray-500 mt-1">{user?.email}</p>
              </div>
              <Button 
                variant="outline" 
                onClick={() => setIsEmailModalOpen(true)}
              >
                Change Email
              </Button>
            </div>
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-gray-200">
              <div>
                <h3 className="text-sm font-medium text-gray-900">Password</h3>
                <p className="text-gray-500 mt-1">••••••••••••••</p>
              </div>
              <Button 
                variant="outline" 
                onClick={() => setIsPasswordModalOpen(true)}
              >
                Change Password
              </Button>
            </div>
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-medium text-gray-900">Account Status</h3>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant="success">Active</Badge>
                  <p className="text-gray-500">Since {new Date(user?.created_at || Date.now()).toLocaleDateString()}</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="flex items-center">
            <Shield className="w-5 h-5 mr-2 text-red-600" />
            <CardTitle>Danger Zone</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-medium text-red-800">Delete Account</h3>
                <p className="text-red-600 mt-1">
                  Permanently delete your account and all of your data. This action cannot be undone.
                </p>
              </div>
              <Button 
                variant="danger"
                onClick={() => setIsDeleteModalOpen(true)}
              >
                Delete Account
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Email Change Modal */}
      <Modal
        isOpen={isEmailModalOpen}
        onClose={() => setIsEmailModalOpen(false)}
        title="Change Email Address"
        description="Enter your new email address below. You'll need to verify this email before the change takes effect."
      >
        <div className="space-y-4">
          <Input
            label="Current Email"
            value={user?.email || ''}
            disabled
            leftIcon={<Mail className="w-5 h-5" />}
          />
          <Input
            label="New Email"
            value={newEmail}
            onChange={(e) => setNewEmail(e.target.value)}
            placeholder="Enter new email address"
            leftIcon={<Mail className="w-5 h-5" />}
            type="email"
          />
          <div className="flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2 mt-5">
            <Button 
              variant="outline" 
              onClick={() => setIsEmailModalOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleEmailChange}
              loading={loading}
            >
              Update Email
            </Button>
          </div>
        </div>
      </Modal>

      {/* Password Change Modal */}
      <Modal
        isOpen={isPasswordModalOpen}
        onClose={() => setIsPasswordModalOpen(false)}
        title="Change Password"
        description="Enter your current password and a new password below."
      >
        <div className="space-y-4">
          <Input
            label="Current Password"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            type="password"
            leftIcon={<Lock className="w-5 h-5" />}
          />
          <Input
            label="New Password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            type="password"
            leftIcon={<Lock className="w-5 h-5" />}
            helperText="Password must be at least 8 characters"
          />
          <Input
            label="Confirm New Password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            type="password"
            leftIcon={<Lock className="w-5 h-5" />}
          />
          <div className="flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2 mt-5">
            <Button 
              variant="outline" 
              onClick={() => setIsPasswordModalOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={handlePasswordChange}
              loading={loading}
            >
              Update Password
            </Button>
          </div>
        </div>
      </Modal>

      {/* Delete Account Modal */}
      <Modal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        title="Delete Account"
        description="This action cannot be undone. All of your data will be permanently removed."
      >
        <div className="space-y-4">
          <div className="bg-red-50 p-4 rounded-lg flex items-start space-x-3">
            <AlertCircle className="w-5 h-5 text-red-600 mt-0.5" />
            <div>
              <h4 className="text-sm font-medium text-red-800">Warning</h4>
              <p className="text-sm text-red-600 mt-1">
                Deleting your account will permanently remove all of your data, including interview history, 
                scores, and profile information. This action cannot be undone.
              </p>
            </div>
          </div>
          
          <Input
            label="Type DELETE to confirm"
            value={deleteConfirmation}
            onChange={(e) => setDeleteConfirmation(e.target.value)}
            placeholder="DELETE"
          />
          
          <div className="flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2 mt-5">
            <Button 
              variant="outline" 
              onClick={() => setIsDeleteModalOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              variant="danger" 
              onClick={handleDeleteAccount}
              loading={loading}
              disabled={deleteConfirmation !== 'DELETE'}
            >
              Delete Account
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};