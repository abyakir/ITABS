import React, { useEffect, useState } from 'react';
import { Bell, Clock, TrendingUp, Info, Check } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { useSettings } from '../../hooks/useSettings';
import toast from 'react-hot-toast';

interface ToggleProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  disabled?: boolean;
}

const Toggle: React.FC<ToggleProps> = ({ checked, onChange, disabled = false }) => {
  return (
    <button
      type="button"
      className={`
        relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer 
        transition-colors ease-in-out duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500
        ${disabled ? 'opacity-50 cursor-not-allowed' : ''}
        ${checked ? 'bg-indigo-600' : 'bg-gray-200'}
      `}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      role="switch"
      aria-checked={checked}
    >
      <span
        aria-hidden="true"
        className={`
          pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200
          ${checked ? 'translate-x-5' : 'translate-x-0'}
        `}
      />
    </button>
  );
};

export const NotificationSettings: React.FC = () => {
  const { preferences, loading, updatePreference } = useSettings();
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>('default');
  const [permissionRequesting, setPermissionRequesting] = useState(false);

  useEffect(() => {
    // Check browser notification permission status
    if ('Notification' in window) {
      setNotificationPermission(Notification.permission);
    }
  }, []);

  const handleToggleChange = async (key: string, value: boolean) => {
    try {
      await updatePreference(key as any, value);
    } catch (error) {
      console.error(`Failed to update ${key}:`, error);
      toast.error(`Failed to update setting`);
    }
  };

  const requestNotificationPermission = async () => {
    if (!('Notification' in window)) {
      toast.error('This browser does not support desktop notification');
      return;
    }

    try {
      setPermissionRequesting(true);
      const permission = await Notification.requestPermission();
      setNotificationPermission(permission);
      
      if (permission === 'granted') {
        toast.success('Notifications enabled');
        // Show a test notification
        new Notification('Notifications Enabled', {
          body: 'You will now receive notifications from Maximum Interview',
          icon: '/favicon.ico'
        });
      } else {
        toast.error('Notification permission denied');
      }
    } catch (error) {
      console.error('Error requesting notification permission:', error);
      toast.error('Failed to request notification permission');
    } finally {
      setPermissionRequesting(false);
    }
  };

  if (loading) {
    return <div className="animate-pulse h-48 bg-gray-200 rounded-xl"></div>;
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div className="flex items-center">
          <Bell className="w-5 h-5 mr-2 text-indigo-600" />
          <CardTitle>Notification Settings</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Browser notification permission */}
          <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
            <div className="flex items-start space-x-3">
              <Info className="w-5 h-5 text-indigo-600 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium text-gray-900">Browser Notifications</h4>
                <p className="text-sm text-gray-600 mt-1 mb-3">
                  Enable browser notifications to receive alerts about upcoming interviews and results.
                </p>
                <div className="flex items-center space-x-2">
                  {notificationPermission === 'granted' ? (
                    <div className="flex items-center space-x-2 text-green-600">
                      <Check className="w-5 h-5" />
                      <span className="font-medium">Notifications enabled</span>
                    </div>
                  ) : (
                    <Button
                      onClick={requestNotificationPermission}
                      loading={permissionRequesting}
                      size="sm"
                    >
                      Enable Notifications
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
          
          <div className="divide-y divide-gray-200">
            {/* Email Notifications */}
            <div className="flex items-center justify-between py-4">
              <div>
                <h4 className="text-sm font-medium text-gray-900">Email Notifications</h4>
                <p className="text-sm text-gray-500 mt-1">Receive updates and notifications via email</p>
              </div>
              <Toggle
                checked={preferences?.email_notifications || false}
                onChange={(checked) => handleToggleChange('email_notifications', checked)}
              />
            </div>
            
            {/* Interview Reminders */}
            <div className="flex items-center justify-between py-4">
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-gray-500" />
                <div>
                  <h4 className="text-sm font-medium text-gray-900">Interview Reminders</h4>
                  <p className="text-sm text-gray-500 mt-1">Get reminded about your scheduled interviews</p>
                </div>
              </div>
              <Toggle
                checked={preferences?.interview_reminders || false}
                onChange={(checked) => handleToggleChange('interview_reminders', checked)}
              />
            </div>
            
            {/* Performance Insights */}
            <div className="flex items-center justify-between py-4">
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-4 h-4 text-gray-500" />
                <div>
                  <h4 className="text-sm font-medium text-gray-900">Performance Insights</h4>
                  <p className="text-sm text-gray-500 mt-1">Receive weekly summaries of your interview performance</p>
                </div>
              </div>
              <Toggle
                checked={preferences?.performance_insights || false}
                onChange={(checked) => handleToggleChange('performance_insights', checked)}
              />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};