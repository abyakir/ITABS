import React, { useState, useEffect } from 'react';
import { Palette, Sun, Moon, Monitor, Check } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '../ui/Card';
import { Button } from '../ui/Button';
import { useSettings } from '../../hooks/useSettings';
import toast from 'react-hot-toast';

export const AppearanceSettings: React.FC = () => {
  const { preferences, loading, updatePreference } = useSettings();
  const [selectedTheme, setSelectedTheme] = useState('light');
  const [selectedFontSize, setSelectedFontSize] = useState('medium');
  const [changes, setChanges] = useState(false);
  
  useEffect(() => {
    if (preferences) {
      setSelectedTheme(preferences.theme_preference || 'light');
      setSelectedFontSize(preferences.font_size || 'medium');
    }
  }, [preferences]);
  
  const handleThemeChange = (theme: string) => {
    setSelectedTheme(theme);
    setChanges(true);
  };
  
  const handleFontSizeChange = (size: string) => {
    setSelectedFontSize(size);
    setChanges(true);
  };
  
  const saveChanges = async () => {
    try {
      await updatePreference('theme_preference', selectedTheme as any);
      await updatePreference('font_size', selectedFontSize as any);
      setChanges(false);
      toast.success('Appearance settings saved');
    } catch (error) {
      toast.error('Failed to save appearance settings');
    }
  };
  
  if (loading) {
    return <div className="animate-pulse h-48 bg-gray-200 rounded-xl"></div>;
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div className="flex items-center">
          <Palette className="w-5 h-5 mr-2 text-indigo-600" />
          <CardTitle>Appearance</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-8">
        <div>
          <h3 className="text-sm font-medium text-gray-900 mb-3">Theme</h3>
          <div className="grid grid-cols-3 gap-3">
            {[
              { id: 'light', name: 'Light', icon: Sun },
              { id: 'dark', name: 'Dark', icon: Moon },
              { id: 'auto', name: 'System', icon: Monitor }
            ].map((theme) => (
              <div
                key={theme.id}
                className={`
                  relative rounded-lg border-2 p-4 flex flex-col items-center cursor-pointer
                  ${selectedTheme === theme.id 
                    ? 'border-indigo-600 bg-indigo-50' 
                    : 'border-gray-200 hover:border-gray-300'
                  }
                `}
                onClick={() => handleThemeChange(theme.id)}
              >
                <theme.icon className={`
                  w-8 h-8 mb-2
                  ${selectedTheme === theme.id ? 'text-indigo-600' : 'text-gray-500'}
                `} />
                <span className={`
                  text-sm font-medium
                  ${selectedTheme === theme.id ? 'text-indigo-600' : 'text-gray-700'}
                `}>
                  {theme.name}
                </span>
                
                {selectedTheme === theme.id && (
                  <div className="absolute top-2 right-2 w-5 h-5 bg-indigo-600 rounded-full flex items-center justify-center">
                    <Check className="w-3 h-3 text-white" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
        
        <div>
          <h3 className="text-sm font-medium text-gray-900 mb-3">Font Size</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { id: 'small', name: 'Small' },
              { id: 'medium', name: 'Medium' },
              { id: 'large', name: 'Large' },
              { id: 'extra-large', name: 'Extra Large' }
            ].map((size) => (
              <div
                key={size.id}
                className={`
                  relative rounded-lg border-2 p-4 flex flex-col items-center cursor-pointer
                  ${selectedFontSize === size.id 
                    ? 'border-indigo-600 bg-indigo-50' 
                    : 'border-gray-200 hover:border-gray-300'
                  }
                `}
                onClick={() => handleFontSizeChange(size.id)}
              >
                <span className={`
                  ${size.id === 'small' ? 'text-xs' :
                   size.id === 'medium' ? 'text-sm' :
                   size.id === 'large' ? 'text-base' :
                   'text-lg'}
                  font-medium
                  ${selectedFontSize === size.id ? 'text-indigo-600' : 'text-gray-700'}
                `}>
                  {size.name}
                </span>
                
                {selectedFontSize === size.id && (
                  <div className="absolute top-2 right-2 w-5 h-5 bg-indigo-600 rounded-full flex items-center justify-center">
                    <Check className="w-3 h-3 text-white" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
        
        <div>
          <h3 className="text-sm font-medium text-gray-900 mb-3">Accessibility</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-medium text-gray-900">High Contrast</h4>
                <p className="text-xs text-gray-500 mt-1">Increase contrast for better readability</p>
              </div>
              <div className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-200">
                <input
                  type="checkbox"
                  className="peer sr-only"
                  checked={preferences?.high_contrast || false}
                  onChange={(e) => updatePreference('high_contrast', e.target.checked)}
                  id="high-contrast"
                />
                <span className={`
                  absolute inset-y-0.5 left-0.5 right-0.5 peer-checked:bg-indigo-600 rounded-full transition
                  ${preferences?.high_contrast ? 'bg-indigo-600' : 'bg-gray-200'}
                `} />
                <span className={`
                  absolute inset-y-1 left-1 h-4 w-4 rounded-full bg-white transition-all
                  ${preferences?.high_contrast ? 'translate-x-5' : 'translate-x-0'}
                `} />
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-medium text-gray-900">Reduce Motion</h4>
                <p className="text-xs text-gray-500 mt-1">Minimize animations and transitions</p>
              </div>
              <div className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-200">
                <input
                  type="checkbox"
                  className="peer sr-only"
                  checked={preferences?.reduce_motion || false}
                  onChange={(e) => updatePreference('reduce_motion', e.target.checked)}
                  id="reduce-motion"
                />
                <span className={`
                  absolute inset-y-0.5 left-0.5 right-0.5 peer-checked:bg-indigo-600 rounded-full transition
                  ${preferences?.reduce_motion ? 'bg-indigo-600' : 'bg-gray-200'}
                `} />
                <span className={`
                  absolute inset-y-1 left-1 h-4 w-4 rounded-full bg-white transition-all
                  ${preferences?.reduce_motion ? 'translate-x-5' : 'translate-x-0'}
                `} />
              </div>
            </div>
          </div>
        </div>
      </CardContent>
      {changes && (
        <CardFooter className="border-t pt-6">
          <div className="flex justify-end space-x-3">
            <Button
              variant="outline"
              onClick={() => {
                setSelectedTheme(preferences?.theme_preference || 'light');
                setSelectedFontSize(preferences?.font_size || 'medium');
                setChanges(false);
              }}
            >
              Cancel
            </Button>
            <Button onClick={saveChanges}>
              Save Changes
            </Button>
          </div>
        </CardFooter>
      )}
    </Card>
  );
};