import React, { useState } from 'react';
import { Mic, Volume2 } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { useSettings } from '../../hooks/useSettings';
import toast from 'react-hot-toast';

export const InterviewSettings: React.FC = () => {
  const { preferences, loading, updatePreference } = useSettings();
  
  const voiceOptions = [
    { id: '21m00Tcm4TlvDq8ikWAM', name: 'Rachel (Default)' },
    { id: 'EXAVITQu4vr4xnSDxMaL', name: 'Alex' },
    { id: 'ErXwobaYiN019PkySvjV', name: 'Sarah' },
    { id: 'VR6AewLTigWG4xSOukaG', name: 'Michael' },
  ];
  
  const handleSliderChange = async (event: React.ChangeEvent<HTMLInputElement>, key: string) => {
    const value = parseFloat(event.target.value);
    try {
      await updatePreference(key as any, value);
    } catch (error) {
      toast.error(`Failed to update ${key}`);
    }
  };
  
  const handleVoiceChange = async (voiceId: string) => {
    try {
      await updatePreference('voice_id', voiceId);
      toast.success('Voice updated');
    } catch (error) {
      toast.error('Failed to update voice');
    }
  };
  
  const handleQualityChange = async (event: React.ChangeEvent<HTMLSelectElement>) => {
    try {
      await updatePreference('video_quality', event.target.value);
    } catch (error) {
      toast.error('Failed to update video quality');
    }
  };
  
  const handleToggleChange = async (key: string, value: boolean) => {
    try {
      await updatePreference(key as any, value);
    } catch (error) {
      toast.error(`Failed to update ${key}`);
    }
  };
  
  if (loading) {
    return <div className="animate-pulse h-48 bg-gray-200 rounded-xl"></div>;
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div className="flex items-center">
            <Mic className="w-5 h-5 mr-2 text-indigo-600" />
            <CardTitle>Audio Settings</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-900 mb-3">Interviewer Voice</label>
            <div className="grid grid-cols-2 gap-3">
              {voiceOptions.map(voice => (
                <button
                  key={voice.id}
                  className={`
                    relative border-2 rounded-lg p-4 text-left transition-all
                    ${preferences?.voice_id === voice.id 
                      ? 'border-indigo-600 bg-indigo-50' 
                      : 'border-gray-200 hover:border-gray-300'
                    }
                  `}
                  onClick={() => handleVoiceChange(voice.id)}
                >
                  <div className="font-medium text-gray-900">{voice.name}</div>
                  <div className="mt-1 flex items-center text-gray-500 text-sm">
                    <Volume2 className="w-4 h-4 mr-1" />
                    <span>Preview</span>
                  </div>
                  
                  {preferences?.voice_id === voice.id && (
                    <div className="absolute top-2 right-2 w-2 h-2 bg-indigo-600 rounded-full"></div>
                  )}
                </button>
              ))}
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-900 mb-2">
              Speech Speed
            </label>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-500">Slower</span>
              <input
                type="range"
                min="0.5"
                max="2"
                step="0.1"
                value={preferences?.speech_speed || 1.0}
                onChange={(e) => handleSliderChange(e, 'speech_speed')}
                className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
              <span className="text-sm text-gray-500">Faster</span>
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
              Current: {preferences?.speech_speed || 1.0}x
            </p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-900 mb-2">
              Microphone Sensitivity
            </label>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-500">Low</span>
              <input
                type="range"
                min="0"
                max="100"
                value={preferences?.microphone_sensitivity || 75}
                onChange={(e) => handleSliderChange(e, 'microphone_sensitivity')}
                className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
              <span className="text-sm text-gray-500">High</span>
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
              {preferences?.microphone_sensitivity || 75}%
            </p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-900 mb-2">Noise Cancellation</label>
            <select
              value={preferences?.noise_cancellation || 'auto'}
              onChange={(e) => updatePreference('noise_cancellation', e.target.value)}
              className="block w-full rounded-lg border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option value="auto">Automatic</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
              <option value="off">Off</option>
            </select>
            <p className="text-xs text-gray-500 mt-1">
              Higher settings provide better noise reduction but may affect voice quality
            </p>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle>Video Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-900 mb-2">Video Quality</label>
            <select
              value={preferences?.video_quality || 'auto'}
              onChange={handleQualityChange}
              className="block w-full rounded-lg border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option value="auto">Automatic</option>
              <option value="hd">HD (720p)</option>
              <option value="standard">Standard (480p)</option>
              <option value="low">Low (360p)</option>
            </select>
            <p className="text-xs text-gray-500 mt-1">
              Lower quality settings use less bandwidth
            </p>
          </div>
          
          <div className="flex items-center justify-between pt-4">
            <div>
              <h4 className="text-sm font-medium text-gray-900">Mirror Video</h4>
              <p className="text-xs text-gray-500 mt-1">Show your video mirrored (like looking in a mirror)</p>
            </div>
            <div className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-200">
              <input
                type="checkbox"
                className="peer sr-only"
                checked={preferences?.mirror_video || false}
                onChange={(e) => handleToggleChange('mirror_video', e.target.checked)}
                id="mirror-video"
              />
              <span className={`
                absolute inset-y-0.5 left-0.5 right-0.5 peer-checked:bg-indigo-600 rounded-full transition
                ${preferences?.mirror_video ? 'bg-indigo-600' : 'bg-gray-200'}
              `} />
              <span className={`
                absolute inset-y-1 left-1 h-4 w-4 rounded-full bg-white transition-all
                ${preferences?.mirror_video ? 'translate-x-5' : 'translate-x-0'}
              `} />
            </div>
          </div>
          
          <div className="flex items-center justify-between pt-4">
            <div>
              <h4 className="text-sm font-medium text-gray-900">Live Captions</h4>
              <p className="text-xs text-gray-500 mt-1">Show captions during interviews</p>
            </div>
            <div className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-200">
              <input
                type="checkbox"
                className="peer sr-only"
                checked={preferences?.live_captions || false}
                onChange={(e) => handleToggleChange('live_captions', e.target.checked)}
                id="live-captions"
              />
              <span className={`
                absolute inset-y-0.5 left-0.5 right-0.5 peer-checked:bg-indigo-600 rounded-full transition
                ${preferences?.live_captions ? 'bg-indigo-600' : 'bg-gray-200'}
              `} />
              <span className={`
                absolute inset-y-1 left-1 h-4 w-4 rounded-full bg-white transition-all
                ${preferences?.live_captions ? 'translate-x-5' : 'translate-x-0'}
              `} />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};