import React, { useState } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  LayoutDashboard, 
  User, 
  Settings, 
  LogOut, 
  Menu, 
  X, 
  ChevronRight, 
  Bell, 
  Search, 
  Mic 
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { Button } from '../ui/Button';
import { Avatar } from '../ui/Avatar';

interface DashboardLayoutProps {
  children: React.ReactNode;
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children }) => {
  const { user, signOut } = useAuth();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  const navigationItems = [
    { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
    { name: 'Profile', href: '/profile', icon: User },
    { name: 'Settings', href: '/settings', icon: Settings },
  ];
  
  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <div className="h-screen flex overflow-hidden bg-gray-50">
      {/* Mobile sidebar backdrop */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-20 bg-black bg-opacity-50 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}
      </AnimatePresence>
      
      {/* Sidebar */}
      <AnimatePresence>
        <motion.aside
          className={`fixed inset-y-0 left-0 z-30 w-64 bg-white shadow-lg transform lg:translate-x-0 lg:relative lg:flex-shrink-0 transition-transform duration-300 ease-in-out ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}
          initial={false}
        >
          <div className="flex flex-col h-full">
            {/* Sidebar header */}
            <div className="flex items-center justify-between h-16 px-6 border-b border-gray-200">
              <Link to="/" className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-full flex items-center justify-center">
                  <Mic className="w-4 h-4 text-white" />
                </div>
                <span className="text-lg font-bold text-gray-900">Interview AI</span>
              </Link>
              <button
                className="p-1.5 rounded-md text-gray-500 hover:bg-gray-100 lg:hidden"
                onClick={() => setSidebarOpen(false)}
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Sidebar content */}
            <div className="flex-1 py-6 overflow-y-auto">
              <nav className="space-y-1 px-3">
                {navigationItems.map((item) => (
                  <Link
                    key={item.name}
                    to={item.href}
                    className={`
                      flex items-center px-3 py-2.5 text-sm font-medium rounded-lg group transition-all
                      ${isActive(item.href)
                        ? 'bg-blue-50 text-blue-700'
                        : 'text-gray-700 hover:bg-gray-100'}
                    `}
                  >
                    <item.icon className={`
                      mr-3 flex-shrink-0 h-5 w-5
                      ${isActive(item.href) ? 'text-blue-700' : 'text-gray-500 group-hover:text-gray-700'}
                    `} />
                    {item.name}
                    {isActive(item.href) && (
                      <ChevronRight className="ml-auto h-4 w-4 text-blue-500" />
                    )}
                  </Link>
                ))}
              </nav>
            </div>
            
            {/* User menu */}
            <div className="p-4 border-t border-gray-200">
              <div className="flex items-center">
                <Avatar size="sm" src={user?.email} fallback={<User className="w-4 h-4" />} />
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">{user?.email}</p>
                  <button
                    onClick={() => signOut()}
                    className="text-xs text-gray-500 hover:text-gray-700 flex items-center mt-0.5"
                  >
                    <LogOut className="w-3 h-3 mr-1" />
                    Sign out
                  </button>
                </div>
              </div>
            </div>
          </div>
        </motion.aside>
      </AnimatePresence>
      
      {/* Main content */}
      <div className="flex flex-col flex-1 overflow-hidden">
        {/* Header */}
        <header className="bg-white shadow-sm lg:shadow z-10">
          <div className="px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
            <button
              className="p-2 rounded-md text-gray-500 hover:bg-gray-100 lg:hidden"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="w-5 h-5" />
            </button>
            
            <div className="flex-1 flex items-center justify-end space-x-4">
              {/* Search */}
              <div className="max-w-xs w-full lg:max-w-md relative hidden md:block">
                <input
                  type="text"
                  placeholder="Search..."
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                />
                <Search className="h-5 w-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
              </div>
              
              {/* Notifications */}
              <button className="p-2 rounded-full text-gray-500 hover:bg-gray-100 relative">
                <Bell className="h-5 w-5" />
                <span className="absolute top-1 right-1 block h-2 w-2 rounded-full bg-red-500 ring-2 ring-white"></span>
              </button>
              
              {/* Start Interview Button */}
              <Button size="sm" icon={<Mic className="w-4 h-4" />} onClick={() => window.location.href = '/setup'}>
                Start Interview
              </Button>
            </div>
          </div>
          
          {/* Breadcrumbs can go here */}
        </header>
        
        {/* Page content */}
        <main className="flex-1 overflow-auto bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;