import React from 'react';
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
  Tooltip
} from 'recharts';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/Card';

export interface SkillData {
  subject: string;
  value: number;
  fullMark: number;
}

interface SkillsRadarChartProps {
  data: SkillData[];
  title: string;
  description?: string;
  colors?: {
    area: string;
    grid: string;
  };
  className?: string;
}

export const SkillsRadarChart: React.FC<SkillsRadarChartProps> = ({
  data,
  title,
  description,
  colors = {
    area: '#4f46e5',
    grid: '#e5e7eb'
  },
  className = ''
}) => {
  // Custom tooltip
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-sm">
          <p className="font-medium text-gray-900">{data.subject}</p>
          <p className="text-gray-700">Value: {data.value}</p>
          <p className="text-gray-500 text-sm">Full Mark: {data.fullMark}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {description && <p className="text-sm text-gray-500 mt-1">{description}</p>}
      </CardHeader>
      <CardContent>
        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart cx="50%" cy="50%" outerRadius="70%" data={data}>
              <PolarGrid stroke={colors.grid} />
              <PolarAngleAxis dataKey="subject" tick={{ fill: '#6b7280', fontSize: 12 }} />
              <PolarRadiusAxis tickCount={5} domain={[0, 10]} axisLine={false} tick={{ fill: '#6b7280', fontSize: 10 }} />
              <Radar
                name="Skills"
                dataKey="value"
                stroke={colors.area}
                fill={colors.area}
                fillOpacity={0.2}
                dot
                activeDot={{ r: 6, strokeWidth: 2 }}
              />
              <Tooltip content={<CustomTooltip />} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};