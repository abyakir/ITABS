import React from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  TooltipProps
} from 'recharts';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/Card';

interface DataPoint {
  date: string;
  value: number;
  label?: string;
}

interface ActivityChartProps {
  data: DataPoint[];
  title: string;
  description?: string;
  color?: string;
  gradientFrom?: string;
  gradientTo?: string;
  yAxisLabel?: string;
  tooltipFormatter?: (value: number) => string;
  showCardHeader?: boolean;
  className?: string;
}

export const ActivityChart: React.FC<ActivityChartProps> = ({
  data,
  title,
  description,
  color = '#4f46e5',
  gradientFrom = 'rgba(79, 70, 229, 0.2)',
  gradientTo = 'rgba(79, 70, 229, 0)',
  yAxisLabel,
  tooltipFormatter = (value) => `${value}`,
  showCardHeader = true,
  className = ''
}) => {
  const CustomTooltip = ({ active, payload, label }: TooltipProps<number, string>) => {
    if (active && payload && payload.length) {
      const dataPoint = payload[0].payload as DataPoint;
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-md">
          <p className="font-medium text-gray-900">{new Date(dataPoint.date).toLocaleDateString()}</p>
          <p className="text-gray-700 mt-1">
            {dataPoint.label || 'Value'}: {tooltipFormatter(dataPoint.value)}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <Card className={className}>
      {showCardHeader && (
        <CardHeader>
          <CardTitle>{title}</CardTitle>
          {description && <p className="text-sm text-gray-500 mt-1">{description}</p>}
        </CardHeader>
      )}
      <CardContent className={!showCardHeader ? 'pt-5' : ''}>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={data}
              margin={{ top: 5, right: 5, left: 5, bottom: 5 }}
            >
              <defs>
                <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={gradientFrom} stopOpacity={0.8} />
                  <stop offset="95%" stopColor={gradientTo} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
              <XAxis
                dataKey="date"
                tickFormatter={(date) => new Date(date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                tick={{ fill: '#6b7280', fontSize: 12 }}
                axisLine={{ stroke: '#e5e7eb' }}
                tickLine={false}
              />
              <YAxis
                label={yAxisLabel ? { value: yAxisLabel, angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fill: '#6b7280', fontSize: 12 } } : undefined}
                tick={{ fill: '#6b7280', fontSize: 12 }}
                axisLine={{ stroke: '#e5e7eb' }}
                tickLine={false}
              />
              <Tooltip content={<CustomTooltip />} />
              <Area
                type="monotone"
                dataKey="value"
                stroke={color}
                fillOpacity={1}
                fill="url(#colorGradient)"
                strokeWidth={2}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};