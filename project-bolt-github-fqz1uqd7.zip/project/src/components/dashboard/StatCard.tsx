import React from 'react';
import { motion } from 'framer-motion';
import { Card } from '../ui/Card';

export interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  description?: string;
  trend?: {
    direction: 'up' | 'down' | 'neutral';
    value: string;
  };
  color?: 'blue' | 'green' | 'purple' | 'yellow' | 'red' | 'gray';
  onClick?: () => void;
  className?: string;
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  icon,
  description,
  trend,
  color = 'blue',
  onClick,
  className = ''
}) => {
  const colorStyles = {
    blue: 'bg-blue-50 text-blue-700',
    green: 'bg-green-50 text-green-700',
    purple: 'bg-purple-50 text-purple-700 hover:bg-purple-100',
    yellow: 'bg-yellow-50 text-yellow-700',
    red: 'bg-red-50 text-red-700',
    gray: 'bg-gray-100 text-gray-700',
    indigo: 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100'
  };
  
  const trendColors = {
    up: 'text-green-600',
    down: 'text-red-600',
    neutral: 'text-gray-500'
  };

  const trendIcons = {
    up: '↑',
    down: '↓',
    neutral: '→'
  };

  return (
    <Card 
      clickable={!!onClick} 
      onClick={onClick}
      className={className} 
      hoverable
    >
      <div className="p-6">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm font-medium text-gray-500">{title}</p>
            <motion.div
              className="flex items-baseline mt-2"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <p className="text-3xl font-semibold text-gray-900">{value}</p>
              {trend && (
                <p className={`ml-2 text-sm ${trendColors[trend.direction]}`}>
                  {trendIcons[trend.direction]} {trend.value}
                </p>
              )}
            </motion.div>
            {description && (
              <p className="mt-1.5 text-sm text-gray-500">{description}</p>
            )}
          </div>
          <div className={`p-2.5 rounded-lg ${colorStyles[color]}`}>
            {icon}
          </div>
        </div>
      </div>
    </Card>
  );
};