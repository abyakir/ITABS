import React from 'react';
import { motion } from 'framer-motion';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Clock, Building, Calendar, ArrowRight } from 'lucide-react';

export interface InterviewCardProps {
  id: string;
  position: string;
  company: string;
  date: string;
  duration: number;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  score?: number;
  onViewResults?: (id: string) => void;
  onResume?: (id: string) => void;
}

export const InterviewCard: React.FC<InterviewCardProps> = ({
  id,
  position,
  company,
  date,
  duration,
  status,
  score,
  onViewResults,
  onResume
}) => {
  // Format date string
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    }).format(date);
  };

  // Status badge variants
  const statusVariants = {
    pending: 'default',
    in_progress: 'primary',
    completed: 'success',
    cancelled: 'error'
  };

  // Status labels for better readability
  const statusLabels = {
    pending: 'Pending',
    in_progress: 'In Progress',
    completed: 'Completed',
    cancelled: 'Cancelled'
  };

  return (
    <Card className="overflow-hidden">
      <div className="p-5 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-1">{position}</h3>
            <div className="flex flex-col sm:flex-row sm:items-center text-sm text-gray-600 space-y-1 sm:space-y-0 sm:space-x-4">
              <div className="flex items-center">
                <Building className="w-4 h-4 mr-1 text-gray-500" />
                {company}
              </div>
              <div className="flex items-center">
                <Calendar className="w-4 h-4 mr-1 text-gray-500" />
                {formatDate(date)}
              </div>
              <div className="flex items-center">
                <Clock className="w-4 h-4 mr-1 text-gray-500" />
                {duration} min
              </div>
            </div>
          </div>
          
          <div className="mt-4 sm:mt-0 flex items-center space-x-3">
            <Badge 
              variant={statusVariants[status] as any}
              size="md"
            >
              {statusLabels[status]}
            </Badge>
            
            {score !== undefined && status === 'completed' && (
              <div className={`
                flex items-center justify-center w-10 h-10 rounded-full font-bold text-white
                ${score >= 8 ? 'bg-green-500' : 
                  score >= 6 ? 'bg-yellow-500' : 'bg-red-500'}
              `}>
                {score}
              </div>
            )}
          </div>
        </div>
        
        {/* Action buttons */}
        <div className="mt-5 flex flex-wrap gap-3 sm:justify-end">
          {status === 'in_progress' && onResume && (
            <Button 
              variant="primary" 
              size="sm" 
              onClick={() => onResume(id)}
              icon={<ArrowRight className="w-4 h-4" />}
              iconPosition="right"
            >
              Resume
            </Button>
          )}
          
          {status === 'completed' && onViewResults && (
            <Button 
              variant="secondary" 
              size="sm" 
              onClick={() => onViewResults(id)}
            >
              View Results
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
};