import { useState, useEffect } from 'react';
import { db, storage } from '../lib/supabase';
import { useAuth } from './useAuth';
import type { UserProfile, UserStats } from '../types';
import toast from 'react-hot-toast';

export function useProfile() {
  const { user } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [stats, setStats] = useState<UserStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (user) {
      loadProfile();
      loadStats();
    }
  }, [user]);

  const loadProfile = async () => {
    if (!user) return;

    console.log('Loading profile for user:', user.id);
    try {
      const { data, error } = await db.userProfiles.get(user.id);
      
      if (error && error.code === 'PGRST116') {
        // No profile found, create one
        console.log('No profile found, creating a new one');
        const { data: newProfile, error: createError } = await db.userProfiles.create(user.id, {
          onboarding_completed: false
        });
        
        if (createError) {
          console.error('Failed to create profile:', createError);
          throw createError;
        }
        
        setProfile(newProfile);
      } else if (error) {
        throw error;
      } else {
        console.log('Profile loaded successfully:', data);
        setProfile(data);
      }
    } catch (error) {
      console.error('Failed to load profile:', error);
      toast.error('Failed to load profile');
    } finally {
      setLoading(false);
    }
  };

  const loadStats = async () => {
    if (!user) return;

    try {
      const result = await db.userProfiles.getStats(user.id);
      const { interviews, scores } = result || { interviews: [], scores: [] };
      
      const completedInterviews = interviews.filter(i => i.status === 'completed');
      const averageScore = scores.length > 0 
        ? scores.reduce((sum, score) => sum + score.overall_score, 0) / scores.length 
        : 0;
      const totalPracticeTime = interviews.reduce((sum, interview) => sum + interview.duration_minutes, 0);
      const improvementTrend = scores.length >= 2 
        ? scores[scores.length - 1].overall_score - scores[0].overall_score
        : 0;
      const bestScore = scores.length > 0 
        ? Math.max(...scores.map(s => s.overall_score))
        : 0;

      // Calculate recent activity (last 30 days)
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      
      const recentActivity = interviews
        .filter(i => new Date(i.created_at) >= thirtyDaysAgo)
        .map(interview => {
          const score = scores.find(s => s.interview_id === interview.id);
          return {
            date: interview.created_at,
            type: 'interview' as const,
            score: score?.overall_score,
            duration: interview.duration_minutes
          };
        })
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

      // Calculate skill progress
      const skillProgress = [
        'clarity',
        'confidence', 
        'relevance',
        'communication',
        'technical_skills'
      ].map(skill => {
        const skillScores = scores.map(s => s[skill as keyof typeof s] as number);
        const currentLevel = skillScores.length > 0 ? skillScores[skillScores.length - 1] : 0;
        const previousLevel = skillScores.length > 1 ? skillScores[skillScores.length - 2] : currentLevel;
        const progress = skillScores.length > 1 
          ? ((currentLevel - skillScores[0]) / skillScores[0]) * 100 
          : 0;
        
        let trend: 'up' | 'down' | 'stable' = 'stable';
        if (currentLevel > previousLevel) trend = 'up';
        else if (currentLevel < previousLevel) trend = 'down';

        return {
          skill: skill.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
          current_level: currentLevel,
          progress,
          trend
        };
      });

      setStats({
        total_interviews: interviews.length,
        completed_interviews: completedInterviews.length,
        average_score: averageScore,
        total_practice_time: totalPracticeTime,
        improvement_trend: improvementTrend,
        best_score: bestScore,
        recent_activity: recentActivity,
        skill_progress: skillProgress
      });
    } catch (error) {
      console.error('Failed to load stats:', error);
      // Set empty stats on error to prevent UI issues
      setStats({
        total_interviews: 0,
        completed_interviews: 0,
        average_score: 0,
        total_practice_time: 0,
        improvement_trend: 0,
        best_score: 0,
        recent_activity: [],
        skill_progress: []
      });
    }
  };

  const updateProfile = async (updates: Partial<UserProfile>) => {
    if (!user) return;

    console.log('Updating profile for user:', user.id, 'with data:', updates);
    setSaving(true);
    try {
      // Check if profile exists first
      let profileData;
      if (!profile) {
        // Try to get the profile first as it might have been created by DB trigger
        const { data: existingProfile, error: getError } = await db.userProfiles.get(user.id);
        
        if (getError && getError.code === 'PGRST116') {
          // No profile exists yet, create one with the updates
          console.log('No profile exists, creating new one with updates');
          const { data: newProfile, error: createError } = await db.userProfiles.create(user.id, {
            ...updates,
        });
          
          if (createError) throw createError;
          profileData = newProfile;
        } else if (getError) {
          throw getError;
        } else {
          // Profile exists, just update it
          console.log('Profile exists, updating with new data');
          const { data: updatedProfile, error: updateError } = await db.userProfiles.update(user.id, updates);
          if (updateError) throw updateError;
          profileData = updatedProfile;
        }
      } else {
        // Profile exists in state, just update it
        console.log('Using existing profile in state, updating with new data');
        const { data: updatedProfile, error: updateError } = await db.userProfiles.update(user.id, updates);
        if (updateError) throw updateError;
        profileData = updatedProfile;
      }
      
      setProfile(profileData);
      console.log('Profile saved successfully:', profileData);
      return profileData;
    } catch (error) {
      console.error('Failed to update profile:', error);
      throw error;
    } finally {
      setSaving(false);
    }
  };

  // Special function for initial profile creation during signup
  const createInitialProfile = async (userId: string, data: Partial<UserProfile>) => {
    setSaving(true);
    try {
      const { data: newProfile, error } = await db.userProfiles.create(userId, {
        ...data,
        onboarding_completed: data.onboarding_completed ?? true
      });
      
      if (error) throw error;
      
      setProfile(newProfile);
      console.log('Initial profile created successfully:', newProfile);
      return newProfile;
    } catch (error) {
      console.error('Failed to create initial profile:', error);
      throw error;
    } finally {
      setSaving(false);
    }
  };

  const uploadProfilePhoto = async (file: File) => {
    if (!user) return;

    setUploading(true);
    try {
      // Validate file
      if (!file.type.startsWith('image/')) {
        throw new Error('Please select an image file');
      }
      
      if (file.size > 5 * 1024 * 1024) {
        throw new Error('Image must be less than 5MB');
      }

      const { publicUrl } = await storage.uploadProfilePhoto(user.id, file);
      
      await updateProfile({ profile_photo_url: publicUrl });
      toast.success('Profile photo updated');
      return publicUrl;
    } catch (error: any) {
      console.error('Failed to upload photo:', error);
      toast.error(error.message || 'Failed to upload photo');
      throw error;
    } finally {
      setUploading(false);
    }
  };

  const uploadResume = async (file: File) => {
    if (!user) return;

    setUploading(true);
    try {
      // Validate file
      const allowedTypes = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
      ];
      
      if (!allowedTypes.includes(file.type)) {
        throw new Error('Please select a PDF, DOC, or DOCX file');
      }
      
      if (file.size > 10 * 1024 * 1024) {
        throw new Error('Resume must be less than 10MB');
      }

      const { publicUrl } = await storage.uploadResume(user.id, file);
      
      await updateProfile({ resume_url: publicUrl });
      toast.success('Resume uploaded successfully');
      return publicUrl;
    } catch (error: any) {
      console.error('Failed to upload resume:', error);
      toast.error(error.message || 'Failed to upload resume');
      throw error;
    } finally {
      setUploading(false);
    }
  };

  const completeOnboarding = async () => {
    if (!user) return;

    try {
      await updateProfile({ onboarding_completed: true });
      toast.success('Welcome to Maximum Interview!');
    } catch (error) {
      console.error('Failed to complete onboarding:', error);
    }
  };

  const exportData = async () => {
    if (!user) return;

    try {
      const data = await storage.exportUserData(user.id);
      
      const dataStr = JSON.stringify(data, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      
      // Use a more secure approach without DOM manipulation
      // Validate URL is a blob URL to prevent XSS
      if (!url.startsWith('blob:')) {
        throw new Error('Invalid URL for download');
      }

      // Sanitize filename to prevent XSS
      const safeDate = new Date().toISOString().split('T')[0].replace(/[^a-zA-Z0-9-]/g, '');
      const safeFilename = `maximum-interview-data-${safeDate}.json`.replace(/[^a-zA-Z0-9.-]/g, '');

      // Use a more secure download approach
      try {
        // Create a temporary link element without adding to DOM
        const link = document.createElement('a');
        link.href = url;
        link.download = safeFilename;
        link.rel = 'noopener noreferrer';

        // Trigger download without DOM manipulation
        const clickEvent = new MouseEvent('click', {
          view: window,
          bubbles: true,
          cancelable: false
        });

        link.dispatchEvent(clickEvent);
      } catch (downloadError) {
        // Fallback: use window.open as last resort
        console.warn('Direct download failed, using fallback method');
        const newWindow = window.open(url, '_blank');
        if (newWindow) {
          newWindow.document.title = safeFilename;
          setTimeout(() => newWindow.close(), 1000);
        }
      }
      URL.revokeObjectURL(url);
      
      toast.success('Data exported successfully');
    } catch (error) {
      console.error('Failed to export data:', error);
      toast.error('Failed to export data');
    }
  };

  const deleteAccount = async () => {
    if (!user) return;

    try {
      // This would typically require additional confirmation
      const confirmed = window.confirm(
        'Are you sure you want to delete your account? This action cannot be undone.'
      );
      
      if (!confirmed) return;

      // Delete user data
      await db.userProfiles.delete(user.id);
      
      // Sign out user
      await db.auth.signOut();
      
      toast.success('Account deleted successfully');
    } catch (error) {
      console.error('Failed to delete account:', error);
      toast.error('Failed to delete account');
    }
  };

  const refreshStats = () => {
    loadStats();
  };

  return {
    profile,
    stats,
    loading,
    saving,
    uploading,
    updateProfile,
    uploadProfilePhoto,
    uploadResume,
    completeOnboarding,
    createInitialProfile,
    exportData,
    deleteAccount,
    refreshStats
  };
}