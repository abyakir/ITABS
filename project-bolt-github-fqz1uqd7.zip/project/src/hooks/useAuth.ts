import { useState, useEffect } from 'react';
import { auth } from '../lib/supabase';
import type { User } from '../types';
import { shouldUseMockAuth, mockAuth } from '../lib/mockAuth';

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if we should use mock auth
    if (shouldUseMockAuth()) {
      console.info('🔑 Using mock authentication - no Supabase credentials found');
      
      // Get mock user state from localStorage
      auth.getCurrentUser()
        .then(({ data }) => {
          if (data.user) {
            console.log('📱 Found mock user in storage:', data.user.email);
            setUser(data.user as User);
          } else {
            console.log('📱 No mock user found in storage');
            setUser(null);
          }
          setLoading(false);
        })
        .catch(error => {
          console.error('❌ Error loading mock user:', error);
          setUser(null);
          setLoading(false);
        });
      
      return;
    }

    // Get initial session
    auth.getCurrentUser()
      .then(({ data: { user } }) => {
        setUser(user as User);
        setLoading(false);
      })
      .catch((error) => {
        console.error('Failed to get current user:', error);
        setLoading(false);
      });

    // Listen for auth changes only if Supabase is configured
    const { data: { subscription } } = auth.onAuthStateChange((event, session) => {
      setUser(session?.user as User || null);
      setLoading(false);

      if (event === 'SIGNED_OUT') {
        setUser(null);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const signIn = async (email: string, password: string) => {
    try {
      const { data, error } = await auth.signIn(email, password);
      
      if (error) {
        console.error('Auth error during signIn:', error);
        return { data: null, error: error.message || 'Authentication failed' };
      }
      
      return { data, error: null };
    } catch (err: any) {
      const errorMessage = err.message || 'Failed to sign in';
      console.error('Exception in signIn:', err);
      return { data: null, error: errorMessage };
    }
  };

  const signUp = async (email: string, password: string) => {
    try {
      console.log('Starting signup for:', email);
      const { data, error } = await auth.signUp(email, password);
      
      if (error) throw new Error(error.message);
      
      console.log('Signup successful, user data:', data);
      
      // Store user in localStorage for mock auth
      if (shouldUseMockAuth() && data?.user) {
        const mockUser: User = {
          id: data.user.id || `mock-${Date.now()}`,
          email: data.user.email || email,
          created_at: new Date().toISOString()
        };
        localStorage.setItem('mock-auth-user', JSON.stringify(mockUser));
        
        // Update user state immediately for better UX
        setUser(mockUser);
      }
      
      // Profile creation is handled automatically by database triggers
      
      return { data, error: null };
    } catch (err) {
      const errorMessage = err.message || 'Failed to sign up';
      return { data: null, error: errorMessage };
    }
  };

  const signOut = async () => {
    try {
      // Remove user from localStorage for mock auth
      if (shouldUseMockAuth()) {
        setUser(null);
        localStorage.removeItem('mock-auth-user');
        return;
      }
      
      await auth.signOut();
      setUser(null);
    } catch (err: any) {
      console.error('Sign out error:', err);
    }
  };

  const updateEmail = async (newEmail: string) => {
    try {
      const { data, error } = await auth.updateEmail(newEmail);
      if (error) throw error;
      return { data, error: null };
    } catch (err: any) {
      return { data: null, error: err.message || 'Failed to update email' };
    }
  };
  
  const updatePassword = async (currentPassword: string, newPassword: string) => {
    try {
      const { data, error } = await auth.updatePassword(newPassword);
      if (error) throw error;
      return { data, error: null };
    } catch (err: any) {
      return { data: null, error: err.message || 'Failed to update password' };
    }
  };
  
  const deleteAccount = async () => {
    try {
      // Remove user from localStorage for mock auth
      if (shouldUseMockAuth()) {
        console.log('🗑️ Removing mock user from storage');
        localStorage.removeItem('mock-auth-user');
        setUser(null);
        return { data: null, error: null };
      }
      
      // This is a simplified implementation
      console.error('Account deletion is disabled in this demo');
      return { data: null, error: 'Account deletion is disabled in this demo' };
    } catch (err: any) {
      return { data: null, error: err.message || 'Failed to delete account' };
    }
  };

  return {
    user,
    loading,
    signIn,
    signUp,
    signOut,
    isAuthenticated: !!user,
    updateEmail,
    updatePassword,
    deleteAccount,
    isMockAuth: shouldUseMockAuth()
  };
};