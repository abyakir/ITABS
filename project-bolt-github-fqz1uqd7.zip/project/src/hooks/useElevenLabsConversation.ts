// src/hooks/useElevenLabsConversation.ts
import { useState, useEffect, useCallback, useRef } from 'react';
import { db, realtime } from '../lib/supabase';
import { useConversation } from '@elevenlabs/react';
import toast from 'react-hot-toast';

// Default values in case env vars are missing
const DEFAULT_API_KEY = 'demo_key';
const DEFAULT_AGENT_ID = '';

/* -------------------------------------------------------------------------- */
/*                                TYPES                                       */
/* -------------------------------------------------------------------------- */
export type Message = {
  id: number | string;
  interview_id?: string;
  role: 'ai' | 'user';
  content: string;
  created_at: string;
};

interface UseElevenLabsConversationConfig {
  apiKey: string;
  agentId: string;
}

/* -------------------------------------------------------------------------- */
/*                             HOOK IMPLEMENTATION                            */
/* -------------------------------------------------------------------------- */
export function useElevenLabsConversation(interviewId?: string) {
  /* -------------------------- local state -------------------------- */
  const [messages, setMessages] = useState<Message[]>([]);
  const [status, setStatus] = useState<'disconnected' | 'connecting' | 'connected'>('connecting');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const apiKeyRef = useRef(import.meta.env.VITE_ELEVENLABS_API_KEY || import.meta.env.VITE_ELEVEN_API_KEY || DEFAULT_API_KEY);
  const agentIdRef = useRef(import.meta.env.VITE_ELEVENLABS_AGENT_ID || DEFAULT_AGENT_ID);

  /* --------------------------- ElevenLabs -------------------------- */
  const conversation = useConversation({
    apiKey: apiKeyRef.current,
    agentId: agentIdRef.current, 
    onConnect: () => {
      console.log('🟢 ElevenLabs connected successfully!');
      setStatus('connected');
    },
    onDisconnect: () => {
      console.log('🔴 ElevenLabs disconnected');
      setStatus('disconnected');
    },
    onModeChange: (mode) => {
      /** speaking | listening | idle */
      console.log(`ElevenLabs mode changed to: ${mode}`);
      setIsSpeaking(mode === 'speaking');
      setIsListening(mode === 'listening');
    },
    onMessage: (m) => {
      console.log('Received message from ElevenLabs:', m);
      let content = '';
      let source = 'ai';
      
      if (typeof m === 'string') {
        content = m;
      } else if (m?.message) {
        content = m.message;
        source = m.source === 'user' ? 'user' : 'ai';
      }
      
      if (!content || !content.trim()) return;
      
      const newMsg: Message = {
        id: crypto.randomUUID(),
        role: source as 'user' | 'ai',
        content,
        created_at: new Date().toISOString(),
      };
      
      console.log(`Adding ${source} message:`, content.substring(0, 50) + '...');
      setMessages((prev) => [...prev, newMsg]);
      
      // Only save to database if we have a valid interview ID
      if (interviewId && isValidUUID(interviewId)) {
        db.messages.create({ 
          interview_id: interviewId, 
          role: newMsg.role,
          content: newMsg.content
        }).then(() => {
          console.log('Message saved to database');
        }).catch((err) => {
          console.error('Failed to save message to database:', err);
        });
      }
    },
    onError: (error) => {
      console.error('ElevenLabs error:', error);
      const errorMsg = typeof error === 'string' 
        ? error 
        : error?.message || 'Connection error with ElevenLabs';
      toast.error(errorMsg);
    },
  });

  /* ----------------------- real-time DB sync ----------------------- */
  useEffect(() => {
    if (!interviewId || !isValidUUID(interviewId)) {
      console.log('No interview ID provided, skipping real-time subscription');
      return undefined;
    }
    
    try {
      const sub = realtime.subscribeToInterview(interviewId, (payload) => {
        const newMessage = payload.new;
        if (!newMessage) return;
        
        setMessages((prev) => {
          // Check if message already exists to avoid duplicates
          if (prev.find((msg) => msg.id === newMessage.id)) {
            return prev;
          }
          return [...prev, newMessage];
        });
      });

      return () => {
        if (sub && typeof sub.unsubscribe === 'function') {
          sub.unsubscribe();
        }
      };
    } catch (error) {
      console.error('Error setting up real-time subscription:', error);
      // Return a no-op cleanup function
      return undefined;
    }
  }, [interviewId]);

  /* ----------------------------- API ------------------------------- */
  const startSession = useCallback(
    async (dynamicVariables: Record<string, string | number> = {}) => {
      // Prevent multiple session starts
      if (status === 'connected') return;
      setStatus('connecting');
      try {
        // Make sure we have the required API key and agent ID
        const apiKey = apiKeyRef.current;
        const agentId = agentIdRef.current;
        
        if (!agentId || agentId === '') {
          throw new Error('ElevenLabs Agent ID is not configured. Please set VITE_ELEVENLABS_AGENT_ID in your environment variables.');
        }
        
        if (apiKey === 'demo_key') {
          throw new Error('ElevenLabs API Key is not configured. Please set VITE_ELEVENLABS_API_KEY in your environment variables.');
        }

        console.log('Starting ElevenLabs session with variables:', dynamicVariables);
        
        // Set up mock data for demo purposes if using demo keys
        if (apiKey === 'demo_key' || !agentId) {
          console.log('Using mock ElevenLabs data for demo');
          setTimeout(() => {
            setStatus('connected');
            const demoGreeting = `Hi there! I'm Alex from ${dynamicVariables.company || 'ACME Corp'}. 
            Welcome to your interview for the ${dynamicVariables.job_title || 'Software Developer'} position. 
            Could you tell me about your background and experience?`;
            
            // Add initial greeting
            const newMsg: Message = {
              id: crypto.randomUUID(),
              role: 'ai',
              content: demoGreeting,
              created_at: new Date().toISOString(),
            };
            setMessages(prev => [...prev, newMsg]);
            
            // Save to database if needed
            if (interviewId && isValidUUID(interviewId)) {
              db.messages.create({
                interview_id: interviewId,
                role: 'ai',
                content: demoGreeting
              }).catch(err => console.error('Failed to save demo message:', err));
            }
          }, 2000);
          
          return;
        }
        
        await conversation.startSession({ 
          agentId, 
          dynamicVariables 
        });
        console.log('Session started successfully');
      } catch (error) {
        console.error('Failed to start session:', error);
        const errorMessage = error instanceof Error ? error.message : 'Failed to start interview session';
        toast.error(errorMessage);
        setStatus('disconnected');
        throw error;
      }
    },
    [conversation, status]
  );

  const endSession = useCallback(async () => {
    await conversation.endSession();
    setStatus('disconnected');
  }, [conversation]);

  return {
    /* state */
    messages,
    status,
    isSpeaking,
    isListening,

    /* methods */
    startSession,
    endSession,

    /* raw SDK (optional) */
    conversation,
    
    // Helper method to add message manually (for demo/testing)
    addMessage: (content: string, role: 'ai' | 'user' = 'user') => {
      const newMsg: Message = {
        id: crypto.randomUUID(),
        role,
        content,
        created_at: new Date().toISOString(),
      };
      setMessages(prev => [...prev, newMsg]);
      
      // Save to database if we have a valid interview ID
      if (interviewId && isValidUUID(interviewId)) {
        db.messages.create({
          interview_id: interviewId,
          role,
          content
        }).catch(err => console.error('Failed to save manual message:', err));
      }
      
      return newMsg;
    }
  };
}
