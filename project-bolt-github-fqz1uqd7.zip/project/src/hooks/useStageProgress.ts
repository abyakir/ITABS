import { useState, useRef, useCallback, useEffect } from 'react';

/**
 * Custom hook for managing stage progression
 * Ensures consistent stage tracking across the application
 */
export interface StageProgressOptions {
  minStage?: number;
  maxStage?: number;
  initialStage?: number;
  onChange?: (stage: number) => void;
  validateStage?: (currentStage: number, nextStage: number) => boolean | Promise<boolean>;
}

export function useStageProgress({
  minStage = 1,
  maxStage = 4,
  initialStage = 1,
  onChange,
  validateStage
}: StageProgressOptions = {}) {
  // State to track the current stage
  const [currentStage, setCurrentStage] = useState(
    initialStage < minStage ? minStage : initialStage > maxStage ? maxStage : initialStage
  );
  
  // Ref to track stage for use in callbacks and to avoid closure issues
  const stageRef = useRef(currentStage);
  
  // Update ref when state changes
  useEffect(() => {
    stageRef.current = currentStage;
    if (onChange) {
      onChange(currentStage);
    }
  }, [currentStage, onChange]);
  
  // Go to next stage with validation
  const nextStage = useCallback(async () => {
    const nextStageNum = Math.min(stageRef.current + 1, maxStage);
    
    // Skip if already at max stage
    if (nextStageNum === stageRef.current) return false;
    
    // Validate stage transition if validator provided
    if (validateStage) {
      const isValid = await validateStage(stageRef.current, nextStageNum);
      if (!isValid) return false;
    }
    
    setCurrentStage(nextStageNum);
    return true;
  }, [maxStage, validateStage]);
  
  // Go to previous stage
  const prevStage = useCallback(() => {
    const prevStageNum = Math.max(stageRef.current - 1, minStage);
    
    // Skip if already at min stage
    if (prevStageNum === stageRef.current) return false;
    
    setCurrentStage(prevStageNum);
    return true;
  }, [minStage]);
  
  // Go to a specific stage with validation
  const goToStage = useCallback(async (stage: number) => {
    const targetStage = Math.max(minStage, Math.min(stage, maxStage));
    
    // Skip if already at target stage
    if (targetStage === stageRef.current) return false;
    
    // Validate stage transition if validator provided
    if (validateStage) {
      const isValid = await validateStage(stageRef.current, targetStage);
      if (!isValid) return false;
    }
    
    setCurrentStage(targetStage);
    return true;
  }, [minStage, maxStage, validateStage]);
  
  // Check if a stage is active
  const isStageActive = useCallback((stage: number) => {
    return currentStage === stage;
  }, [currentStage]);
  
  // Check if a stage is completed
  const isStageCompleted = useCallback((stage: number) => {
    return currentStage > stage;
  }, [currentStage]);
  
  return {
    currentStage,
    stageRef,
    nextStage,
    prevStage,
    goToStage,
    isStageActive,
    isStageCompleted,
    isFirstStage: currentStage === minStage,
    isLastStage: currentStage === maxStage,
    totalStages: maxStage - minStage + 1
  };
}

export default useStageProgress;