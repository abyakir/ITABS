import { useState, useEffect } from 'react';
import { db } from '../lib/supabase';
import { useAuth } from './useAuth';
import type { UserPreferences } from '../types';
import toast from 'react-hot-toast';

export function useSettings() {
  const { user } = useAuth();
  const [preferences, setPreferences] = useState<UserPreferences | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (user) {
      loadPreferences();
    }
  }, [user]);

  const loadPreferences = async () => {
    if (!user) return;

    try {
      const { data, error } = await db.userPreferences.get(user.id);
      
      if (error && error.code === 'PGRST116') {
        // No preferences found, create defaults
        const { data: newPrefs } = await db.userPreferences.initializeDefaults(user.id);
        setPreferences(newPrefs);
      } else if (error) {
        throw error;
      } else {
        setPreferences(data);
      }
    } catch (error) {
      console.error('Failed to load preferences:', error);
      toast.error('Failed to load settings');
    } finally {
      setLoading(false);
    }
  };

  const updatePreference = async <K extends keyof UserPreferences>(
    key: K,
    value: UserPreferences[K]
  ) => {
    if (!user || !preferences) return;

    try {
      // Create a copy of the current preferences
      const updatedPrefs = { ...preferences, [key]: value };
      setPreferences(updatedPrefs);

      // Update the database
      const { error } = await db.userPreferences.update(user.id, { [key]: value });
      if (error) throw error;

      // Apply settings immediately
      applySettings(key, value);
      
      // Show success toast for certain settings
      if (['theme_preference', 'language', 'font_size'].includes(key as string)) {
        toast.success(`${key.replace('_', ' ')} updated`);
      }
      
    } catch (error) {
      console.error('Failed to update preference:', error);
      toast.error('Failed to update setting');
      
      // Revert on error
      setPreferences(preferences);
    }
  };

  const updateMultiplePreferences = async (updates: Partial<UserPreferences>) => {
    if (!user || !preferences) return;

    setSaving(true);
    try {
      const updatedPrefs = { ...preferences, ...updates };
      setPreferences(updatedPrefs);

      const { error } = await db.userPreferences.update(user.id, updates);
      if (error) throw error;

      // Apply all settings
      Object.entries(updates).forEach(([key, value]) => {
        applySettings(key as keyof UserPreferences, value);
      });

      toast.success('Settings saved successfully');
    } catch (error) {
      console.error('Failed to update preferences:', error);
      toast.error('Failed to save settings');
      // Revert on error
      setPreferences(preferences);
    } finally {
      setSaving(false);
    }
  };

  const applySettings = (key: keyof UserPreferences, value: any) => {
    switch (key) {
      case 'theme_preference':
        applyTheme(value);
        break;
      case 'font_size':
        applyFontSize(value);
        break;
      case 'high_contrast':
        applyHighContrast(value);
        break;
      case 'reduce_motion':
        applyReduceMotion(value);
        break;
      case 'language':
        applyLanguage(value);
        break;
      default:
        break;
    }
  };

  const applyTheme = (theme: 'light' | 'dark' | 'auto') => {
    const root = document.documentElement;
    
    if (theme === 'auto') {
      // Listen for system theme changes
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      const handleChange = () => applyTheme('auto');
      
      mediaQuery.addEventListener('change', handleChange);
      
      // Cleanup function will be needed in a complete implementation
      
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      theme = prefersDark ? 'dark' : 'light';
    }
    
    // Remove existing theme classes
    root.classList.remove('light', 'dark');
    root.classList.add(theme);
    
    // Update meta theme-color
    const metaThemeColor = document.querySelector('meta[name="theme-color"]');
    if (metaThemeColor) {
      metaThemeColor.setAttribute('content', theme === 'dark' ? '#1f2937' : '#ffffff');
    }
  };

  const applyFontSize = (size: 'small' | 'medium' | 'large' | 'extra-large') => {
    const root = document.documentElement;
    const sizeMap = {
      'small': '14px',
      'medium': '16px',
      'large': '18px',
      'extra-large': '20px'
    };
    
    root.style.fontSize = sizeMap[size];
    root.setAttribute('data-font-size', size);
  };

  const applyHighContrast = (enabled: boolean) => {
    const root = document.documentElement;
    if (enabled) {
      root.classList.add('high-contrast');
    } else {
      root.classList.remove('high-contrast');
    }
  };

  const applyReduceMotion = (enabled: boolean) => {
    const root = document.documentElement;
    if (enabled) {
      root.classList.add('reduce-motion');
    } else {
      root.classList.remove('reduce-motion');
    }
  };

  const applyLanguage = (language: string) => {
    document.documentElement.lang = language;
    // Here you would typically integrate with i18n library
  };

  const resetToDefaults = async () => {
    if (!user) return;

    setSaving(true);
    try {
      const { data } = await db.userPreferences.initializeDefaults(user.id);
      setPreferences(data);
      
      // Apply all default settings
      if (data) {
        Object.entries(data).forEach(([key, value]) => {
          applySettings(key as keyof UserPreferences, value);
        });
      }
      
      toast.success('Settings reset to defaults');
    } catch (error) {
      console.error('Failed to reset settings:', error);
      toast.error('Failed to reset settings');
    } finally {
      setSaving(false);
    }
  };

  const exportSettings = () => {
    if (!preferences) return;

    const dataStr = JSON.stringify(preferences, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `maximum-interview-settings-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast.success('Settings exported successfully');
  };

  const importSettings = async (file: File) => {
    if (!user) return;

    try {
      const text = await file.text();
      const importedPrefs = JSON.parse(text) as Partial<UserPreferences>;
      
      // Validate imported settings
      const validKeys = Object.keys(preferences || {});
      const filteredPrefs = Object.fromEntries(
        Object.entries(importedPrefs).filter(([key]) => validKeys.includes(key))
      );
      
      await updateMultiplePreferences(filteredPrefs);
      toast.success('Settings imported successfully');
    } catch (error) {
      console.error('Failed to import settings:', error);
      toast.error('Failed to import settings');
    }
  };

  // Initialize settings on load
  useEffect(() => {
    if (preferences) {
      // Apply all current settings when preferences load
      Object.entries(preferences).forEach(([key, value]) => {
        applySettings(key as keyof UserPreferences, value);
      });
    }
  }, [preferences]);

  // Check for system theme changes
  useEffect(() => {
    if (preferences?.theme_preference === 'auto') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      const handleChange = () => applyTheme('auto');
      
      mediaQuery.addEventListener('change', handleChange);
      return () => mediaQuery.removeEventListener('change', handleChange);
    }
  }, [preferences?.theme_preference]);

  return {
    preferences,
    loading,
    saving,
    updatePreference,
    updateMultiplePreferences,
    resetToDefaults,
    exportSettings,
    importSettings,
    applySettings
  };
}