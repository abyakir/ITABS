export interface User {
  id: string;
  email: string;
  created_at: string;
}

export interface UserProfile {
  id: string;
  first_name?: string;
  last_name?: string;
  location?: string;
  country?: string;
  referral_source?: string;
  professional_experience?: string;
  profile_photo_url?: string;
  resume_url?: string;
  onboarding_completed: boolean;
  skills?: string[];
  certifications?: string[];
  linkedin_url?: string;
  github_url?: string;
  portfolio_url?: string;
  phone_number?: string;
  timezone?: string;
  created_at: string;
  updated_at: string;
}

export interface UserPreferences {
  user_id: string;
  email_notifications: boolean;
  interview_reminders: boolean;
  performance_insights: boolean;
  camera_verification_enabled: boolean;
  face_detection_enabled: boolean;
  privacy_mode: 'standard' | 'enhanced' | 'minimal';
  theme_preference: 'light' | 'dark' | 'auto';
  language: string;
  font_size: 'small' | 'medium' | 'large' | 'extra-large';
  high_contrast: boolean;
  reduce_motion: boolean;
  live_captions: boolean;
  voice_id: string;
  speech_speed: number;
  microphone_sensitivity: number;
  noise_cancellation: 'auto' | 'high' | 'medium' | 'low' | 'off';
  video_quality: 'auto' | 'hd' | 'standard' | 'low';
  mirror_video: boolean;
  date_format: 'US' | 'UK' | 'ISO' | 'DE';
  time_format: '12' | '24';
  timezone: string;
  created_at: string;
  updated_at: string;
}

export interface Interview {
  id: string;
  user_id: string;
  job_title: string;
  company: string;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  created_at: string;
  completed_at?: string;
  duration_minutes: number;
  experience_level?: 'entry' | 'mid' | 'senior';
  industry?: string;
  custom_questions?: string[];
  focus_areas?: string[];
  interview_phase?: 'opening' | 'background' | 'experience' | 'skills' | 'motivation' | 'closing';
}

export interface Message {
  id: number;
  interview_id: string;
  role: 'user' | 'ai';
  content: string;
  audio_url?: string;
  created_at: string;
  metadata?: {
    confidence?: number;
    processing_time?: number;
    word_count?: number;
  };
}

export interface Score {
  interview_id: string;
  clarity: number;
  confidence: number;
  relevance: number;
  communication: number;
  technical_skills: number;
  overall_score: number;
  summary: string;
  recommendations: string;
  strengths?: string[];
  improvements?: string[];
  industry_comparison?: {
    percentile: number;
    average_score: number;
  };
  // Enhanced scoring categories
  professionalism: number;
  behavioral_appropriateness: number;
  screen_sharing_quality?: number;
  presentation_skills?: number;
  engagement_level: number;
  response_quality_trend: 'improving' | 'declining' | 'stable';
  // Real-time scoring data
  real_time_scores?: RealTimeScore[];
  behavioral_incidents?: BehavioralIncident[];
  screen_share_analysis?: ScreenShareAnalysis[];
  created_at: string;
}

export interface RealTimeScore {
  timestamp: string;
  question_number: number;
  response_quality: number;
  engagement_level: number;
  professionalism: number;
  clarity: number;
  confidence: number;
  technical_depth?: number;
  behavioral_flags: string[];
  score_adjustments: {
    reason: string;
    adjustment: number;
    category: string;
  }[];
}

export interface BehavioralIncident {
  timestamp: string;
  type: 'inappropriate_language' | 'unprofessional_conduct' | 'poor_engagement' | 'hostile_behavior' | 'distraction';
  severity: 'minor' | 'moderate' | 'severe';
  description: string;
  score_impact: number;
  auto_detected: boolean;
  context: string;
}

export interface ScreenShareAnalysis {
  timestamp: string;
  duration: number;
  content_type: 'code' | 'presentation' | 'portfolio' | 'document' | 'inappropriate' | 'unknown';
  quality_assessment: {
    technical_quality: number;
    presentation_skills: number;
    organization: number;
    professionalism: number;
  };
  inappropriate_content_detected: boolean;
  technical_insights?: {
    code_quality?: number;
    best_practices?: number;
    problem_solving?: number;
  };
  behavioral_observations: string[];
}

export interface InterviewSetup {
  jobTitle: string;
  company: string;
  resumeFile?: File;
  customQuestions?: string[];
  experienceLevel: 'entry' | 'mid' | 'senior';
  duration: number; // minutes
  industry?: string;
  focusAreas?: string[];
  difficulty?: 'easy' | 'medium' | 'hard';
}

export interface VoiceSettings {
  voiceId: string;
  stability: number;
  similarityBoost: number;
  speed: number;
  style?: number;
  useSpeakerBoost?: boolean;
}

export interface TOTPVerification {
  token: string;
  isVerified: boolean;
}

export interface UserSession {
  id: string;
  user_id: string;
  session_type: 'interview' | 'practice' | 'assessment';
  camera_verified: boolean;
  face_detected: boolean;
  started_at: string;
  ended_at?: string;
  verification_screenshots?: string[];
  created_at: string;
}

export interface NotificationSettings {
  email_notifications: boolean;
  push_notifications: boolean;
  interview_reminders: boolean;
  performance_insights: boolean;
  weekly_summaries: boolean;
  product_updates: boolean;
}

export interface AccessibilitySettings {
  high_contrast: boolean;
  large_text: boolean;
  reduce_motion: boolean;
  focus_indicators: boolean;
  live_captions: boolean;
  screen_reader_optimized: boolean;
  keyboard_navigation: boolean;
}

export interface AudioVideoSettings {
  microphone_sensitivity: number;
  noise_cancellation: string;
  video_quality: string;
  mirror_video: boolean;
  voice_id: string;
  speech_speed: number;
  auto_start_recording: boolean;
  background_blur: boolean;
}

export interface PrivacySettings {
  privacy_mode: 'minimal' | 'standard' | 'enhanced';
  camera_verification_enabled: boolean;
  face_detection_enabled: boolean;
  data_retention_days: number;
  analytics_enabled: boolean;
  third_party_sharing: boolean;
}

export interface RegionalSettings {
  language: string;
  timezone: string;
  date_format: string;
  time_format: string;
  currency: string;
  number_format: string;
}

export interface UserStats {
  total_interviews: number;
  completed_interviews: number;
  average_score: number;
  total_practice_time: number;
  improvement_trend: number;
  best_score: number;
  recent_activity: Array<{
    date: string;
    type: 'interview' | 'practice';
    score?: number;
    duration: number;
  }>;
  skill_progress: Array<{
    skill: string;
    current_level: number;
    progress: number;
    trend: 'up' | 'down' | 'stable';
  }>;
}

export interface ExportData {
  profile: UserProfile;
  preferences: UserPreferences;
  interviews: Interview[];
  scores: Score[];
  messages: Message[];
  sessions: UserSession[];
  exportedAt: string;
  version: string;
}