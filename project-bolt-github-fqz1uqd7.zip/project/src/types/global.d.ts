// Global type definitions for missing packages

declare module 'babel__generator' {
  export interface GeneratorOptions {
    auxiliaryCommentBefore?: string;
    auxiliaryCommentAfter?: string;
    shouldPrintComment?: (comment: string) => boolean;
    retainLines?: boolean;
    retainFunctionParens?: boolean;
    comments?: boolean;
    compact?: boolean | 'auto';
    minified?: boolean;
    concise?: boolean;
    quotes?: 'single' | 'double';
    filename?: string;
    sourceMaps?: boolean;
    sourceMapTarget?: string;
    sourceRoot?: string;
    sourceFileName?: string;
  }

  export interface GeneratorResult {
    code: string;
    map?: any;
    rawMappings?: any;
  }

  export default function generate(
    ast: any,
    opts?: GeneratorOptions,
    code?: string | { [filename: string]: string }
  ): GeneratorResult;
}

declare module 'babel__traverse' {
  export interface TraverseOptions {
    scope?: any;
    noScope?: boolean;
  }

  export interface NodePath {
    node: any;
    parent: any;
    parentPath: NodePath | null;
    scope: any;
    hub: any;
    data: any;
    context: any;
    state: any;
    opts: any;
    skipKeys: any;
    removed: boolean;
    
    get(key: string): NodePath | NodePath[];
    set(key: string, node: any): void;
    getSibling(key: string | number): NodePath;
    getFunctionParent(): NodePath | null;
    getStatementParent(): NodePath | null;
    replaceWith(replacement: any): void;
    replaceWithMultiple(nodes: any[]): void;
    replaceWithSourceString(replacement: string): void;
    insertBefore(nodes: any | any[]): void;
    insertAfter(nodes: any | any[]): void;
    remove(): void;
    traverse(visitor: any, state?: any): void;
    skip(): void;
    stop(): void;
    requeue(path?: NodePath): void;
    visit(): boolean;
  }

  export interface Visitor {
    [key: string]: {
      enter?(path: NodePath, state: any): void;
      exit?(path: NodePath, state: any): void;
    } | ((path: NodePath, state: any) => void);
  }

  export default function traverse(
    parent: any,
    opts: Visitor,
    scope?: any,
    state?: any,
    parentPath?: NodePath
  ): void;
}

declare module 'estree' {
  export interface BaseNode {
    type: string;
    loc?: SourceLocation | null;
    range?: [number, number];
  }

  export interface SourceLocation {
    source?: string | null;
    start: Position;
    end: Position;
  }

  export interface Position {
    line: number;
    column: number;
  }

  export interface Program extends BaseNode {
    type: 'Program';
    body: Statement[];
    sourceType: 'script' | 'module';
  }

  export interface Statement extends BaseNode {}
  export interface Expression extends BaseNode {}
  export interface Declaration extends Statement {}
  export interface Pattern extends BaseNode {}

  export interface Identifier extends Expression, Pattern {
    type: 'Identifier';
    name: string;
  }

  export interface Literal extends Expression {
    type: 'Literal';
    value: string | boolean | null | number | RegExp;
    raw?: string;
  }

  export interface ExpressionStatement extends Statement {
    type: 'ExpressionStatement';
    expression: Expression;
  }

  export interface BlockStatement extends Statement {
    type: 'BlockStatement';
    body: Statement[];
  }

  export interface FunctionDeclaration extends Declaration {
    type: 'FunctionDeclaration';
    id: Identifier | null;
    params: Pattern[];
    body: BlockStatement;
    generator?: boolean;
    async?: boolean;
  }

  export interface VariableDeclaration extends Declaration {
    type: 'VariableDeclaration';
    declarations: VariableDeclarator[];
    kind: 'var' | 'let' | 'const';
  }

  export interface VariableDeclarator extends BaseNode {
    type: 'VariableDeclarator';
    id: Pattern;
    init: Expression | null;
  }

  export interface CallExpression extends Expression {
    type: 'CallExpression';
    callee: Expression;
    arguments: (Expression | SpreadElement)[];
  }

  export interface MemberExpression extends Expression {
    type: 'MemberExpression';
    object: Expression;
    property: Expression;
    computed: boolean;
  }

  export interface SpreadElement extends BaseNode {
    type: 'SpreadElement';
    argument: Expression;
  }

  export interface Property extends BaseNode {
    type: 'Property';
    key: Expression;
    value: Expression;
    kind: 'init' | 'get' | 'set';
    method: boolean;
    shorthand: boolean;
    computed: boolean;
  }

  export interface ObjectExpression extends Expression {
    type: 'ObjectExpression';
    properties: Property[];
  }

  export interface ArrayExpression extends Expression {
    type: 'ArrayExpression';
    elements: (Expression | null)[];
  }

  export interface ArrowFunctionExpression extends Expression {
    type: 'ArrowFunctionExpression';
    id: Identifier | null;
    params: Pattern[];
    body: BlockStatement | Expression;
    generator: boolean;
    async: boolean;
    expression: boolean;
  }

  export interface ReturnStatement extends Statement {
    type: 'ReturnStatement';
    argument: Expression | null;
  }

  export interface IfStatement extends Statement {
    type: 'IfStatement';
    test: Expression;
    consequent: Statement;
    alternate: Statement | null;
  }

  export interface WhileStatement extends Statement {
    type: 'WhileStatement';
    test: Expression;
    body: Statement;
  }

  export interface ForStatement extends Statement {
    type: 'ForStatement';
    init: VariableDeclaration | Expression | null;
    test: Expression | null;
    update: Expression | null;
    body: Statement;
  }

  export interface BinaryExpression extends Expression {
    type: 'BinaryExpression';
    operator: string;
    left: Expression;
    right: Expression;
  }

  export interface UnaryExpression extends Expression {
    type: 'UnaryExpression';
    operator: string;
    argument: Expression;
    prefix: boolean;
  }

  export interface AssignmentExpression extends Expression {
    type: 'AssignmentExpression';
    operator: string;
    left: Pattern | Expression;
    right: Expression;
  }

  export interface UpdateExpression extends Expression {
    type: 'UpdateExpression';
    operator: '++' | '--';
    argument: Expression;
    prefix: boolean;
  }

  export interface LogicalExpression extends Expression {
    type: 'LogicalExpression';
    operator: '||' | '&&';
    left: Expression;
    right: Expression;
  }

  export interface ConditionalExpression extends Expression {
    type: 'ConditionalExpression';
    test: Expression;
    alternate: Expression;
    consequent: Expression;
  }

  export interface NewExpression extends Expression {
    type: 'NewExpression';
    callee: Expression;
    arguments: (Expression | SpreadElement)[];
  }

  export interface ThisExpression extends Expression {
    type: 'ThisExpression';
  }

  export interface SequenceExpression extends Expression {
    type: 'SequenceExpression';
    expressions: Expression[];
  }

  export interface TemplateLiteral extends Expression {
    type: 'TemplateLiteral';
    quasis: TemplateElement[];
    expressions: Expression[];
  }

  export interface TemplateElement extends BaseNode {
    type: 'TemplateElement';
    tail: boolean;
    value: {
      cooked: string;
      raw: string;
    };
  }

  export interface TaggedTemplateExpression extends Expression {
    type: 'TaggedTemplateExpression';
    tag: Expression;
    quasi: TemplateLiteral;
  }

  export interface ClassDeclaration extends Declaration {
    type: 'ClassDeclaration';
    id: Identifier | null;
    superClass: Expression | null;
    body: ClassBody;
  }

  export interface ClassBody extends BaseNode {
    type: 'ClassBody';
    body: MethodDefinition[];
  }

  export interface MethodDefinition extends BaseNode {
    type: 'MethodDefinition';
    key: Expression;
    value: FunctionExpression;
    kind: 'constructor' | 'method' | 'get' | 'set';
    computed: boolean;
    static: boolean;
  }

  export interface FunctionExpression extends Expression {
    type: 'FunctionExpression';
    id: Identifier | null;
    params: Pattern[];
    body: BlockStatement;
    generator: boolean;
    async: boolean;
  }

  export interface TryStatement extends Statement {
    type: 'TryStatement';
    block: BlockStatement;
    handler: CatchClause | null;
    finalizer: BlockStatement | null;
  }

  export interface CatchClause extends BaseNode {
    type: 'CatchClause';
    param: Pattern | null;
    body: BlockStatement;
  }

  export interface ThrowStatement extends Statement {
    type: 'ThrowStatement';
    argument: Expression;
  }

  export interface BreakStatement extends Statement {
    type: 'BreakStatement';
    label: Identifier | null;
  }

  export interface ContinueStatement extends Statement {
    type: 'ContinueStatement';
    label: Identifier | null;
  }

  export interface SwitchStatement extends Statement {
    type: 'SwitchStatement';
    discriminant: Expression;
    cases: SwitchCase[];
  }

  export interface SwitchCase extends BaseNode {
    type: 'SwitchCase';
    test: Expression | null;
    consequent: Statement[];
  }

  export interface EmptyStatement extends Statement {
    type: 'EmptyStatement';
  }

  export interface DebuggerStatement extends Statement {
    type: 'DebuggerStatement';
  }

  export interface WithStatement extends Statement {
    type: 'WithStatement';
    object: Expression;
    body: Statement;
  }

  export interface LabeledStatement extends Statement {
    type: 'LabeledStatement';
    label: Identifier;
    body: Statement;
  }

  export interface DoWhileStatement extends Statement {
    type: 'DoWhileStatement';
    body: Statement;
    test: Expression;
  }

  export interface ForInStatement extends Statement {
    type: 'ForInStatement';
    left: VariableDeclaration | Pattern;
    right: Expression;
    body: Statement;
  }

  export interface ForOfStatement extends Statement {
    type: 'ForOfStatement';
    left: VariableDeclaration | Pattern;
    right: Expression;
    body: Statement;
  }
}
