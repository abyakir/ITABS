// Main type definitions index file

/// <reference path="./babel__generator.d.ts" />
/// <reference path="./babel__traverse.d.ts" />
/// <reference path="./estree.d.ts" />
/// <reference path="./global.d.ts" />

// Re-export all types for easier importing
export * from './babel__generator';
export * from './babel__traverse';
export * from './estree';

// Global type augmentations
declare global {
  // Extend Window interface if needed
  interface Window {
    // Add any global window properties here if needed
  }

  // Extend NodeJS global if needed
  namespace NodeJS {
    interface Global {
      // Add any global Node.js properties here if needed
    }
  }
}

// Module augmentations for better TypeScript support
declare module '*.svg' {
  const content: string;
  export default content;
}

declare module '*.png' {
  const content: string;
  export default content;
}

declare module '*.jpg' {
  const content: string;
  export default content;
}

declare module '*.jpeg' {
  const content: string;
  export default content;
}

declare module '*.gif' {
  const content: string;
  export default content;
}

declare module '*.webp' {
  const content: string;
  export default content;
}

declare module '*.ico' {
  const content: string;
  export default content;
}

declare module '*.bmp' {
  const content: string;
  export default content;
}

// CSS Modules
declare module '*.module.css' {
  const classes: { [key: string]: string };
  export default classes;
}

declare module '*.module.scss' {
  const classes: { [key: string]: string };
  export default classes;
}

declare module '*.module.sass' {
  const classes: { [key: string]: string };
  export default classes;
}

// JSON modules
declare module '*.json' {
  const value: any;
  export default value;
}

// Text files
declare module '*.txt' {
  const content: string;
  export default content;
}

// Markdown files
declare module '*.md' {
  const content: string;
  export default content;
}

// Web Workers
declare module '*?worker' {
  const WorkerConstructor: {
    new (): Worker;
  };
  export default WorkerConstructor;
}

declare module '*?worker&inline' {
  const WorkerConstructor: {
    new (): Worker;
  };
  export default WorkerConstructor;
}

// Vite-specific
declare module 'virtual:*' {
  const result: any;
  export default result;
}

// Environment variables
interface ImportMetaEnv {
  readonly VITE_SUPABASE_URL: string;
  readonly VITE_SUPABASE_ANON_KEY: string;
  readonly VITE_ELEVEN_API_KEY: string;
  readonly VITE_ELEVENLABS_API_KEY: string;
  readonly VITE_ELEVENLABS_AGENT_ID: string;
  readonly VITE_ELEVEN_VOICE_ID: string;
  // Add other env variables as needed
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

// Export empty object to make this a module
export {};
