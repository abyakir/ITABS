declare module '@babel/generator' {
  export interface GeneratorOptions {
    auxiliaryCommentBefore?: string;
    auxiliaryCommentAfter?: string;
    shouldPrintComment?: (comment: string) => boolean;
    retainLines?: boolean;
    retainFunctionParens?: boolean;
    comments?: boolean;
    compact?: boolean | 'auto';
    minified?: boolean;
    concise?: boolean;
    quotes?: 'single' | 'double';
    filename?: string;
    sourceMaps?: boolean;
    sourceMapTarget?: string;
    sourceRoot?: string;
    sourceFileName?: string;
  }

  export interface GeneratorResult {
    code: string;
    map?: any;
    rawMappings?: any;
  }

  export default function generate(
    ast: any,
    opts?: GeneratorOptions,
    code?: string | { [filename: string]: string }
  ): GeneratorResult;
}

// Also declare the module without the @ prefix for compatibility
declare module 'babel__generator' {
  export * from '@babel/generator';
  export { default } from '@babel/generator';
}
