declare module '@babel/traverse' {
  export interface TraverseOptions {
    scope?: any;
    noScope?: boolean;
  }

  export interface NodePath {
    node: any;
    parent: any;
    parentPath: NodePath | null;
    scope: any;
    hub: any;
    data: any;
    context: any;
    state: any;
    opts: any;
    skipKeys: any;
    removed: boolean;
    
    get(key: string): NodePath | NodePath[];
    set(key: string, node: any): void;
    getSibling(key: string | number): NodePath;
    getFunctionParent(): NodePath | null;
    getStatementParent(): NodePath | null;
    replaceWith(replacement: any): void;
    replaceWithMultiple(nodes: any[]): void;
    replaceWithSourceString(replacement: string): void;
    insertBefore(nodes: any | any[]): void;
    insertAfter(nodes: any | any[]): void;
    remove(): void;
    traverse(visitor: any, state?: any): void;
    skip(): void;
    stop(): void;
    requeue(path?: NodePath): void;
    visit(): boolean;
  }

  export interface Visitor {
    [key: string]: {
      enter?(path: NodePath, state: any): void;
      exit?(path: NodePath, state: any): void;
    } | ((path: NodePath, state: any) => void);
  }

  export default function traverse(
    parent: any,
    opts: Visitor,
    scope?: any,
    state?: any,
    parentPath?: NodePath
  ): void;
}

// Also declare the module without the @ prefix for compatibility
declare module 'babel__traverse' {
  export * from '@babel/traverse';
  export { default } from '@babel/traverse';
}
