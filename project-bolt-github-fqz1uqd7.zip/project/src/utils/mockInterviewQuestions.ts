/**
 * Mock interview questions generator
 * 
 * This module provides predefined sets of interview questions for
 * the interactive job interview simulation, organized by job type
 * and skill level.
 */

// Generic introduction for most interviews
export const createIntroduction = (
  candidateName: string,
  interviewerName: string,
  jobTitle: string,
  company: string
): string => {
  return `Hello ${candidateName}, I'm ${interviewerName} from ${company}. Thank you for joining us today for the ${jobTitle} position. Let's start by having you tell me a bit about yourself and your background.`;
};

// General job interview questions suitable for most positions
export const generalQuestions = [
  "Can you walk me through your resume and highlight your most relevant experience?",
  "What interests you about this position specifically?",
  "Why are you interested in working for our company?",
  "What are your greatest strengths?",
  "What would you consider your weaknesses or areas for improvement?",
  "Tell me about a challenge you faced at work and how you overcame it.",
  "How do you prioritize your work when you have multiple deadlines?",
  "Describe a situation where you had to work with a difficult colleague.",
  "Where do you see yourself professionally in five years?",
  "What questions do you have about the position or company?"
];

// Technical questions for software development roles
export const softwareDevelopmentQuestions = {
  entry: [
    "What programming languages are you most comfortable with?",
    "Can you explain the difference between object-oriented and functional programming?",
    "How do you approach debugging an application?",
    "Describe your experience with version control systems like Git.",
    "What is your approach to writing clean, maintainable code?",
    "Have you worked with APIs before? Can you describe that experience?",
    "How do you stay updated with the latest technology trends?",
    "Can you describe a small project you've worked on and your contribution to it?",
    "What experience do you have with testing frameworks?",
    "How do you handle code reviews?"
  ],
  mid: [
    "Describe a complex technical problem you solved recently.",
    "How do you approach system design for scalable applications?",
    "What's your experience with microservices architecture?",
    "Explain your approach to optimizing application performance.",
    "How do you ensure security in your applications?",
    "Describe your experience with CI/CD pipelines.",
    "How have you handled technical debt in previous projects?",
    "What design patterns have you implemented and in what contexts?",
    "Describe a situation where you improved an existing codebase.",
    "How do you balance technical excellence with business needs and deadlines?"
  ],
  senior: [
    "How do you approach architectural decisions when building complex systems?",
    "Describe your experience leading technical initiatives or projects.",
    "How do you evaluate new technologies for potential adoption?",
    "Describe how you've mentored junior developers.",
    "How do you handle disagreements about technical approaches with your team?",
    "What's your approach to implementing major system changes with minimal disruption?",
    "Describe your experience with building highly scalable or distributed systems.",
    "How do you balance innovation with stability in production systems?",
    "What methods do you use for capacity planning and performance forecasting?",
    "How have you handled critical production issues in previous roles?"
  ]
};

// Questions for design and UX roles
export const designQuestions = {
  entry: [
    "What design tools and software are you proficient in?",
    "Can you walk me through your design process?",
    "How do you approach receiving and implementing feedback on your designs?",
    "Tell me about a project in your portfolio you're most proud of.",
    "How do you stay informed about current design trends?",
    "What's your understanding of user-centered design?",
    "How do you ensure your designs are accessible?",
    "Describe your experience with responsive design.",
    "How do you approach working with developers to implement your designs?",
    "What interests you most about this design position?"
  ],
  mid: [
    "How do you validate your design decisions with users?",
    "Describe a time when you had to balance user needs with business requirements.",
    "What metrics do you use to evaluate the success of your designs?",
    "How do you approach designing for different user personas?",
    "Tell me about a design problem you solved that had significant constraints.",
    "How have you incorporated user research into your design process?",
    "Describe your experience with design systems.",
    "How do you collaborate with product managers and engineers?",
    "Tell me about a time when you had to advocate for user experience.",
    "How do you approach designing for international or diverse audiences?"
  ],
  senior: [
    "How do you approach setting design strategy and vision?",
    "Describe how you've built and managed a design system.",
    "How have you scaled design processes in a growing organization?",
    "Tell me about how you've mentored other designers.",
    "Describe a situation where you influenced product strategy through design.",
    "How do you balance innovation with consistency in your design approach?",
    "What methods do you use to align stakeholders around design decisions?",
    "How do you approach design ethics and responsibility?",
    "Describe your experience leading design teams or initiatives.",
    "How do you measure and communicate the business impact of good design?"
  ]
};

// Questions for marketing and sales roles
export const marketingSalesQuestions = {
  entry: [
    "What experience do you have with digital marketing platforms?",
    "How do you stay updated on marketing/sales trends?",
    "Describe a successful campaign or sale you contributed to.",
    "What tools or CRM systems have you worked with?",
    "How do you approach building relationships with potential clients?",
    "What's your understanding of our target market?",
    "How do you handle objections in the sales process?",
    "What metrics do you track to measure your performance?",
    "How do you prioritize leads or marketing initiatives?",
    "Describe your communication style when working with clients."
  ],
  mid: [
    "Tell me about a challenging sale or campaign you managed and the outcome.",
    "How do you analyze market trends to inform your strategies?",
    "Describe your experience with budget management for marketing initiatives.",
    "How do you approach setting goals and KPIs for yourself or your team?",
    "Tell me about a time you had to pivot your strategy based on market feedback.",
    "How do you leverage data analytics in your sales or marketing approach?",
    "Describe your experience with marketing automation or sales enablement tools.",
    "How do you coordinate with other departments to align on messaging?",
    "What's your approach to customer retention and relationship building?",
    "How have you handled competing priorities in previous roles?"
  ],
  senior: [
    "How have you developed and implemented strategic marketing or sales plans?",
    "Describe how you've built and led high-performing teams.",
    "How do you align sales or marketing strategies with broader business objectives?",
    "Describe a situation where you identified new market opportunities.",
    "How have you managed through significant market changes or challenges?",
    "What's your approach to forecasting and resource planning?",
    "How do you foster innovation within your team while maintaining focus?",
    "Describe how you've mentored team members in their professional development.",
    "How do you approach crisis management in marketing or PR situations?",
    "What methods have you used to enter new markets or reach new customer segments?"
  ]
};

// Questions for management and leadership roles
export const leadershipQuestions = {
  mid: [
    "Describe your management style.",
    "How do you motivate team members?",
    "Tell me about a time you had to give difficult feedback.",
    "How do you handle conflicts within your team?",
    "Describe your approach to delegating tasks.",
    "How do you ensure your team meets deadlines and quality standards?",
    "Tell me about a change you implemented in a previous role.",
    "How do you approach goal-setting for your team?",
    "Describe how you've developed team members in previous roles.",
    "How do you communicate expectations to your team?"
  ],
  senior: [
    "How have you shaped company culture in previous roles?",
    "Describe a situation where you had to make a difficult strategic decision.",
    "How do you approach resource allocation and budget management?",
    "Tell me about a time you had to lead through a significant change or crisis.",
    "How do you align your team's goals with broader organizational objectives?",
    "Describe your experience with building diverse and inclusive teams.",
    "How do you approach succession planning and developing future leaders?",
    "What metrics do you use to measure organizational health and performance?",
    "How have you handled underperforming team members or departments?",
    "Describe your experience with stakeholder management and executive communication."
  ]
};

// Behavioral questions organized by competency
export const behavioralQuestions = {
  problemSolving: [
    "Tell me about a time when you faced an unexpected problem. How did you deal with it?",
    "Describe a situation where you had to think creatively to solve an issue.",
    "Give me an example of a complex problem you solved through analytical thinking."
  ],
  teamwork: [
    "Describe a situation where you had to work closely with someone whose personality was different from yours.",
    "Tell me about a time when you successfully built a relationship with a difficult colleague or stakeholder.",
    "Give an example of when you worked effectively as part of a team to accomplish a goal."
  ],
  leadership: [
    "Describe a time when you took the lead on a difficult project.",
    "Tell me about a situation where you had to influence others without formal authority.",
    "Give an example of how you've motivated team members during challenging times."
  ],
  communication: [
    "Describe a situation where you had to explain a complex topic to someone outside your field.",
    "Tell me about a time when your communication skills made a difference in a project.",
    "Give an example of when you had to deliver a difficult message or negative feedback."
  ],
  adaptability: [
    "Tell me about a time when you had to adapt to a significant change at work.",
    "Describe a situation where you had to learn a new skill quickly to meet a deadline.",
    "Give an example of when you had to be flexible with your approach to solve a problem."
  ]
};

// Generate a set of questions based on job type and experience level
export function getQuestionSet(
  jobType: string, 
  experienceLevel: 'entry' | 'mid' | 'senior',
  count: number = 10
): string[] {
  let questions: string[] = [];
  
  // Add job-specific questions
  if (jobType.toLowerCase().includes('develop') || jobType.toLowerCase().includes('engineer') || jobType.toLowerCase().includes('program')) {
    questions = softwareDevelopmentQuestions[experienceLevel] || softwareDevelopmentQuestions.mid;
  } else if (jobType.toLowerCase().includes('design') || jobType.toLowerCase().includes('ux')) {
    questions = designQuestions[experienceLevel] || designQuestions.mid;
  } else if (jobType.toLowerCase().includes('market') || jobType.toLowerCase().includes('sale')) {
    questions = marketingSalesQuestions[experienceLevel] || marketingSalesQuestions.mid;
  } else if (jobType.toLowerCase().includes('manage') || jobType.toLowerCase().includes('lead')) {
    questions = leadershipQuestions[experienceLevel] || leadershipQuestions.mid;
  } else {
    // Default to general questions plus some behavioral ones
    questions = [...generalQuestions];
    
    // Add some behavioral questions
    const behavioralCategories = Object.keys(behavioralQuestions);
    for (let i = 0; i < Math.min(5, count / 2); i++) {
      const category = behavioralCategories[i % behavioralCategories.length];
      const categoryQuestions = behavioralQuestions[category as keyof typeof behavioralQuestions];
      questions.push(categoryQuestions[i % categoryQuestions.length]);
    }
  }
  
  // Ensure we don't have duplicates and return the requested count
  return [...new Set(questions)].slice(0, count);
}