// Development helpers for debugging and HMR issues

// Check if we're in development mode
export const isDevelopment = import.meta.env.DEV;

// Check if HMR is available
export const isHMRAvailable = () => {
  return typeof import.meta.hot !== 'undefined';
};

// Log development information
export const logDevInfo = () => {
  if (isDevelopment) {
    console.log('🔧 Development Mode Active');
    console.log('📡 HMR Available:', isHMRAvailable());
    console.log('🌐 Environment:', {
      mode: import.meta.env.MODE,
      dev: import.meta.env.DEV,
      prod: import.meta.env.PROD,
      base: import.meta.env.BASE_URL
    });
  }
};

// Fix for common development issues
export const initDevFixes = () => {
  if (isDevelopment) {
    // Ensure global is defined
    if (typeof global === 'undefined') {
      (window as any).global = window;
    }

    // Ensure process is defined
    if (typeof process === 'undefined') {
      (window as any).process = { env: {} };
    }

    // Log any HMR errors
    if (isHMRAvailable()) {
      import.meta.hot?.on('vite:error', (err) => {
        console.error('🚨 HMR Error:', err);
      });
    }

    logDevInfo();
  }
};

// WebSocket connection helper for HMR debugging
export const checkHMRConnection = () => {
  if (isDevelopment && isHMRAvailable()) {
    const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsHost = window.location.hostname;
    const wsPort = import.meta.env.VITE_HMR_PORT || window.location.port || '5173';
    
    console.log('🔌 HMR WebSocket Info:', {
      protocol: wsProtocol,
      host: wsHost,
      port: wsPort,
      url: `${wsProtocol}//${wsHost}:${wsPort}`
    });
  }
};

// Initialize all development helpers
export const initDevelopment = () => {
  initDevFixes();
  checkHMRConnection();
};
