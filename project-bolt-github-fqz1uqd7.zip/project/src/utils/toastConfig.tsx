import toast from 'react-hot-toast';

// Custom toast configuration for interview sessions
export const interviewToast = {
  // Silent success - no UI notification during interview
  success: (message: string, options?: any) => {
    // Only log to console during interview, no UI toast
    console.log('✅', message);
  },
  
  // Silent info - no UI notification during interview
  info: (message: string, options?: any) => {
    console.log('ℹ️', message);
  },
  
  // Still show errors as they're important
  error: (message: string, options?: any) => {
    toast.error(message, {
      duration: 3000,
      position: 'bottom-center', // Less intrusive position
      ...options
    });
  },
  
  // Still show warnings as they're important
  warning: (message: string, options?: any) => {
    toast(message, {
      icon: '⚠️',
      duration: 3000,
      position: 'bottom-center',
      ...options
    });
  }
};

// Regular toast for non-interview screens
export const regularToast = toast;

// Global flag to determine if we're in interview mode
let isInterviewMode = false;

export const setInterviewMode = (enabled: boolean) => {
  isInterviewMode = enabled;
};

export const getInterviewMode = () => isInterviewMode;

// Smart toast that switches based on interview mode
export const smartToast = {
  success: (message: string, options?: any) => {
    if (isInterviewMode) {
      interviewToast.success(message, options);
    } else {
      toast.success(message, options);
    }
  },
  
  error: (message: string, options?: any) => {
    if (isInterviewMode) {
      interviewToast.error(message, options);
    } else {
      toast.error(message, options);
    }
  },
  
  info: (message: string, options?: any) => {
    if (isInterviewMode) {
      interviewToast.info(message, options);
    } else {
      toast.custom((t) => {
        return (
          <div
            className={`${t.visible ? 'animate-enter' : 'animate-leave'} max-w-md w-full bg-white shadow-lg rounded-lg pointer-events-auto flex ring-1 ring-black ring-opacity-5`}
          >
            <div className="flex-1 w-0 p-4">
              <div className="flex items-center">
                <div className="flex-shrink-0 pt-0.5">
                  <span className="bg-blue-100 p-2 rounded-full text-blue-600">ℹ️</span>
                </div>
                <div className="ml-3 flex-1">
                  <p className="text-sm font-medium text-gray-900">
                    {message}
                  </p>
                </div>
              </div>
            <div className="flex border-l border-gray-200">
              <button
                onClick={() => toast.dismiss(t.id)}
                className="w-full border border-transparent rounded-none rounded-r-lg p-4 flex items-center justify-center text-sm font-medium text-gray-600 hover:text-gray-500 focus:outline-none"
              >
                Close
              </button>
            </div>
          </div>
        </div>
        );
      }, options);
    }
  },
  
  warning: (message: string, options?: any) => {
    if (isInterviewMode) {
      interviewToast.warning(message, options);
    } else {
      toast(message, { icon: '⚠️', ...options });
    }
  }
};