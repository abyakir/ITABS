/**
 * Real-time Subscriptions Test Suite
 * 
 * Tests Supabase real-time functionality for:
 * 1. Live message updates during interviews
 * 2. Session status changes
 * 3. Score updates for real-time feedback
 * 4. Connection handling and reconnection
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { db, supabase, realtime } from '../../lib/supabase';
import type { Interview, Message } from '../../types';

// Test configuration
const TEST_USER_ID = 'realtime-test-user';
const TEST_TIMEOUT = 10000; // 10 seconds

describe('Supabase Real-time Subscriptions', () => {
  let testInterview: Interview;
  let subscriptions: any[] = [];

  beforeEach(async () => {
    // Create test interview
    const { data: interview, error } = await db.interviews.create({
      user_id: TEST_USER_ID,
      job_title: 'Test Engineer',
      company: 'Test Company',
      status: 'in_progress'
    });

    if (error) {
      throw new Error(`Failed to create test interview: ${error.message}`);
    }

    testInterview = interview;
  });

  afterEach(async () => {
    // Clean up subscriptions
    subscriptions.forEach(sub => {
      if (sub && typeof sub.unsubscribe === 'function') {
        sub.unsubscribe();
      }
    });
    subscriptions = [];

    // Clean up test data
    if (testInterview?.id) {
      await db.interviews.delete(testInterview.id);
    }
  });

  describe('Message Real-time Updates', () => {
    it('should receive real-time message updates', async () => {
      return new Promise<void>((resolve, reject) => {
        const timeout = setTimeout(() => {
          reject(new Error('Test timeout: No real-time message received'));
        }, TEST_TIMEOUT);

        let messageReceived = false;

        // Set up real-time subscription
        const subscription = realtime.subscribeToInterview(
          testInterview.id,
          (payload) => {
            try {
              expect(payload).toBeDefined();
              expect(payload.eventType).toBeDefined();
              expect(payload.new || payload.old).toBeDefined();

              if (payload.eventType === 'INSERT' && payload.new) {
                const message = payload.new;
                expect(message.interview_id).toBe(testInterview.id);
                expect(message.role).toBe('ai');
                expect(message.content).toBe('Test real-time message');
                
                messageReceived = true;
                clearTimeout(timeout);
                resolve();
              }
            } catch (error) {
              clearTimeout(timeout);
              reject(error);
            }
          }
        );

        subscriptions.push(subscription);

        // Wait a moment for subscription to be established
        setTimeout(async () => {
          try {
            // Create a message to trigger the real-time update
            await db.messages.create({
              interview_id: testInterview.id,
              role: 'ai',
              content: 'Test real-time message'
            });
          } catch (error) {
            clearTimeout(timeout);
            reject(error);
          }
        }, 1000);
      });
    });

    it('should handle multiple message updates in sequence', async () => {
      return new Promise<void>((resolve, reject) => {
        const timeout = setTimeout(() => {
          reject(new Error('Test timeout: Not all messages received'));
        }, TEST_TIMEOUT);

        const expectedMessages = ['Message 1', 'Message 2', 'Message 3'];
        const receivedMessages: string[] = [];

        // Set up real-time subscription
        const subscription = realtime.subscribeToInterview(
          testInterview.id,
          (payload) => {
            try {
              if (payload.eventType === 'INSERT' && payload.new) {
                const message = payload.new;
                receivedMessages.push(message.content);

                if (receivedMessages.length === expectedMessages.length) {
                  expect(receivedMessages).toEqual(expectedMessages);
                  clearTimeout(timeout);
                  resolve();
                }
              }
            } catch (error) {
              clearTimeout(timeout);
              reject(error);
            }
          }
        );

        subscriptions.push(subscription);

        // Wait for subscription to be established, then send messages
        setTimeout(async () => {
          try {
            for (const content of expectedMessages) {
              await db.messages.create({
                interview_id: testInterview.id,
                role: 'ai',
                content
              });
              // Small delay between messages
              await new Promise(resolve => setTimeout(resolve, 100));
            }
          } catch (error) {
            clearTimeout(timeout);
            reject(error);
          }
        }, 1000);
      });
    });
  });

  describe('User Session Real-time Updates', () => {
    it('should receive session status changes', async () => {
      return new Promise<void>((resolve, reject) => {
        const timeout = setTimeout(() => {
          reject(new Error('Test timeout: No session update received'));
        }, TEST_TIMEOUT);

        // Set up real-time subscription for user sessions
        const subscription = realtime.subscribeToUserSessions(
          TEST_USER_ID,
          (payload) => {
            try {
              expect(payload).toBeDefined();
              expect(payload.eventType).toBeDefined();

              if (payload.eventType === 'INSERT' && payload.new) {
                const session = payload.new;
                expect(session.user_id).toBe(TEST_USER_ID);
                expect(session.session_type).toBe('interview');
                
                clearTimeout(timeout);
                resolve();
              }
            } catch (error) {
              clearTimeout(timeout);
              reject(error);
            }
          }
        );

        subscriptions.push(subscription);

        // Wait for subscription to be established, then create session
        setTimeout(async () => {
          try {
            await db.userSessions.create({
              user_id: TEST_USER_ID,
              session_type: 'interview',
              camera_verified: true,
              face_detected: true
            });
          } catch (error) {
            clearTimeout(timeout);
            reject(error);
          }
        }, 1000);
      });
    });
  });

  describe('Connection Handling', () => {
    it('should handle subscription connection states', async () => {
      return new Promise<void>((resolve, reject) => {
        const timeout = setTimeout(() => {
          reject(new Error('Test timeout: Subscription not established'));
        }, TEST_TIMEOUT);

        // Create subscription and monitor its state
        const channel = supabase
          .channel(`test-interview:${testInterview.id}`)
          .on('postgres_changes', {
            event: '*',
            schema: 'public',
            table: 'messages',
            filter: `interview_id=eq.${testInterview.id}`
          }, (payload) => {
            // Message received, subscription is working
            clearTimeout(timeout);
            resolve();
          });

        // Subscribe and check status
        channel.subscribe((status) => {
          if (status === 'SUBSCRIBED') {
            // Subscription established, create a test message
            setTimeout(async () => {
              try {
                await db.messages.create({
                  interview_id: testInterview.id,
                  role: 'ai',
                  content: 'Connection test message'
                });
              } catch (error) {
                clearTimeout(timeout);
                reject(error);
              }
            }, 500);
          } else if (status === 'CHANNEL_ERROR') {
            clearTimeout(timeout);
            reject(new Error('Channel subscription error'));
          }
        });

        subscriptions.push(channel);
      });
    });

    it('should handle subscription cleanup properly', async () => {
      // Create and immediately unsubscribe
      const channel = supabase
        .channel(`cleanup-test:${testInterview.id}`)
        .on('postgres_changes', {
          event: '*',
          schema: 'public',
          table: 'messages',
          filter: `interview_id=eq.${testInterview.id}`
        }, () => {});

      const subscription = channel.subscribe();
      
      // Wait a moment then unsubscribe
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const unsubscribeResult = await supabase.removeChannel(channel);
      expect(unsubscribeResult).toBe('ok');
    });
  });

  describe('Error Handling', () => {
    it('should handle invalid subscription parameters gracefully', async () => {
      // Test with invalid interview ID
      const invalidSubscription = realtime.subscribeToInterview(
        'invalid-interview-id',
        (payload) => {
          // This should not receive any messages
        }
      );

      subscriptions.push(invalidSubscription);

      // Create a message for the real interview
      await db.messages.create({
        interview_id: testInterview.id,
        role: 'ai',
        content: 'This should not trigger invalid subscription'
      });

      // Wait to ensure no messages are received on invalid subscription
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // If we reach here without errors, the test passes
      expect(true).toBe(true);
    });

    it('should handle network disconnection scenarios', async () => {
      // This test would require mocking network conditions
      // For now, we'll test that subscriptions can be re-established
      
      const channel = supabase
        .channel(`reconnect-test:${testInterview.id}`)
        .on('postgres_changes', {
          event: '*',
          schema: 'public',
          table: 'messages',
          filter: `interview_id=eq.${testInterview.id}`
        }, () => {});

      // Subscribe
      await new Promise<void>((resolve) => {
        channel.subscribe((status) => {
          if (status === 'SUBSCRIBED') {
            resolve();
          }
        });
      });

      // Unsubscribe
      await supabase.removeChannel(channel);

      // Re-subscribe
      const newChannel = supabase
        .channel(`reconnect-test-2:${testInterview.id}`)
        .on('postgres_changes', {
          event: '*',
          schema: 'public',
          table: 'messages',
          filter: `interview_id=eq.${testInterview.id}`
        }, () => {});

      await new Promise<void>((resolve) => {
        newChannel.subscribe((status) => {
          if (status === 'SUBSCRIBED') {
            resolve();
          }
        });
      });

      subscriptions.push(newChannel);
      
      // Test passes if re-subscription succeeds
      expect(true).toBe(true);
    });
  });
});
