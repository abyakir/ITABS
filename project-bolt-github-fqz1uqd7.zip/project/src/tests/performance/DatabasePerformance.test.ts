/**
 * Database Performance Test Suite
 * 
 * Tests database query performance and optimization for:
 * 1. Interview creation and retrieval
 * 2. Message insertion and conversation loading
 * 3. Score calculation and analytics
 * 4. Real-time subscription performance
 * 5. Index effectiveness
 */

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { db, supabase } from '../../lib/supabase';
import type { Interview, Message, Score } from '../../types';

// Performance thresholds (in milliseconds)
const PERFORMANCE_THRESHOLDS = {
  INTERVIEW_CREATION: 500,
  MESSAGE_INSERTION: 200,
  CONVERSATION_LOADING: 1000,
  SCORE_CALCULATION: 300,
  USER_STATS_QUERY: 800,
  REAL_TIME_LATENCY: 100
};

// Test data configuration
const TEST_USER_COUNT = 10;
const TEST_INTERVIEWS_PER_USER = 5;
const TEST_MESSAGES_PER_INTERVIEW = 20;

describe('Database Performance Tests', () => {
  let testUserIds: string[] = [];
  let testInterviewIds: string[] = [];

  beforeAll(async () => {
    console.log('Setting up performance test data...');
    await setupTestData();
  });

  afterAll(async () => {
    console.log('Cleaning up performance test data...');
    await cleanupTestData();
  });

  describe('Interview Operations Performance', () => {
    it('should create interviews within performance threshold', async () => {
      const startTime = performance.now();
      
      const { data: interview, error } = await db.interviews.create({
        user_id: testUserIds[0],
        job_title: 'Performance Test Engineer',
        company: 'Test Company',
        status: 'in_progress',
        experience_level: 'mid',
        custom_questions: ['Question 1', 'Question 2'],
        focus_areas: ['Technical Skills', 'Communication']
      });

      const endTime = performance.now();
      const executionTime = endTime - startTime;

      expect(error).toBeNull();
      expect(interview).toBeDefined();
      expect(executionTime).toBeLessThan(PERFORMANCE_THRESHOLDS.INTERVIEW_CREATION);
      
      console.log(`Interview creation time: ${executionTime.toFixed(2)}ms`);
      
      if (interview) {
        testInterviewIds.push(interview.id);
      }
    });

    it('should retrieve user interviews efficiently', async () => {
      const startTime = performance.now();
      
      const { data: interviews, error } = await db.interviews.getAll(testUserIds[0]);
      
      const endTime = performance.now();
      const executionTime = endTime - startTime;

      expect(error).toBeNull();
      expect(interviews).toBeDefined();
      expect(executionTime).toBeLessThan(PERFORMANCE_THRESHOLDS.CONVERSATION_LOADING);
      
      console.log(`Interview retrieval time: ${executionTime.toFixed(2)}ms for ${interviews?.length || 0} interviews`);
    });

    it('should handle concurrent interview creation', async () => {
      const concurrentOperations = 5;
      const startTime = performance.now();
      
      const promises = Array.from({ length: concurrentOperations }, (_, i) =>
        db.interviews.create({
          user_id: testUserIds[i % testUserIds.length],
          job_title: `Concurrent Test ${i}`,
          company: 'Test Company',
          status: 'in_progress'
        })
      );

      const results = await Promise.all(promises);
      
      const endTime = performance.now();
      const executionTime = endTime - startTime;
      const avgTime = executionTime / concurrentOperations;

      expect(results.every(r => r.error === null)).toBe(true);
      expect(avgTime).toBeLessThan(PERFORMANCE_THRESHOLDS.INTERVIEW_CREATION);
      
      console.log(`Concurrent interview creation: ${executionTime.toFixed(2)}ms total, ${avgTime.toFixed(2)}ms average`);
      
      // Add successful interviews to cleanup list
      results.forEach(result => {
        if (result.data) {
          testInterviewIds.push(result.data.id);
        }
      });
    });
  });

  describe('Message Operations Performance', () => {
    it('should insert messages quickly', async () => {
      const interviewId = testInterviewIds[0];
      if (!interviewId) {
        throw new Error('No test interview available');
      }

      const startTime = performance.now();
      
      const { data: message, error } = await db.messages.create({
        interview_id: interviewId,
        role: 'ai',
        content: 'Performance test message with some content to simulate real usage patterns.'
      });

      const endTime = performance.now();
      const executionTime = endTime - startTime;

      expect(error).toBeNull();
      expect(message).toBeDefined();
      expect(executionTime).toBeLessThan(PERFORMANCE_THRESHOLDS.MESSAGE_INSERTION);
      
      console.log(`Message insertion time: ${executionTime.toFixed(2)}ms`);
    });

    it('should load conversation messages efficiently', async () => {
      const interviewId = testInterviewIds[0];
      if (!interviewId) {
        throw new Error('No test interview available');
      }

      // First, create multiple messages
      const messagePromises = Array.from({ length: 10 }, (_, i) =>
        db.messages.create({
          interview_id: interviewId,
          role: i % 2 === 0 ? 'ai' : 'user',
          content: `Test message ${i} with varying content length to simulate real conversation patterns.`
        })
      );

      await Promise.all(messagePromises);

      // Now test retrieval performance
      const startTime = performance.now();
      
      const { data: messages, error } = await db.messages.getByInterviewId(interviewId);
      
      const endTime = performance.now();
      const executionTime = endTime - startTime;

      expect(error).toBeNull();
      expect(messages).toBeDefined();
      expect(messages?.length).toBeGreaterThan(0);
      expect(executionTime).toBeLessThan(PERFORMANCE_THRESHOLDS.CONVERSATION_LOADING);
      
      console.log(`Conversation loading time: ${executionTime.toFixed(2)}ms for ${messages?.length || 0} messages`);
    });

    it('should handle bulk message insertion efficiently', async () => {
      const interviewId = testInterviewIds[1] || testInterviewIds[0];
      if (!interviewId) {
        throw new Error('No test interview available');
      }

      const messageCount = 50;
      const startTime = performance.now();
      
      const promises = Array.from({ length: messageCount }, (_, i) =>
        db.messages.create({
          interview_id: interviewId,
          role: i % 2 === 0 ? 'ai' : 'user',
          content: `Bulk message ${i} - ${Math.random().toString(36).substring(7)}`
        })
      );

      const results = await Promise.all(promises);
      
      const endTime = performance.now();
      const executionTime = endTime - startTime;
      const avgTime = executionTime / messageCount;

      expect(results.every(r => r.error === null)).toBe(true);
      expect(avgTime).toBeLessThan(PERFORMANCE_THRESHOLDS.MESSAGE_INSERTION);
      
      console.log(`Bulk message insertion: ${executionTime.toFixed(2)}ms total, ${avgTime.toFixed(2)}ms average`);
    });
  });

  describe('Score Operations Performance', () => {
    it('should save scores efficiently', async () => {
      const interviewId = testInterviewIds[0];
      if (!interviewId) {
        throw new Error('No test interview available');
      }

      const scoreData = {
        interview_id: interviewId,
        clarity: 8,
        confidence: 7,
        relevance: 9,
        communication: 8,
        technical_skills: 7,
        overall_score: 8,
        summary: 'Performance test score with detailed summary content.',
        recommendations: 'Performance test recommendations with actionable feedback.',
        professionalism: 9,
        behavioral_appropriateness: 10,
        engagement_level: 8,
        response_quality_trend: 'improving' as const,
        strengths: ['Clear communication', 'Technical knowledge'],
        improvements: ['More examples', 'Deeper technical details'],
        real_time_scores: Array.from({ length: 10 }, (_, i) => ({
          timestamp: Date.now() + i * 1000,
          category: 'clarity',
          score: 7 + Math.random() * 3
        }))
      };

      const startTime = performance.now();
      
      const { data: score, error } = await db.scores.create(scoreData);
      
      const endTime = performance.now();
      const executionTime = endTime - startTime;

      expect(error).toBeNull();
      expect(score).toBeDefined();
      expect(executionTime).toBeLessThan(PERFORMANCE_THRESHOLDS.SCORE_CALCULATION);
      
      console.log(`Score creation time: ${executionTime.toFixed(2)}ms`);
    });

    it('should retrieve user score history efficiently', async () => {
      const userId = testUserIds[0];
      
      const startTime = performance.now();
      
      const { data: scores, error } = await db.scores.getUserScores(userId);
      
      const endTime = performance.now();
      const executionTime = endTime - startTime;

      expect(error).toBeNull();
      expect(scores).toBeDefined();
      expect(executionTime).toBeLessThan(PERFORMANCE_THRESHOLDS.USER_STATS_QUERY);
      
      console.log(`Score history retrieval: ${executionTime.toFixed(2)}ms for ${scores?.length || 0} scores`);
    });
  });

  describe('Complex Query Performance', () => {
    it('should handle interview with details query efficiently', async () => {
      const interviewId = testInterviewIds[0];
      if (!interviewId) {
        throw new Error('No test interview available');
      }

      const startTime = performance.now();
      
      const result = await db.interviews.getWithDetails(interviewId);
      
      const endTime = performance.now();
      const executionTime = endTime - startTime;

      expect(result.interview).toBeDefined();
      expect(result.messages).toBeDefined();
      expect(executionTime).toBeLessThan(PERFORMANCE_THRESHOLDS.CONVERSATION_LOADING);
      
      console.log(`Interview with details query: ${executionTime.toFixed(2)}ms`);
    });

    it('should handle user statistics query efficiently', async () => {
      const userId = testUserIds[0];
      
      const startTime = performance.now();
      
      const stats = await db.userProfiles.getStats(userId);
      
      const endTime = performance.now();
      const executionTime = endTime - startTime;

      expect(stats).toBeDefined();
      expect(stats.interviews).toBeDefined();
      expect(stats.scores).toBeDefined();
      expect(executionTime).toBeLessThan(PERFORMANCE_THRESHOLDS.USER_STATS_QUERY);
      
      console.log(`User statistics query: ${executionTime.toFixed(2)}ms`);
    });
  });

  // Helper functions
  async function setupTestData() {
    // Create test users
    for (let i = 0; i < TEST_USER_COUNT; i++) {
      const userId = `perf-test-user-${i}-${Date.now()}`;
      testUserIds.push(userId);
      
      await db.userProfiles.create(userId, {
        id: userId,
        first_name: `Test${i}`,
        last_name: 'User',
        professional_experience: 'Software Engineer'
      });
    }

    // Create test interviews
    for (const userId of testUserIds) {
      for (let j = 0; j < TEST_INTERVIEWS_PER_USER; j++) {
        const { data: interview } = await db.interviews.create({
          user_id: userId,
          job_title: `Test Job ${j}`,
          company: 'Test Company',
          status: j % 2 === 0 ? 'completed' : 'in_progress',
          experience_level: 'mid'
        });
        
        if (interview) {
          testInterviewIds.push(interview.id);
        }
      }
    }
  }

  async function cleanupTestData() {
    // Delete test interviews (will cascade delete messages and scores)
    for (const interviewId of testInterviewIds) {
      try {
        await db.interviews.delete(interviewId);
      } catch (error) {
        console.warn(`Failed to delete interview ${interviewId}:`, error);
      }
    }

    // Delete test users
    for (const userId of testUserIds) {
      try {
        await db.userProfiles.delete(userId);
      } catch (error) {
        console.warn(`Failed to delete user ${userId}:`, error);
      }
    }
  }
});
