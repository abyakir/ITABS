/**
 * Manual Data Flow Test
 * 
 * This script tests the complete ElevenLabs-Supabase integration
 * by simulating a real interview workflow.
 */

import { db } from '../../lib/supabase';
import { dynamicScoringService } from '../../lib/dynamicScoring';
import type { InterviewSetup } from '../../types';

// Test configuration
const TEST_USER_ID = 'test-user-' + Date.now();
const TEST_INTERVIEW_SETUP: InterviewSetup = {
  jobTitle: 'Senior Software Engineer',
  company: 'Tech Innovations Inc',
  duration: 30,
  experienceLevel: 'senior',
  customQuestions: [
    'Describe your experience with microservices architecture',
    'How do you handle technical debt in large codebases?'
  ],
  focusAreas: ['Technical Leadership', 'System Design', 'Communication'],
  interviewerName: 'Alex'
};

async function testCompleteDataFlow() {
  console.log('🚀 Starting ElevenLabs-Supabase Integration Test...\n');

  try {
    // Step 1: Create Interview
    console.log('📝 Step 1: Creating interview record...');
    const { data: interview, error: interviewError } = await db.interviews.create({
      user_id: TEST_USER_ID,
      job_title: TEST_INTERVIEW_SETUP.jobTitle,
      company: TEST_INTERVIEW_SETUP.company,
      status: 'in_progress',
      experience_level: TEST_INTERVIEW_SETUP.experienceLevel,
      custom_questions: TEST_INTERVIEW_SETUP.customQuestions || [],
      focus_areas: TEST_INTERVIEW_SETUP.focusAreas || []
    });

    if (interviewError) {
      throw new Error(`Interview creation failed: ${interviewError.message}`);
    }

    console.log(`✅ Interview created with ID: ${interview.id}`);
    console.log(`   Job Title: ${interview.job_title}`);
    console.log(`   Company: ${interview.company}`);
    console.log(`   Status: ${interview.status}`);
    console.log(`   Experience Level: ${interview.experience_level}`);
    console.log(`   Custom Questions: ${interview.custom_questions?.length || 0}`);
    console.log(`   Focus Areas: ${interview.focus_areas?.length || 0}\n`);

    // Step 2: Simulate Conversation
    console.log('💬 Step 2: Simulating conversation messages...');
    
    const conversationFlow = [
      { role: 'ai', content: `Hi there! I'm ${TEST_INTERVIEW_SETUP.interviewerName} from ${TEST_INTERVIEW_SETUP.company}. Welcome to your interview for the ${TEST_INTERVIEW_SETUP.jobTitle} position. Can you start by telling me about yourself?` },
      { role: 'user', content: 'Thank you for having me! I\'m a senior software engineer with 8 years of experience in full-stack development. I\'ve led several teams and have extensive experience with microservices architecture and cloud platforms.' },
      { role: 'ai', content: 'That sounds impressive! Can you tell me about a challenging technical problem you\'ve solved recently?' },
      { role: 'user', content: 'Recently, I architected a solution to reduce our API response times by 60%. We had a monolithic system that was becoming a bottleneck, so I designed a microservices architecture with proper caching strategies and database optimization.' },
      { role: 'ai', content: 'Excellent! How do you approach technical debt in large codebases?' },
      { role: 'user', content: 'I believe in a balanced approach. I allocate 20% of sprint capacity to technical debt, prioritize based on business impact, and ensure we have good monitoring to identify problematic areas. Documentation and knowledge sharing are also crucial.' }
    ];

    const messages = [];
    for (let i = 0; i < conversationFlow.length; i++) {
      const messageData = conversationFlow[i];
      const { data: message, error: messageError } = await db.messages.create({
        interview_id: interview.id,
        role: messageData.role as 'ai' | 'user',
        content: messageData.content
      });

      if (messageError) {
        throw new Error(`Message creation failed: ${messageError.message}`);
      }

      messages.push(message);
      console.log(`   ${messageData.role.toUpperCase()}: ${messageData.content.substring(0, 80)}...`);
    }

    console.log(`✅ Created ${messages.length} messages\n`);

    // Step 3: Test Dynamic Scoring
    console.log('📊 Step 3: Testing dynamic scoring...');
    
    // Initialize dynamic scoring
    dynamicScoringService.initialize(interview.id, {
      jobTitle: TEST_INTERVIEW_SETUP.jobTitle,
      experienceLevel: TEST_INTERVIEW_SETUP.experienceLevel || 'mid',
      focusAreas: TEST_INTERVIEW_SETUP.focusAreas || []
    });

    // Simulate scoring user responses
    const userResponses = conversationFlow.filter(msg => msg.role === 'user');
    for (let i = 0; i < userResponses.length; i++) {
      const response = userResponses[i];
      const responseTime = 3000 + Math.random() * 2000; // 3-5 seconds
      
      await dynamicScoringService.analyzeResponse(
        response.content,
        i + 1,
        responseTime
      );
    }

    const finalScores = dynamicScoringService.getFinalScores();
    console.log('   Dynamic scoring results:');
    console.log(`   - Clarity: ${finalScores.clarity}/10`);
    console.log(`   - Confidence: ${finalScores.confidence}/10`);
    console.log(`   - Relevance: ${finalScores.relevance}/10`);
    console.log(`   - Communication: ${finalScores.communication}/10`);
    console.log(`   - Technical Skills: ${finalScores.technical_skills}/10`);
    console.log(`   - Professionalism: ${finalScores.professionalism}/10`);
    console.log(`   - Engagement Level: ${finalScores.engagement_level}/10\n`);

    // Step 4: Save Final Scores
    console.log('💾 Step 4: Saving final scores to database...');
    
    const { data: score, error: scoreError } = await db.scores.create({
      interview_id: interview.id,
      ...finalScores,
      summary: 'Strong technical candidate with excellent communication skills and leadership experience.',
      recommendations: 'Consider for senior role. Recommend discussing team leadership opportunities.',
      strengths: ['Technical expertise', 'Clear communication', 'Problem-solving approach'],
      improvements: ['Could provide more specific metrics', 'Expand on team management experience'],
      real_time_scores: [
        { timestamp: Date.now() - 10000, category: 'clarity', score: 8 },
        { timestamp: Date.now() - 5000, category: 'confidence', score: 9 },
        { timestamp: Date.now(), category: 'technical_skills', score: 9 }
      ],
      behavioral_incidents: [],
      screen_share_analysis: []
    });

    if (scoreError) {
      throw new Error(`Score creation failed: ${scoreError.message}`);
    }

    console.log(`✅ Scores saved successfully`);
    console.log(`   Overall Score: ${score.overall_score}/10`);
    console.log(`   Strengths: ${score.strengths?.length || 0} items`);
    console.log(`   Improvements: ${score.improvements?.length || 0} items`);
    console.log(`   Real-time Scores: ${score.real_time_scores?.length || 0} entries\n`);

    // Step 5: Complete Interview
    console.log('🏁 Step 5: Completing interview...');
    
    const completedAt = new Date().toISOString();
    const durationMinutes = Math.floor(Math.random() * 10) + 25; // 25-35 minutes

    const { data: completedInterview, error: updateError } = await db.interviews.update(interview.id, {
      status: 'completed',
      completed_at: completedAt,
      duration_minutes: durationMinutes
    });

    if (updateError) {
      throw new Error(`Interview completion failed: ${updateError.message}`);
    }

    console.log(`✅ Interview completed successfully`);
    console.log(`   Status: ${completedInterview.status}`);
    console.log(`   Duration: ${completedInterview.duration_minutes} minutes`);
    console.log(`   Completed At: ${completedInterview.completed_at}\n`);

    // Step 6: Test Data Retrieval
    console.log('🔍 Step 6: Testing data retrieval...');
    
    const result = await db.interviews.getWithDetails(interview.id);
    
    console.log(`✅ Retrieved complete interview data:`);
    console.log(`   Interview: ${result.interview ? 'Found' : 'Not found'}`);
    console.log(`   Messages: ${result.messages?.length || 0} entries`);
    console.log(`   Score: ${result.score ? 'Found' : 'Not found'}`);
    console.log(`   Errors: ${Object.values(result.errors).filter(e => e).length} errors\n`);

    // Step 7: Cleanup
    console.log('🧹 Step 7: Cleaning up test data...');
    
    await db.interviews.delete(interview.id);
    console.log(`✅ Test data cleaned up\n`);

    console.log('🎉 All tests passed! ElevenLabs-Supabase integration is working correctly.');

  } catch (error) {
    console.error('❌ Test failed:', error);
    throw error;
  }
}

// Run the test if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  testCompleteDataFlow()
    .then(() => {
      console.log('\n✅ Test completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n❌ Test failed:', error);
      process.exit(1);
    });
}

export { testCompleteDataFlow };
