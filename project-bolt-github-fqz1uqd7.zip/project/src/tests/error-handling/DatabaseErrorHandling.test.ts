/**
 * Database Error Handling Test Suite
 * 
 * Tests error scenarios and graceful fallbacks for:
 * 1. Network connectivity issues
 * 2. Authentication failures
 * 3. Data validation errors
 * 4. Database constraint violations
 * 5. Real-time subscription failures
 */

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { db, supabase } from '../../lib/supabase';
import { useElevenLabsConversation } from '../../hooks/useElevenLabsConversation';
import type { InterviewSetup } from '../../types';

// Mock data
const mockUser = { id: 'test-user-error-handling' };
const mockInterviewSetup: InterviewSetup = {
  jobTitle: 'Software Engineer',
  company: 'Test Company',
  duration: 30,
  experienceLevel: 'mid',
  interviewerName: 'Alex'
};

describe('Database Error Handling', () => {
  beforeEach(() => {
    // Reset all mocks
    vi.clearAllMocks();
  });

  describe('Network Connectivity Issues', () => {
    it('should handle network timeout gracefully', async () => {
      // Mock network timeout
      const originalFetch = global.fetch;
      global.fetch = vi.fn().mockRejectedValue(new Error('Network timeout'));

      try {
        const { data, error } = await db.interviews.create({
          user_id: mockUser.id,
          job_title: mockInterviewSetup.jobTitle,
          company: mockInterviewSetup.company,
          status: 'in_progress'
        });

        // Should handle the error gracefully
        expect(error).toBeDefined();
        expect(data).toBeNull();
      } catch (networkError) {
        // Network errors should be caught and handled
        expect(networkError).toBeDefined();
      } finally {
        global.fetch = originalFetch;
      }
    });

    it('should retry failed database operations', async () => {
      let callCount = 0;
      const mockCreate = vi.fn().mockImplementation(() => {
        callCount++;
        if (callCount < 3) {
          return Promise.reject(new Error('Temporary network error'));
        }
        return Promise.resolve({
          data: { id: 'test-interview', user_id: mockUser.id },
          error: null
        });
      });

      // Mock the database operation
      const originalCreate = db.interviews.create;
      db.interviews.create = mockCreate;

      try {
        // This should succeed after retries
        const result = await retryOperation(() => db.interviews.create({
          user_id: mockUser.id,
          job_title: mockInterviewSetup.jobTitle,
          company: mockInterviewSetup.company,
          status: 'in_progress'
        }), 3);

        expect(result.data).toBeDefined();
        expect(callCount).toBe(3);
      } finally {
        db.interviews.create = originalCreate;
      }
    });
  });

  describe('Authentication Failures', () => {
    it('should handle expired session gracefully', async () => {
      // Mock expired session
      const mockAuth = vi.spyOn(supabase.auth, 'getUser').mockResolvedValue({
        data: { user: null },
        error: { message: 'JWT expired' }
      });

      try {
        const { data, error } = await db.userProfiles.get(mockUser.id);
        
        expect(error).toBeDefined();
        expect(error.message).toContain('JWT expired');
        expect(data).toBeNull();
      } finally {
        mockAuth.mockRestore();
      }
    });

    it('should handle insufficient permissions', async () => {
      // Mock permission denied error
      const mockQuery = vi.fn().mockResolvedValue({
        data: null,
        error: { code: '42501', message: 'Insufficient privileges' }
      });

      const originalFrom = supabase.from;
      supabase.from = vi.fn().mockReturnValue({
        insert: mockQuery,
        select: () => ({ single: mockQuery })
      });

      try {
        const { data, error } = await db.interviews.create({
          user_id: mockUser.id,
          job_title: mockInterviewSetup.jobTitle,
          company: mockInterviewSetup.company,
          status: 'in_progress'
        });

        expect(error).toBeDefined();
        expect(error.code).toBe('42501');
        expect(data).toBeNull();
      } finally {
        supabase.from = originalFrom;
      }
    });
  });

  describe('Data Validation Errors', () => {
    it('should handle invalid data types', async () => {
      try {
        // Attempt to create interview with invalid data
        const { data, error } = await db.interviews.create({
          user_id: null as any, // Invalid user_id
          job_title: '', // Empty required field
          company: '', // Empty required field
          status: 'invalid_status' as any // Invalid status
        });

        expect(error).toBeDefined();
        expect(data).toBeNull();
      } catch (validationError) {
        expect(validationError).toBeDefined();
      }
    });

    it('should handle constraint violations', async () => {
      // Mock unique constraint violation
      const mockQuery = vi.fn().mockResolvedValue({
        data: null,
        error: { 
          code: '23505', 
          message: 'duplicate key value violates unique constraint' 
        }
      });

      const originalFrom = supabase.from;
      supabase.from = vi.fn().mockReturnValue({
        insert: mockQuery,
        select: () => ({ single: mockQuery })
      });

      try {
        const { data, error } = await db.interviews.create({
          user_id: mockUser.id,
          job_title: mockInterviewSetup.jobTitle,
          company: mockInterviewSetup.company,
          status: 'in_progress'
        });

        expect(error).toBeDefined();
        expect(error.code).toBe('23505');
        expect(data).toBeNull();
      } finally {
        supabase.from = originalFrom;
      }
    });

    it('should handle foreign key violations', async () => {
      // Mock foreign key constraint violation
      const mockQuery = vi.fn().mockResolvedValue({
        data: null,
        error: { 
          code: '23503', 
          message: 'insert or update on table violates foreign key constraint' 
        }
      });

      const originalFrom = supabase.from;
      supabase.from = vi.fn().mockReturnValue({
        insert: mockQuery,
        select: () => ({ single: mockQuery })
      });

      try {
        const { data, error } = await db.messages.create({
          interview_id: 'non-existent-interview-id',
          role: 'ai',
          content: 'Test message'
        });

        expect(error).toBeDefined();
        expect(error.code).toBe('23503');
        expect(data).toBeNull();
      } finally {
        supabase.from = originalFrom;
      }
    });
  });

  describe('Real-time Subscription Failures', () => {
    it('should handle subscription connection failures', async () => {
      // Mock subscription failure
      const mockChannel = {
        on: vi.fn().mockReturnThis(),
        subscribe: vi.fn().mockImplementation((callback) => {
          // Simulate connection failure
          setTimeout(() => callback('CHANNEL_ERROR'), 100);
          return Promise.resolve();
        }),
        unsubscribe: vi.fn()
      };

      const originalChannel = supabase.channel;
      supabase.channel = vi.fn().mockReturnValue(mockChannel);

      try {
        const subscription = supabase
          .channel('test-channel')
          .on('postgres_changes', {
            event: '*',
            schema: 'public',
            table: 'messages'
          }, () => {})
          .subscribe((status) => {
            expect(status).toBe('CHANNEL_ERROR');
          });

        // Wait for the mock to trigger
        await new Promise(resolve => setTimeout(resolve, 200));
      } finally {
        supabase.channel = originalChannel;
      }
    });

    it('should handle subscription message parsing errors', async () => {
      const mockCallback = vi.fn();
      const mockChannel = {
        on: vi.fn().mockImplementation((event, config, callback) => {
          // Simulate malformed message
          setTimeout(() => {
            try {
              callback({ malformed: 'data', missing: 'required_fields' });
            } catch (error) {
              // Error should be caught and handled gracefully
              expect(error).toBeDefined();
            }
          }, 100);
          return mockChannel;
        }),
        subscribe: vi.fn().mockResolvedValue('SUBSCRIBED'),
        unsubscribe: vi.fn()
      };

      const originalChannel = supabase.channel;
      supabase.channel = vi.fn().mockReturnValue(mockChannel);

      try {
        supabase
          .channel('test-channel')
          .on('postgres_changes', {
            event: '*',
            schema: 'public',
            table: 'messages'
          }, mockCallback)
          .subscribe();

        // Wait for the mock to trigger
        await new Promise(resolve => setTimeout(resolve, 200));
        
        expect(mockCallback).toHaveBeenCalled();
      } finally {
        supabase.channel = originalChannel;
      }
    });
  });

  describe('Graceful Degradation', () => {
    it('should continue functioning with local storage when database is unavailable', async () => {
      // Mock complete database failure
      const originalFrom = supabase.from;
      supabase.from = vi.fn().mockReturnValue({
        insert: vi.fn().mockRejectedValue(new Error('Database unavailable')),
        select: vi.fn().mockRejectedValue(new Error('Database unavailable')),
        update: vi.fn().mockRejectedValue(new Error('Database unavailable'))
      });

      try {
        // Test local storage fallback
        const localData = {
          interview_id: 'local-interview',
          messages: [
            { id: 1, role: 'ai', content: 'Local message', created_at: new Date().toISOString() }
          ]
        };

        // Store in localStorage as fallback
        localStorage.setItem('interview_backup', JSON.stringify(localData));

        const stored = localStorage.getItem('interview_backup');
        expect(stored).toBeDefined();

        const parsed = JSON.parse(stored!);
        expect(parsed.interview_id).toBe('local-interview');
        expect(parsed.messages).toHaveLength(1);
      } finally {
        supabase.from = originalFrom;
        localStorage.removeItem('interview_backup');
      }
    });

    it('should provide meaningful error messages to users', async () => {
      const errorScenarios = [
        { code: '23505', expectedMessage: 'already in progress' },
        { code: '23503', expectedMessage: 'account not found' },
        { code: '42501', expectedMessage: 'Access denied' },
        { code: 'PGRST301', expectedMessage: 'Connection error' }
      ];

      for (const scenario of errorScenarios) {
        const error = { code: scenario.code, message: `Error ${scenario.code}` };
        const userMessage = getUserFriendlyErrorMessage(error);
        
        expect(userMessage.toLowerCase()).toContain(
          scenario.expectedMessage.toLowerCase()
        );
      }
    });
  });
});

// Helper functions
async function retryOperation<T>(
  operation: () => Promise<T>,
  maxRetries: number = 3,
  delay: number = 1000
): Promise<T> {
  let lastError: Error;
  
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await operation();
    } catch (error) {
      lastError = error as Error;
      if (i < maxRetries - 1) {
        await new Promise(resolve => setTimeout(resolve, delay * (i + 1)));
      }
    }
  }
  
  throw lastError!;
}

function getUserFriendlyErrorMessage(error: { code?: string; message: string }): string {
  switch (error.code) {
    case '23505':
      return 'An interview session is already in progress. Please complete or cancel the existing session first.';
    case '23503':
      return 'User account not found. Please sign in again.';
    case '42501':
      return 'Access denied. Please check your account permissions.';
    case 'PGRST301':
      return 'Connection error. Please check your internet connection and try again.';
    default:
      return 'An unexpected error occurred. Please try again or contact support if the problem persists.';
  }
}
