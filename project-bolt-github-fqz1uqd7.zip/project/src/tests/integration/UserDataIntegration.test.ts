/**
 * User Data Integration Test Suite
 * 
 * Tests user authentication, preferences, and session data synchronization
 * between ElevenLabs interview components and Supabase storage.
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { db, auth } from '../../lib/supabase';
import type { UserProfile, UserPreferences } from '../../types';

// Test user data
const TEST_USER_EMAIL = 'test-integration@example.com';
const TEST_USER_PASSWORD = 'TestPassword123!';
const TEST_USER_ID = 'test-user-integration-' + Date.now();

describe('User Data Integration', () => {
  let testUserId: string;

  beforeEach(async () => {
    // Clean up any existing test data
    await cleanupTestUser();
  });

  afterEach(async () => {
    // Clean up test data
    await cleanupTestUser();
  });

  describe('User Authentication Flow', () => {
    it('should create user profile and preferences on signup', async () => {
      // Note: This test assumes the handle_new_user trigger is working
      // In a real test environment, you would mock the auth signup
      
      // Simulate user profile creation (as would happen via trigger)
      const profileData: Partial<UserProfile> = {
        id: TEST_USER_ID,
        first_name: 'Test',
        last_name: 'User',
        location: 'Test City',
        country: 'Test Country',
        professional_experience: 'Software Engineer',
        onboarding_completed: false
      };

      const { data: profile, error: profileError } = await db.userProfiles.create(
        TEST_USER_ID,
        profileData
      );

      expect(profileError).toBeNull();
      expect(profile).toBeDefined();
      expect(profile.id).toBe(TEST_USER_ID);
      expect(profile.first_name).toBe('Test');
      expect(profile.onboarding_completed).toBe(false);

      testUserId = profile.id;

      // Verify default preferences were created
      const { data: preferences, error: prefError } = await db.userPreferences.get(TEST_USER_ID);

      expect(prefError).toBeNull();
      expect(preferences).toBeDefined();
      expect(preferences.user_id).toBe(TEST_USER_ID);
      expect(preferences.email_notifications).toBe(true);
      expect(preferences.interview_reminders).toBe(true);
      expect(preferences.theme_preference).toBe('light');
    });

    it('should handle user profile updates correctly', async () => {
      // Create initial profile
      await db.userProfiles.create(TEST_USER_ID, {
        id: TEST_USER_ID,
        first_name: 'Initial',
        last_name: 'Name'
      });

      testUserId = TEST_USER_ID;

      // Update profile
      const updateData = {
        first_name: 'Updated',
        last_name: 'Name',
        professional_experience: 'Senior Software Engineer',
        onboarding_completed: true
      };

      const { data: updatedProfile, error } = await db.userProfiles.update(
        TEST_USER_ID,
        updateData
      );

      expect(error).toBeNull();
      expect(updatedProfile).toBeDefined();
      expect(updatedProfile.first_name).toBe('Updated');
      expect(updatedProfile.professional_experience).toBe('Senior Software Engineer');
      expect(updatedProfile.onboarding_completed).toBe(true);
      expect(updatedProfile.updated_at).toBeDefined();
    });
  });

  describe('User Preferences Management', () => {
    beforeEach(async () => {
      // Create test user profile and preferences
      await db.userProfiles.create(TEST_USER_ID, {
        id: TEST_USER_ID,
        first_name: 'Test',
        last_name: 'User'
      });

      await db.userPreferences.initialize(TEST_USER_ID);
      testUserId = TEST_USER_ID;
    });

    it('should update interview-related preferences', async () => {
      const interviewPreferences = {
        camera_verification_enabled: false,
        face_detection_enabled: false,
        voice_id: 'custom-voice-id',
        speech_speed: 1.2,
        microphone_sensitivity: 80,
        noise_cancellation: 'high' as const
      };

      const { data: updated, error } = await db.userPreferences.update(
        TEST_USER_ID,
        interviewPreferences
      );

      expect(error).toBeNull();
      expect(updated).toBeDefined();
      expect(updated.camera_verification_enabled).toBe(false);
      expect(updated.face_detection_enabled).toBe(false);
      expect(updated.voice_id).toBe('custom-voice-id');
      expect(updated.speech_speed).toBe(1.2);
      expect(updated.microphone_sensitivity).toBe(80);
      expect(updated.noise_cancellation).toBe('high');
    });

    it('should handle accessibility preferences', async () => {
      const accessibilityPreferences = {
        high_contrast: true,
        reduce_motion: true,
        font_size: 'large' as const,
        live_captions: true
      };

      const { data: updated, error } = await db.userPreferences.update(
        TEST_USER_ID,
        accessibilityPreferences
      );

      expect(error).toBeNull();
      expect(updated).toBeDefined();
      expect(updated.high_contrast).toBe(true);
      expect(updated.reduce_motion).toBe(true);
      expect(updated.font_size).toBe('large');
      expect(updated.live_captions).toBe(true);
    });
  });

  describe('User Session Management', () => {
    beforeEach(async () => {
      // Create test user profile
      await db.userProfiles.create(TEST_USER_ID, {
        id: TEST_USER_ID,
        first_name: 'Test',
        last_name: 'User'
      });
      testUserId = TEST_USER_ID;
    });

    it('should create and manage interview sessions', async () => {
      // Create interview session
      const { data: session, error } = await db.userSessions.create({
        user_id: TEST_USER_ID,
        session_type: 'interview',
        camera_verified: true,
        face_detected: true
      });

      expect(error).toBeNull();
      expect(session).toBeDefined();
      expect(session.user_id).toBe(TEST_USER_ID);
      expect(session.session_type).toBe('interview');
      expect(session.camera_verified).toBe(true);
      expect(session.face_detected).toBe(true);
      expect(session.started_at).toBeDefined();

      // Update session with verification screenshots
      const screenshots = [
        { timestamp: Date.now(), type: 'face_detection', confidence: 0.95 },
        { timestamp: Date.now() + 1000, type: 'camera_check', status: 'verified' }
      ];

      const { data: updatedSession, error: updateError } = await db.userSessions.update(
        session.id,
        {
          ended_at: new Date().toISOString(),
          verification_screenshots: screenshots
        }
      );

      expect(updateError).toBeNull();
      expect(updatedSession).toBeDefined();
      expect(updatedSession.ended_at).toBeDefined();
      expect(updatedSession.verification_screenshots).toEqual(screenshots);
    });

    it('should retrieve active sessions correctly', async () => {
      // Create multiple sessions
      await db.userSessions.create({
        user_id: TEST_USER_ID,
        session_type: 'practice'
      });

      const { data: activeSession } = await db.userSessions.create({
        user_id: TEST_USER_ID,
        session_type: 'interview'
      });

      // End the first session
      await db.userSessions.update(activeSession.id, {
        ended_at: new Date().toISOString()
      });

      // Create another active session
      const { data: newActiveSession } = await db.userSessions.create({
        user_id: TEST_USER_ID,
        session_type: 'interview'
      });

      // Get active session (should be the most recent one without ended_at)
      const { data: retrieved, error } = await db.userSessions.getActive(TEST_USER_ID);

      expect(error).toBeNull();
      expect(retrieved).toBeDefined();
      expect(retrieved.id).toBe(newActiveSession.id);
      expect(retrieved.ended_at).toBeNull();
    });
  });

  describe('Data Export and Statistics', () => {
    beforeEach(async () => {
      // Create comprehensive test data
      await db.userProfiles.create(TEST_USER_ID, {
        id: TEST_USER_ID,
        first_name: 'Test',
        last_name: 'User',
        professional_experience: 'Software Engineer'
      });

      await db.userPreferences.initialize(TEST_USER_ID);
      testUserId = TEST_USER_ID;

      // Create test interview and scores
      const { data: interview } = await db.interviews.create({
        user_id: TEST_USER_ID,
        job_title: 'Software Engineer',
        company: 'Test Company',
        status: 'completed'
      });

      await db.scores.create({
        interview_id: interview.id,
        clarity: 8,
        confidence: 7,
        relevance: 9,
        communication: 8,
        technical_skills: 7,
        overall_score: 8,
        summary: 'Good performance',
        recommendations: 'Keep practicing',
        professionalism: 9,
        behavioral_appropriateness: 10,
        engagement_level: 8,
        response_quality_trend: 'improving'
      });
    });

    it('should export complete user data', async () => {
      const exportData = await db.exportUserData(TEST_USER_ID);

      expect(exportData).toBeDefined();
      expect(exportData.profile).toBeDefined();
      expect(exportData.preferences).toBeDefined();
      expect(exportData.interviews).toBeDefined();
      expect(exportData.scores).toBeDefined();
      expect(exportData.exportedAt).toBeDefined();

      // Verify data completeness
      expect(exportData.profile.id).toBe(TEST_USER_ID);
      expect(exportData.interviews.length).toBeGreaterThan(0);
      expect(exportData.scores.length).toBeGreaterThan(0);
    });

    it('should calculate user statistics correctly', async () => {
      const stats = await db.userProfiles.getStats(TEST_USER_ID);

      expect(stats).toBeDefined();
      expect(stats.interviews).toBeDefined();
      expect(stats.scores).toBeDefined();
      expect(stats.interviews.length).toBeGreaterThan(0);
      expect(stats.scores.length).toBeGreaterThan(0);

      // Verify interview data
      const interview = stats.interviews[0];
      expect(interview.user_id).toBe(TEST_USER_ID);
      expect(interview.status).toBe('completed');

      // Verify score data
      const score = stats.scores[0];
      expect(score.overall_score).toBe(8);
      expect(score.professionalism).toBe(9);
    });
  });

  // Helper function to clean up test data
  async function cleanupTestUser() {
    try {
      if (testUserId) {
        // Delete user profile (this will cascade delete related data)
        await db.userProfiles.delete(testUserId);
        testUserId = null;
      }

      // Clean up any remaining test data
      const { data: interviews } = await db.interviews.getAll(TEST_USER_ID);
      if (interviews) {
        for (const interview of interviews) {
          await db.interviews.delete(interview.id);
        }
      }
    } catch (error) {
      console.warn('Cleanup error:', error);
    }
  }
});
