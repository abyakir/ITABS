/**
 * ElevenLabs-Supabase Integration Test Suite
 * 
 * Tests the complete interview lifecycle to ensure:
 * 1. Interview records are properly created
 * 2. Messages are correctly stored with metadata
 * 3. Dynamic scoring data is accurately saved
 * 4. Interview completion updates status and duration
 * 5. Real-time subscriptions work correctly
 * 6. Error handling is graceful
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { db, supabase } from '../../lib/supabase';
import { dynamicScoringService } from '../../lib/dynamicScoring';
import type { Interview, Message, Score, InterviewSetup } from '../../types';

// Mock user for testing
const mockUser = {
  id: 'test-user-123',
  email: 'test@example.com'
};

// Mock interview setup
const mockInterviewSetup: InterviewSetup = {
  jobTitle: 'Software Engineer',
  company: 'Test Company',
  duration: 30,
  experienceLevel: 'mid',
  customQuestions: ['Tell me about your experience with React'],
  focusAreas: ['Technical Skills', 'Communication'],
  interviewerName: 'Alex'
};

describe('ElevenLabs-Supabase Integration', () => {
  let testInterview: Interview;
  let testMessages: Message[] = [];

  beforeEach(async () => {
    // Clean up any existing test data
    await cleanupTestData();
  });

  afterEach(async () => {
    // Clean up test data after each test
    await cleanupTestData();
  });

  describe('Interview Lifecycle', () => {
    it('should create interview record with correct schema', async () => {
      // Test interview creation
      const { data: interview, error } = await db.interviews.create({
        user_id: mockUser.id,
        job_title: mockInterviewSetup.jobTitle,
        company: mockInterviewSetup.company,
        status: 'in_progress',
        experience_level: mockInterviewSetup.experienceLevel,
        custom_questions: mockInterviewSetup.customQuestions || [],
        focus_areas: mockInterviewSetup.focusAreas || []
      });

      expect(error).toBeNull();
      expect(interview).toBeDefined();
      expect(interview.id).toBeDefined();
      expect(interview.user_id).toBe(mockUser.id);
      expect(interview.job_title).toBe(mockInterviewSetup.jobTitle);
      expect(interview.company).toBe(mockInterviewSetup.company);
      expect(interview.status).toBe('in_progress');
      expect(interview.experience_level).toBe(mockInterviewSetup.experienceLevel);
      expect(interview.custom_questions).toEqual(mockInterviewSetup.customQuestions);
      expect(interview.focus_areas).toEqual(mockInterviewSetup.focusAreas);
      expect(interview.created_at).toBeDefined();

      testInterview = interview;
    });

    it('should store AI and user messages correctly', async () => {
      // Create interview first
      const { data: interview } = await db.interviews.create({
        user_id: mockUser.id,
        job_title: mockInterviewSetup.jobTitle,
        company: mockInterviewSetup.company,
        status: 'in_progress'
      });

      testInterview = interview;

      // Test AI message creation
      const { data: aiMessage, error: aiError } = await db.messages.create({
        interview_id: interview.id,
        role: 'ai',
        content: 'Hello! Welcome to your interview. Can you tell me about yourself?'
      });

      expect(aiError).toBeNull();
      expect(aiMessage).toBeDefined();
      expect(aiMessage.role).toBe('ai');
      expect(aiMessage.interview_id).toBe(interview.id);
      expect(aiMessage.created_at).toBeDefined();

      // Test user message creation
      const { data: userMessage, error: userError } = await db.messages.create({
        interview_id: interview.id,
        role: 'user',
        content: 'I am a software engineer with 5 years of experience...'
      });

      expect(userError).toBeNull();
      expect(userMessage).toBeDefined();
      expect(userMessage.role).toBe('user');
      expect(userMessage.interview_id).toBe(interview.id);

      testMessages = [aiMessage, userMessage];
    });

    it('should save dynamic scoring data correctly', async () => {
      // Create interview first
      const { data: interview } = await db.interviews.create({
        user_id: mockUser.id,
        job_title: mockInterviewSetup.jobTitle,
        company: mockInterviewSetup.company,
        status: 'in_progress'
      });

      testInterview = interview;

      // Test enhanced scoring data
      const mockScoreData: Omit<Score, 'created_at'> = {
        interview_id: interview.id,
        clarity: 8,
        confidence: 7,
        relevance: 9,
        communication: 8,
        technical_skills: 7,
        overall_score: 8,
        summary: 'Good performance overall',
        recommendations: 'Focus on technical depth',
        professionalism: 9,
        behavioral_appropriateness: 10,
        engagement_level: 8,
        response_quality_trend: 'improving',
        strengths: ['Clear communication', 'Good problem solving'],
        improvements: ['Technical depth', 'More specific examples'],
        real_time_scores: [
          { timestamp: Date.now(), category: 'clarity', score: 8 },
          { timestamp: Date.now(), category: 'confidence', score: 7 }
        ],
        behavioral_incidents: [],
        screen_share_analysis: []
      };

      const { data: score, error } = await db.scores.create(mockScoreData);

      expect(error).toBeNull();
      expect(score).toBeDefined();
      expect(score.interview_id).toBe(interview.id);
      expect(score.professionalism).toBe(9);
      expect(score.behavioral_appropriateness).toBe(10);
      expect(score.engagement_level).toBe(8);
      expect(score.response_quality_trend).toBe('improving');
      expect(score.strengths).toEqual(mockScoreData.strengths);
      expect(score.improvements).toEqual(mockScoreData.improvements);
      expect(score.real_time_scores).toEqual(mockScoreData.real_time_scores);
    });

    it('should update interview completion status correctly', async () => {
      // Create interview first
      const { data: interview } = await db.interviews.create({
        user_id: mockUser.id,
        job_title: mockInterviewSetup.jobTitle,
        company: mockInterviewSetup.company,
        status: 'in_progress'
      });

      testInterview = interview;

      // Simulate interview completion
      const completedAt = new Date().toISOString();
      const durationMinutes = 25;

      const { data: updatedInterview, error } = await db.interviews.update(interview.id, {
        status: 'completed',
        completed_at: completedAt,
        duration_minutes: durationMinutes
      });

      expect(error).toBeNull();
      expect(updatedInterview).toBeDefined();
      expect(updatedInterview.status).toBe('completed');
      expect(updatedInterview.completed_at).toBe(completedAt);
      expect(updatedInterview.duration_minutes).toBe(durationMinutes);
    });
  });

  describe('Data Relationships', () => {
    it('should retrieve interview with all related data', async () => {
      // Create interview
      const { data: interview } = await db.interviews.create({
        user_id: mockUser.id,
        job_title: mockInterviewSetup.jobTitle,
        company: mockInterviewSetup.company,
        status: 'completed'
      });

      testInterview = interview;

      // Create messages
      await db.messages.create({
        interview_id: interview.id,
        role: 'ai',
        content: 'Test AI message'
      });

      await db.messages.create({
        interview_id: interview.id,
        role: 'user',
        content: 'Test user response'
      });

      // Create score
      await db.scores.create({
        interview_id: interview.id,
        clarity: 8,
        confidence: 7,
        relevance: 9,
        communication: 8,
        technical_skills: 7,
        overall_score: 8,
        summary: 'Test summary',
        recommendations: 'Test recommendations',
        professionalism: 9,
        behavioral_appropriateness: 10,
        engagement_level: 8,
        response_quality_trend: 'stable'
      });

      // Test getWithDetails
      const result = await db.interviews.getWithDetails(interview.id);

      expect(result.interview).toBeDefined();
      expect(result.messages).toHaveLength(2);
      expect(result.score).toBeDefined();
      expect(result.errors.interview).toBeNull();
      expect(result.errors.messages).toBeNull();
      expect(result.errors.score).toBeNull();
    });
  });

  // Helper function to clean up test data
  async function cleanupTestData() {
    try {
      // Delete test messages
      if (testMessages.length > 0) {
        for (const message of testMessages) {
          await db.messages.delete(message.id);
        }
        testMessages = [];
      }

      // Delete test interview (this will cascade delete related data)
      if (testInterview?.id) {
        await db.interviews.delete(testInterview.id);
        testInterview = null;
      }

      // Clean up any test interviews by user
      const { data: interviews } = await db.interviews.getAll(mockUser.id);
      if (interviews) {
        for (const interview of interviews) {
          await db.interviews.delete(interview.id);
        }
      }
    } catch (error) {
      console.warn('Cleanup error:', error);
    }
  }
});
