/**
 * Complete End-to-End Integration Test
 * 
 * Tests the complete user journey from setup → interview → results
 * to confirm all Supabase integrations work seamlessly with the 
 * ElevenLabs conversational AI system.
 */

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { db, realtime } from '../../lib/supabase';
import { dynamicScoringService } from '../../lib/dynamicScoring';
import type { InterviewSetup, Interview, Message, Score } from '../../types';

// Test configuration
const E2E_TEST_USER_ID = 'e2e-test-user-' + Date.now();
const E2E_INTERVIEW_SETUP: InterviewSetup = {
  jobTitle: 'Senior Full-Stack Developer',
  company: 'TechCorp Solutions',
  duration: 30,
  experienceLevel: 'senior',
  customQuestions: [
    'Describe your experience with microservices architecture',
    'How do you handle performance optimization in React applications?',
    'Tell me about a challenging technical problem you solved recently'
  ],
  focusAreas: ['Technical Leadership', 'System Design', 'React/Node.js'],
  interviewerName: 'Alex'
};

describe('Complete ElevenLabs-Supabase Integration E2E Test', () => {
  let testInterview: Interview;
  let testMessages: Message[] = [];
  let testScore: Score;
  let realtimeSubscription: any;

  beforeAll(async () => {
    console.log('🚀 Starting Complete Integration Test...');
    
    // Create test user profile
    await db.userProfiles.create(E2E_TEST_USER_ID, {
      id: E2E_TEST_USER_ID,
      first_name: 'E2E',
      last_name: 'TestUser',
      professional_experience: 'Senior Software Engineer',
      onboarding_completed: true
    });

    // Initialize user preferences
    await db.userPreferences.initialize(E2E_TEST_USER_ID);
  });

  afterAll(async () => {
    console.log('🧹 Cleaning up E2E test data...');
    
    // Clean up real-time subscription
    if (realtimeSubscription) {
      realtimeSubscription.unsubscribe();
    }

    // Clean up test data
    if (testInterview?.id) {
      await db.interviews.delete(testInterview.id);
    }
    
    await db.userProfiles.delete(E2E_TEST_USER_ID);
  });

  it('should complete the full interview lifecycle successfully', async () => {
    console.log('\n📝 Step 1: Creating interview from setup...');
    
    // Step 1: Create interview from setup
    const { data: interview, error: interviewError } = await db.interviews.create({
      user_id: E2E_TEST_USER_ID,
      job_title: E2E_INTERVIEW_SETUP.jobTitle,
      company: E2E_INTERVIEW_SETUP.company,
      status: 'in_progress',
      experience_level: E2E_INTERVIEW_SETUP.experienceLevel,
      duration: E2E_INTERVIEW_SETUP.duration,
      custom_questions: E2E_INTERVIEW_SETUP.customQuestions || [],
      focus_areas: E2E_INTERVIEW_SETUP.focusAreas || []
    });

    expect(interviewError).toBeNull();
    expect(interview).toBeDefined();
    expect(interview.job_title).toBe(E2E_INTERVIEW_SETUP.jobTitle);
    expect(interview.company).toBe(E2E_INTERVIEW_SETUP.company);
    expect(interview.status).toBe('in_progress');
    
    testInterview = interview;
    console.log(`✅ Interview created: ${interview.id}`);

    console.log('\n🔄 Step 2: Setting up real-time subscriptions...');
    
    // Step 2: Set up real-time message subscription
    const messageUpdates: any[] = [];
    realtimeSubscription = realtime.subscribeToInterview(
      interview.id,
      (payload) => {
        console.log('📨 Real-time update received:', payload.eventType);
        messageUpdates.push(payload);
      }
    );

    // Wait for subscription to be established
    await new Promise(resolve => setTimeout(resolve, 1000));
    console.log('✅ Real-time subscription established');

    console.log('\n💬 Step 3: Simulating conversation flow...');
    
    // Step 3: Simulate complete conversation
    const conversationFlow = [
      {
        role: 'ai',
        content: `Hi there! I'm ${E2E_INTERVIEW_SETUP.interviewerName} from ${E2E_INTERVIEW_SETUP.company}. Welcome to your interview for the ${E2E_INTERVIEW_SETUP.jobTitle} position. I'm excited to learn more about your experience. Can you start by telling me about yourself and your background in software development?`
      },
      {
        role: 'user',
        content: 'Thank you for having me! I\'m a senior full-stack developer with over 8 years of experience. I\'ve worked extensively with React, Node.js, and cloud technologies. I\'ve led several teams and have a strong background in system architecture and performance optimization. I\'m passionate about building scalable applications and mentoring junior developers.'
      },
      {
        role: 'ai',
        content: 'That\'s impressive! I\'d love to hear more about your experience with microservices architecture. Can you describe a project where you implemented microservices and the challenges you faced?'
      },
      {
        role: 'user',
        content: 'Absolutely! In my previous role, I led the migration of a monolithic e-commerce platform to microservices. We broke it down into 12 services including user management, inventory, payments, and notifications. The main challenges were data consistency, service communication, and monitoring. We used event sourcing for data consistency, implemented circuit breakers for resilience, and used distributed tracing for monitoring. The result was a 40% improvement in deployment frequency and 60% reduction in system downtime.'
      },
      {
        role: 'ai',
        content: 'Excellent! Now, regarding React performance optimization - what strategies do you use to ensure optimal performance in large React applications?'
      },
      {
        role: 'user',
        content: 'Great question! I use several strategies: React.memo for component memoization, useMemo and useCallback for expensive calculations, code splitting with React.lazy, virtual scrolling for large lists, and proper state management to avoid unnecessary re-renders. I also implement performance monitoring with tools like React DevTools Profiler and Web Vitals. In one project, these optimizations reduced initial load time by 50% and improved user interaction metrics significantly.'
      },
      {
        role: 'ai',
        content: 'That\'s comprehensive! Can you tell me about a particularly challenging technical problem you solved recently?'
      },
      {
        role: 'user',
        content: 'Recently, I tackled a complex race condition in our real-time collaboration feature. Multiple users were editing documents simultaneously, causing data conflicts and lost changes. I implemented operational transformation with conflict-free replicated data types (CRDTs), added optimistic updates with rollback mechanisms, and created a robust synchronization protocol. The solution required deep understanding of distributed systems and careful state management. It took 3 weeks to implement but eliminated all data conflicts and improved user experience dramatically.'
      },
      {
        role: 'ai',
        content: 'Outstanding! Thank you for sharing those detailed examples. Your experience with system architecture, performance optimization, and problem-solving is exactly what we\'re looking for. Do you have any questions about the role or our team?'
      },
      {
        role: 'user',
        content: 'Thank you! I\'d love to know more about the team structure and the technical challenges you\'re currently facing. Also, what opportunities are there for technical leadership and mentoring?'
      },
      {
        role: 'ai',
        content: 'Great questions! Our team consists of 15 engineers across 3 squads. We\'re currently scaling our platform to handle 10x traffic growth and modernizing our data pipeline. There are excellent opportunities for technical leadership - we\'re looking for someone to lead our architecture guild and mentor our growing team of mid-level developers. Thank you for your time today. We\'ll be in touch soon with next steps!'
      }
    ];

    // Create messages and track real-time updates
    for (let i = 0; i < conversationFlow.length; i++) {
      const messageData = conversationFlow[i];
      
      const { data: message, error: messageError } = await db.messages.create({
        interview_id: interview.id,
        role: messageData.role as 'ai' | 'user',
        content: messageData.content
      });

      expect(messageError).toBeNull();
      expect(message).toBeDefined();
      expect(message.content).toBe(messageData.content);
      expect(message.role).toBe(messageData.role);
      
      testMessages.push(message);
      
      // Small delay to simulate real conversation timing
      await new Promise(resolve => setTimeout(resolve, 200));
    }

    console.log(`✅ Created ${testMessages.length} conversation messages`);

    // Verify real-time updates were received
    await new Promise(resolve => setTimeout(resolve, 1000));
    expect(messageUpdates.length).toBeGreaterThan(0);
    console.log(`✅ Received ${messageUpdates.length} real-time updates`);

    console.log('\n📊 Step 4: Generating dynamic scores...');
    
    // Step 4: Initialize and run dynamic scoring
    dynamicScoringService.initialize(interview.id, {
      jobTitle: E2E_INTERVIEW_SETUP.jobTitle,
      experienceLevel: E2E_INTERVIEW_SETUP.experienceLevel || 'mid',
      focusAreas: E2E_INTERVIEW_SETUP.focusAreas || []
    });

    // Analyze user responses
    const userResponses = conversationFlow.filter(msg => msg.role === 'user');
    for (let i = 0; i < userResponses.length; i++) {
      const response = userResponses[i];
      const responseTime = 2000 + Math.random() * 3000; // 2-5 seconds
      
      await dynamicScoringService.analyzeResponse(
        response.content,
        i + 1,
        responseTime
      );
    }

    const finalScores = dynamicScoringService.getFinalScores();
    console.log('📊 Dynamic scoring completed:');
    console.log(`   - Overall Score: ${finalScores.overall_score}/10`);
    console.log(`   - Technical Skills: ${finalScores.technical_skills}/10`);
    console.log(`   - Communication: ${finalScores.communication}/10`);
    console.log(`   - Professionalism: ${finalScores.professionalism}/10`);

    console.log('\n💾 Step 5: Saving final scores...');
    
    // Step 5: Save comprehensive scores
    const { data: score, error: scoreError } = await db.scores.create({
      interview_id: interview.id,
      ...finalScores,
      summary: 'Exceptional candidate with strong technical expertise and leadership experience. Demonstrated deep understanding of system architecture, performance optimization, and problem-solving. Excellent communication skills and ability to explain complex technical concepts clearly.',
      recommendations: 'Highly recommend for senior role. Consider for technical leadership position. Strong candidate for architecture guild leadership and mentoring responsibilities.',
      strengths: [
        'Deep technical expertise in full-stack development',
        'Strong system architecture and microservices experience',
        'Excellent problem-solving and analytical skills',
        'Clear communication and ability to explain complex concepts',
        'Leadership experience and mentoring capabilities',
        'Performance optimization expertise'
      ],
      improvements: [
        'Could explore more about team management methodologies',
        'Discuss experience with specific cloud platforms in more detail'
      ],
      real_time_scores: [
        { timestamp: Date.now() - 30000, category: 'clarity', score: 9 },
        { timestamp: Date.now() - 25000, category: 'confidence', score: 8 },
        { timestamp: Date.now() - 20000, category: 'technical_skills', score: 9 },
        { timestamp: Date.now() - 15000, category: 'communication', score: 9 },
        { timestamp: Date.now() - 10000, category: 'professionalism', score: 10 },
        { timestamp: Date.now() - 5000, category: 'engagement_level', score: 9 }
      ],
      behavioral_incidents: [], // No incidents - professional throughout
      screen_share_analysis: [] // No screen sharing in this interview
    });

    expect(scoreError).toBeNull();
    expect(score).toBeDefined();
    expect(score.overall_score).toBeGreaterThan(7); // Should be a strong score
    expect(score.strengths).toBeDefined();
    expect(score.improvements).toBeDefined();
    expect(score.real_time_scores).toBeDefined();
    
    testScore = score;
    console.log(`✅ Scores saved with overall score: ${score.overall_score}/10`);

    console.log('\n🏁 Step 6: Completing interview...');
    
    // Step 6: Complete the interview
    const completedAt = new Date().toISOString();
    const durationMinutes = 28; // Realistic interview duration

    const { data: completedInterview, error: updateError } = await db.interviews.update(interview.id, {
      status: 'completed',
      completed_at: completedAt,
      duration_minutes: durationMinutes
    });

    expect(updateError).toBeNull();
    expect(completedInterview).toBeDefined();
    expect(completedInterview.status).toBe('completed');
    expect(completedInterview.completed_at).toBe(completedAt);
    expect(completedInterview.duration_minutes).toBe(durationMinutes);
    
    console.log(`✅ Interview completed in ${durationMinutes} minutes`);

    console.log('\n🔍 Step 7: Verifying complete data retrieval...');
    
    // Step 7: Test complete data retrieval
    const result = await db.interviews.getWithDetails(interview.id);
    
    expect(result.interview).toBeDefined();
    expect(result.interview.id).toBe(interview.id);
    expect(result.interview.status).toBe('completed');
    
    expect(result.messages).toBeDefined();
    expect(result.messages.length).toBe(conversationFlow.length);
    
    expect(result.score).toBeDefined();
    expect(result.score.overall_score).toBe(score.overall_score);
    
    expect(result.errors.interview).toBeNull();
    expect(result.errors.messages).toBeNull();
    expect(result.errors.score).toBeNull();
    
    console.log('✅ Complete data retrieval verified');
    console.log(`   - Interview: ${result.interview ? 'Found' : 'Missing'}`);
    console.log(`   - Messages: ${result.messages?.length || 0} entries`);
    console.log(`   - Score: ${result.score ? 'Found' : 'Missing'}`);

    console.log('\n📈 Step 8: Testing analytics and statistics...');
    
    // Step 8: Test user statistics
    const userStats = await db.userProfiles.getStats(E2E_TEST_USER_ID);
    
    expect(userStats).toBeDefined();
    expect(userStats.interviews).toBeDefined();
    expect(userStats.interviews.length).toBeGreaterThan(0);
    expect(userStats.scores).toBeDefined();
    expect(userStats.scores.length).toBeGreaterThan(0);
    
    const userInterview = userStats.interviews.find(i => i.id === interview.id);
    expect(userInterview).toBeDefined();
    expect(userInterview?.status).toBe('completed');
    
    const userScore = userStats.scores.find(s => s.interview_id === interview.id);
    expect(userScore).toBeDefined();
    expect(userScore?.overall_score).toBe(score.overall_score);
    
    console.log('✅ Analytics and statistics verified');
    console.log(`   - User has ${userStats.interviews.length} interviews`);
    console.log(`   - User has ${userStats.scores.length} scores`);
    console.log(`   - Average score: ${userStats.scores.reduce((sum, s) => sum + s.overall_score, 0) / userStats.scores.length}/10`);

    console.log('\n🎉 Complete Integration Test PASSED!');
    console.log('All ElevenLabs-Supabase integrations are working correctly.');
  });
});
