export function Home() {
  return (
    <>
      {/* Hero Section */}
      <HeroSection />
      
      {/* Features Section */}
      <FeaturesHighlight />
      
      {/* Feature Highlight Section */}
      <FeatureSection />
      
      {/* Testimonials Section */}
      <TestimonialsSection />
      
      {/* Call to Action */}
      <CallToAction />
    </>
  );
}

// Import the components
import { HeroSection } from '../components/landing/HeroSection';
import { FeatureSection } from '../components/landing/FeatureSection';
import { FeaturesHighlight } from '../components/landing/FeaturesHighlight';
import { TestimonialsSection } from '../components/landing/TestimonialsSection';
import { CallToAction } from '../components/landing/CallToAction';