import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Briefcase, 
  Building, 
  Clock, 
  Target, 
  FileText, 
  ChevronRight, 
  Play, 
  Plus, 
  X, 
  ArrowRight,
  Users,
  Mic,
  Settings
} from 'lucide-react';
import { motion } from 'framer-motion';

// UI Components
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { FileUpload } from '../components/ui/FileUpload';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Tabs } from '../components/ui/Tabs';
import { Dropdown } from '../components/ui/Dropdown';

// Dashboard Components
import { StatCard } from '../components/dashboard/StatCard';
import { InterviewCard } from '../components/dashboard/InterviewCard';

// Dashboard Configuration
import DashboardSetup from '../components/DashboardSetup';

// Hooks
import { useAuth } from '../hooks/useAuth';
import { storeInterviewData } from '../lib/utils';
import type { InterviewSetup } from '../types';
import toast from 'react-hot-toast';

export function Setup() {
  const { user } = useAuth();
  const navigate = useNavigate();
  
  // Interview Setup State
  const [setup, setSetup] = useState<InterviewSetup>({
    jobTitle: '',
    company: '',
    experienceLevel: 'mid',
    duration: 30
  });
  
  const [customQuestions, setCustomQuestions] = useState<string[]>([]);
  const [newQuestion, setNewQuestion] = useState('');
  const [resumeFile, setResumeFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  // Track stage with a ref to avoid synchronization issues
  const [currentStage, setCurrentStage] = useState(1);
  const stageRef = useRef(1);

  // Pre-defined options
  const industries = [
    'Technology', 'Finance', 'Healthcare', 'Marketing', 'Sales',
    'Engineering', 'Design', 'Operations', 'Consulting', 'Education'
  ];

  const jobRoles = [
    'Software Engineer', 'Product Manager', 'Data Scientist', 'Marketing Manager',
    'Sales Representative', 'UX Designer', 'Business Analyst', 'Project Manager',
    'Financial Analyst', 'Operations Manager'
  ];

  // Focus areas for interviews
  const focusAreas = [
    { value: 'technical', label: 'Technical Skills' },
    { value: 'behavioral', label: 'Behavioral Questions' },
    { value: 'problem_solving', label: 'Problem Solving' },
    { value: 'communication', label: 'Communication' },
    { value: 'leadership', label: 'Leadership' },
    { value: 'culture_fit', label: 'Culture Fit' }
  ];

  const [selectedFocusAreas, setSelectedFocusAreas] = useState<string[]>([]);

  // Handle adding/removing custom questions
  const handleAddQuestion = () => {
    if (newQuestion.trim()) {
      setCustomQuestions([...customQuestions, newQuestion.trim()]);
      setNewQuestion('');
    }
  };

  const handleRemoveQuestion = (index: number) => {
    setCustomQuestions(customQuestions.filter((_, i) => i !== index));
  };

  // Handle focus area selection
  const toggleFocusArea = (area: string) => {
    if (selectedFocusAreas.includes(area)) {
      setSelectedFocusAreas(selectedFocusAreas.filter(a => a !== area));
    } else {
      setSelectedFocusAreas([...selectedFocusAreas, area]);
    }
  };

  // Start interview
  const handleStartInterview = async (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    // Prevent default button behavior to avoid page refresh
    e.preventDefault();
    
    if (!setup.jobTitle || !setup.company) {
      toast.error('Please fill in job title and company');
      console.log('Missing job title or company');
      return;
    }

    if (!user) {
      toast.error('Please sign in to start interview');
      console.log('User not authenticated');
      return;
    }

    setLoading(true);
    try {
      console.log('Starting interview with setup:', {
        jobTitle: setup.jobTitle,
        company: setup.company || 'Unknown Company',
        duration: setup.duration || 30,
        experienceLevel: setup.experienceLevel || 'mid',
      });
      
      // Create a focus areas array from the selected focus areas
      const focusAreasArray = selectedFocusAreas.map(area => 
        focusAreas.find(f => f.value === area)?.label || area
      );
      
      // Store interview data in localStorage to persist between navigation
      const interviewData = {
        jobTitle: setup.jobTitle,
        company: setup.company,
        duration: setup.duration,
        experienceLevel: setup.experienceLevel,
        customQuestions: customQuestions,
        focusAreas: focusAreasArray,
        interviewerName: 'Alex'
      };
      
      storeInterviewData(interviewData);

      // Ask user which interview experience they want to try
      const useEnhanced = window.confirm(
        'Would you like to try the enhanced job interview experience with connection verification and assessment report? (Click OK for enhanced, Cancel for standard)'
      );
      
      if (useEnhanced) {
        // Navigate to the new job interview experience
        navigate(`/job-interview/new`, {
          replace: true,
          state: {
            fromSetup: true,
            interviewData
          }
        });
      } else {
        // Navigate to standard ElevenLabs interview
        navigate(`/elevenlabs-interview/new`, {
          replace: true,
          state: {
            fromSetup: true,
            interviewData
          }
        });
      }
    } catch (error: any) {
      console.error('Setup error:', error);
      toast.error(error.message || 'Failed to start interview');
    } finally {
      setLoading(false);
    }
  };

  // Navigation between steps
  const nextStage = () => {
    const nextStageNumber = Math.min(stageRef.current + 1, 4);
    stageRef.current = nextStageNumber;
    setCurrentStage(nextStageNumber);
    
    // Update the tab selection to match the stage
    const stageToTabMap: Record<number, string> = {
      1: 'basic',
      2: 'details',
      3: 'custom',
      4: 'review'
    };
    
    // Log stage transition for debugging
    console.log(`Moving to stage ${nextStageNumber}: ${stageToTabMap[nextStageNumber]}`);
  };
  
  const prevStage = () => {
    const prevStageNumber = Math.max(stageRef.current - 1, 1);
    stageRef.current = prevStageNumber;
    setCurrentStage(prevStageNumber);
    
    // Update the tab selection to match the stage
    const stageToTabMap: Record<number, string> = {
      1: 'basic',
      2: 'details',
      3: 'custom',
      4: 'review'
    };
    
    // Log stage transition for debugging
    console.log(`Moving back to stage ${prevStageNumber}: ${stageToTabMap[prevStageNumber]}`);
  };
  
  // Maintain synchronization between stage number and tab selection
  useEffect(() => {
    // This ensures the stage number and tab selection stay in sync
    stageRef.current = currentStage;
  }, [currentStage]);

  // Setup page tabs
  const setupTabs = [
    {
      id: 'basic',
      label: 'Basic Info',
      content: (
        <StepOne 
          setup={setup} 
          setSetup={setSetup} 
          jobRoles={jobRoles}
          industries={industries}
        />
      )
    },
    {
      id: 'details',
      label: 'Interview Details',
      content: (
        <StepTwo
          setup={setup}
          setSetup={setSetup}
          selectedFocusAreas={selectedFocusAreas}
          toggleFocusArea={toggleFocusArea}
          focusAreas={focusAreas}
        />
      )
    },
    {
      id: 'custom',
      label: 'Custom Content',
      content: (
        <StepThree
          customQuestions={customQuestions}
          newQuestion={newQuestion}
          setNewQuestion={setNewQuestion}
          handleAddQuestion={handleAddQuestion}
          handleRemoveQuestion={handleRemoveQuestion}
          resumeFile={resumeFile}
          setResumeFile={setResumeFile}
        />
      )
    },
    {
      id: 'review',
      label: 'Review',
      content: (
        <StepFour
          setup={setup}
          customQuestions={customQuestions}
          resumeFile={resumeFile}
          selectedFocusAreas={selectedFocusAreas}
          focusAreas={focusAreas}
          handleStartInterview={handleStartInterview}
          loading={loading}
        />
      )
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-purple-700 py-12">
      <div className="max-w-5xl mx-auto px-6">
        {/* Modern Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-white mb-4">
            Interview Setup
          </h1>
          <p className="text-xl text-white/80">
            Customize your AI interview experience for the best practice session
          </p>
        </div>

        {/* Modern Progress Steps */}
        <div className="flex items-center justify-center mb-12">
          {[1, 2, 3, 4].map((step) => (
            <div key={step} className="flex items-center">
              <div className={`
                w-14 h-14 rounded-2xl flex items-center justify-center font-bold text-lg shadow-lg transition-all duration-300 relative
                ${currentStage >= step
                  ? 'bg-white text-purple-600 shadow-xl'
                  : 'bg-white/20 text-white/60'
                }
              `}>
                {step}
                {currentStage === step && (
                  <span className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full animate-pulse"></span>
                )}
              </div>
              {step < 4 && (
                <div className={`
                  w-20 h-2 mx-3 rounded-full transition-all duration-300
                  ${currentStage > step ? 'bg-white' : 'bg-white/20'}
                `} />
              )}
            </div>
          ))}
        </div>

        <Card className="bg-white/95 backdrop-blur-sm border border-white/20 shadow-xl rounded-3xl overflow-hidden">
          <CardContent className="p-0">
            <Tabs
              tabs={setupTabs}
              defaultTab={`${currentStage === 1 ? 'basic' : currentStage === 2 ? 'details' : currentStage === 3 ? 'custom' : 'review'}`}
              variant="underline"
              className="p-8"
              onChange={(tabId) => {
                // Create a mapping from tabId to stage number
                const stepMap: Record<string, number> = {
                  'basic': 1,
                  'details': 2,
                  'custom': 3,
                  'review': 4
                };
                const newStage = stepMap[tabId] || 1;
                
                // Update both the state and the ref to maintain synchronization
                setCurrentStage(newStage);
                stageRef.current = newStage;
                
                // Log stage change for debugging
                console.log(`Tab changed to ${tabId}, stage set to ${newStage}`);
              }}
            />
          </CardContent>

          {/* Navigation buttons */}
          <div className="flex justify-between p-8 pt-0">
            <Button
              onClick={prevStage}
              disabled={currentStage === 1}
              variant="outline"
              className="px-6"
            >
              Previous
            </Button>

            {currentStage < 4 ? (
              <Button
                onClick={nextStage}
                disabled={currentStage === 1 && (!setup.jobTitle || !setup.company)}
                className="px-6"
                icon={<ChevronRight className="w-5 h-5" />}
                iconPosition="right"
              >
                Next
              </Button>
            ) : (
              <Button
                onClick={handleStartInterview}
                disabled={loading || !setup.jobTitle || !setup.company || !user}
                className="px-8 py-3 bg-gradient-to-r from-purple-600 to-indigo-600"
                loading={loading}
                icon={<Play className="w-5 h-5" />}
              >
                Start Interview
              </Button>
            )}
          </div>
        </Card>
        
        {/* Stage debugging info - only visible in development mode */}
        {import.meta.env.DEV && (
          <div className="fixed top-4 right-4 bg-gray-800/80 text-white text-xs p-2 rounded-lg z-50">
            <div>Current Stage: {currentStage}</div>
            <div>Stage Ref: {stageRef.current}</div>
          </div>
        )}
      </div>
    </div>
  );
}

// Step 1: Basic Information
const StepOne = ({ 
  setup, 
  setSetup, 
  jobRoles, 
  industries 
}: { 
  setup: InterviewSetup, 
  setSetup: React.Dispatch<React.SetStateAction<InterviewSetup>>,
  jobRoles: string[],
  industries: string[]
}) => {
  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <div className="w-24 h-24 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-lg transform transition-transform hover:scale-105 hover:rotate-3 relative">
          <div className="absolute inset-0 bg-white opacity-10 blur-xl rounded-3xl"></div>
          <Briefcase className="w-10 h-10 text-white" />
        </div>
        <motion.h2 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-3xl font-bold text-gray-900 mb-3"
        >
          Basic Information
        </motion.h2>
        <motion.p 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-lg text-gray-600"
        >
          Tell us about the position you're interviewing for
        </motion.p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <Input
            label="Job Title"
            value={setup.jobTitle}
            onChange={(e) => setSetup(prev => ({ ...prev, jobTitle: e.target.value }))}
            placeholder="e.g., Software Engineer"
            required
          />
          <div className="mt-3">
            <p className="text-sm text-gray-600 mb-3">Popular roles:</p>
            <div className="flex flex-wrap gap-2">
              {jobRoles.slice(0, 4).map((role) => (
                <button
                  key={role}
                  onClick={() => setSetup(prev => ({ ...prev, jobTitle: role }))}
                  className="px-4 py-2 text-sm bg-gradient-to-r from-purple-100 to-blue-100 hover:from-purple-200 hover:to-blue-200 text-gray-900 rounded-xl transition-all duration-200 border border-purple-200/50"
                >
                  {role}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div>
          <Input
            label="Company"
            value={setup.company}
            onChange={(e) => setSetup(prev => ({ ...prev, company: e.target.value }))}
            placeholder="e.g., Google, Microsoft, Startup"
            required
          />
          <div className="mt-3">
            <p className="text-sm text-gray-600 mb-3">Industries:</p>
            <div className="flex flex-wrap gap-2">
              {industries.slice(0, 4).map((industry) => (
                <button
                  key={industry}
                  onClick={() => setSetup(prev => ({ ...prev, company: industry }))}
                  className="px-4 py-2 text-sm bg-gradient-to-r from-purple-100 to-blue-100 hover:from-purple-200 hover:to-blue-200 text-gray-900 rounded-xl transition-all duration-200 border border-purple-200/50"
                >
                  {industry}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div>
        <label className="block text-lg font-semibold text-gray-900 mb-4">
          Experience Level
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          {[
            { value: 'entry', label: 'Entry Level', desc: '0-2 years' },
            { value: 'mid', label: 'Mid Level', desc: '3-7 years' },
            { value: 'senior', label: 'Senior Level', desc: '8+ years' }
          ].map((level) => (
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.98 }}
              key={level.value}
              onClick={() => setSetup(prev => ({ ...prev, experienceLevel: level.value as any }))}
              className={`
                p-6 border-2 rounded-2xl text-center transition-all duration-300
                ${setup.experienceLevel === level.value
                  ? 'border-purple-500 bg-gradient-to-br from-purple-50 to-blue-50 text-purple-700 shadow-xl'
                  : 'border-gray-200 hover:border-purple-300 hover:bg-purple-50/50 hover:shadow-md'
                }
              `}
            >
              <div className="font-bold text-lg mb-1">{level.label}</div>
              <div className="text-sm text-gray-600 mt-1 pb-1">{level.desc}</div>
              {setup.experienceLevel === level.value && (
                <motion.div 
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="w-3 h-3 bg-purple-500 rounded-full mx-auto mt-2"
                />
              )}
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  );
};

// Step 2: Interview Details
const StepTwo = ({ 
  setup, 
  setSetup, 
  selectedFocusAreas,
  toggleFocusArea,
  focusAreas
}: { 
  setup: InterviewSetup, 
  setSetup: React.Dispatch<React.SetStateAction<InterviewSetup>>,
  selectedFocusAreas: string[],
  toggleFocusArea: (area: string) => void,
  focusAreas: { value: string, label: string }[]
}) => {
  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <div className="w-24 h-24 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-lg transform transition-transform hover:scale-105 hover:rotate-3 relative">
          <div className="absolute inset-0 bg-white opacity-10 blur-xl rounded-3xl"></div>
          <Settings className="w-10 h-10 text-white" />
        </div>
        <motion.h2 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-3xl font-bold text-gray-900 mb-3"
        >
          Interview Configuration
        </motion.h2>
        <motion.p 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-lg text-gray-600"
        >
          Set up your interview parameters
        </motion.p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-3">
            Duration (minutes)
          </label>
          <div className="grid grid-cols-2 gap-3">
            {[15, 30, 45, 60].map((duration) => (
              <button
                key={duration}
                onClick={() => setSetup(prev => ({ ...prev, duration }))}
                className={`
                  p-3 border-2 rounded-lg text-center transition-colors
                  ${setup.duration === duration
                    ? 'border-indigo-600 bg-indigo-50 text-indigo-700'
                    : 'border-gray-200 hover:border-gray-300'
                  }
                `}
              >
                {duration} min
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-3">
            AI Interview System
          </label>
          <div className="p-4 border-2 border-indigo-600 bg-indigo-50 rounded-lg text-center">
            <div className="font-semibold text-indigo-700">ElevenLabs AI Agent</div>
            <div className="text-sm text-indigo-600">Advanced conversational AI with real-time interaction</div>
          </div>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-3">
          Focus Areas
        </label>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          <motion.div
            className="grid grid-cols-2 md:grid-cols-3 gap-3 w-full"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ staggerChildren: 0.05 }}
          >
            {focusAreas.map((area) => (
              <motion.button
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                key={area.value}
                onClick={() => toggleFocusArea(area.value)}
                className={`
                  p-4 border-2 rounded-lg text-center transition-all duration-200 flex flex-col items-center
                  ${selectedFocusAreas.includes(area.value)
                    ? 'border-indigo-600 bg-indigo-50 text-indigo-700 shadow-md'
                    : 'border-gray-200 hover:border-indigo-300 hover:shadow-sm'
                  }
                `}
              >
                <span className="font-medium">{area.label}</span>
                {selectedFocusAreas.includes(area.value) && (
                  <Badge variant="primary" size="sm" className="mt-2 animate-fadeIn">Selected</Badge>
                )}
              </motion.button>
            ))}
          </motion.div>
        </div>
        <p className="text-xs text-gray-500 mt-2">
          Select areas to focus on during your interview. This will help the AI tailor questions accordingly.
        </p>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h4 className="font-semibold text-blue-900 mb-2">Scoring Criteria</h4>
        <div className="grid md:grid-cols-2 gap-4 text-sm text-blue-700">
          <div>
            <strong>Technical Competency:</strong> Domain knowledge, problem-solving
          </div>
          <div>
            <strong>Communication:</strong> Clarity, articulation, listening
          </div>
          <div>
            <strong>Behavioral:</strong> Leadership, teamwork, adaptability
          </div>
          <div>
            <strong>Cultural Fit:</strong> Values alignment, motivation
          </div>
        </div>
      </div>
    </div>
  );
};

// Step 3: Custom Content
const StepThree = ({ 
  customQuestions,
  newQuestion,
  setNewQuestion,
  handleAddQuestion,
  handleRemoveQuestion,
  resumeFile,
  setResumeFile
}: { 
  customQuestions: string[],
  newQuestion: string,
  setNewQuestion: React.Dispatch<React.SetStateAction<string>>,
  handleAddQuestion: () => void,
  handleRemoveQuestion: (index: number) => void,
  resumeFile: File | null,
  setResumeFile: React.Dispatch<React.SetStateAction<File | null>>
}) => {
  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <div className="w-24 h-24 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-lg transform transition-transform hover:scale-105 hover:rotate-3 relative">
          <div className="absolute inset-0 bg-white opacity-10 blur-xl rounded-3xl"></div>
          <FileText className="w-10 h-10 text-white" />
        </div>
        <motion.h2 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-3xl font-bold text-gray-900 mb-3"
        >
          Additional Materials
        </motion.h2>
        <motion.p 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-lg text-gray-600"
        >
          Upload resume and add custom questions (optional)
        </motion.p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <FileUpload
            onFileSelect={setResumeFile}
            onFileRemove={() => setResumeFile(null)}
            selectedFile={resumeFile}
            label="Resume Upload"
            helperText="PDF, DOC, or DOCX up to 5MB"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-3">
            Custom Questions
          </label>
          <div className="space-y-3">
            <div className="flex gap-2">
              <Input
                value={newQuestion}
                onChange={(e) => setNewQuestion(e.target.value)}
                placeholder="Add a custom question..."
                className="flex-1"
                onKeyPress={(e) => e.key === 'Enter' && handleAddQuestion()}
              />
              <Button
                onClick={handleAddQuestion}
                disabled={!newQuestion.trim()}
                size="sm"
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            
            {customQuestions.length > 0 ? (
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {customQuestions.map((question, index) => (
                  <div key={index} className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg">
                    <span className="flex-1 text-sm">{question}</span>
                    <button
                      onClick={() => handleRemoveQuestion(index)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-sm p-3 bg-gray-50 rounded-lg">
                No custom questions added yet. Add questions to personalize your interview.
              </p>
            )}
          </div>
          <p className="text-xs text-gray-500 mt-2">
            Add specific questions you want the interviewer to ask you.
          </p>
        </div>
      </div>

      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <h4 className="font-semibold text-yellow-900 mb-2">Pro Tips</h4>
        <ul className="text-sm text-yellow-800 space-y-1">
          <li>• Add custom questions related to your target position</li>
          <li>• Upload your resume to get more tailored feedback</li>
          <li>• Include questions you find difficult to answer in real interviews</li>
          <li>• Try including technical and behavioral questions for a well-rounded practice</li>
        </ul>
      </div>
    </div>
  );
};

// Step 4: Review & Start
const StepFour = ({ 
  setup,
  customQuestions,
  resumeFile,
  selectedFocusAreas,
  focusAreas,
  handleStartInterview,
  loading
}: { 
  setup: InterviewSetup,
  customQuestions: string[],
  resumeFile: File | null,
  selectedFocusAreas: string[],
  focusAreas: { value: string, label: string }[],
  handleStartInterview: (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void,
  loading: boolean
}) => {
  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <div className="w-24 h-24 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-lg transform transition-transform hover:scale-105 hover:rotate-3 relative">
          <div className="absolute inset-0 bg-white opacity-10 blur-xl rounded-3xl"></div>
          <Target className="w-10 h-10 text-white" />
        </div>
        <motion.h2 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-3xl font-bold text-gray-900 mb-3"
        >
          Review & Start
        </motion.h2>
        <motion.p 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-lg text-gray-600"
        >
          Confirm your settings and begin the interview
        </motion.p>
      </div>

      <div className="bg-gradient-to-br from-gray-50 to-white rounded-xl p-6 space-y-4 shadow-inner border border-gray-100">
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <h4 className="font-semibold text-gray-900">Position</h4>
            <p className="text-gray-600">{setup.jobTitle || 'Not specified'} at {setup.company || 'Not specified'}</p>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">Experience Level</h4>
            <p className="text-gray-600 capitalize">{setup.experienceLevel} Level</p>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">Duration</h4>
            <p className="text-gray-600">{setup.duration} minutes</p>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">AI System</h4>
            <p className="text-gray-600">ElevenLabs AI Agent</p>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">Custom Questions</h4>
            <p className="text-gray-600">{customQuestions.length} added</p>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">Focus Areas</h4>
            <div className="flex flex-wrap gap-2 mt-1">
              {selectedFocusAreas.length > 0 ? (
                selectedFocusAreas.map(area => (
                  <Badge key={area} variant="primary" size="sm">
                    {focusAreas.find(f => f.value === area)?.label || area}
                  </Badge>
                ))
              ) : (
                <p className="text-gray-500">No specific focus areas selected</p>
              )}
            </div>
          </div>
        </div>
        
        {resumeFile && (
          <div>
            <h4 className="font-semibold text-gray-900">Resume</h4>
            <p className="text-gray-600">{resumeFile.name}</p>
          </div>
        )}
      </div>

      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <h4 className="font-semibold text-green-900 mb-2">What to Expect:</h4>
        <ul className="text-sm text-green-700 space-y-1">
          <li>• AI interviewer will ask relevant questions for your role</li>
          <li>• Speak naturally - your responses will be analyzed in real-time</li>
          <li>• Questions will adapt based on your experience level</li>
          <li>• You'll receive comprehensive feedback at the end</li>
        </ul>
      </div>

      <div className="text-center">
        <motion.div
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          className="inline-block"
        >
          <Button
          onClick={handleStartInterview}
          disabled={loading || !setup.jobTitle || !setup.company}
          className="group px-10 py-4 text-xl font-bold rounded-2xl transition-all duration-300 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 relative overflow-hidden"
          loading={loading}
          icon={<Play className="w-6 h-6 mr-3 group-hover:animate-pulse" />}
          >
            <span className="relative z-10">{loading ? 'Initializing Interview...' : 'Start AI Interview'}</span>
            <span className="absolute inset-0 bg-gradient-to-r from-indigo-600/60 to-purple-600/60 w-full scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left"></span>
          </Button>
        </motion.div>

        {(!setup.jobTitle || !setup.company) && (
          <p className="text-red-500 text-sm mt-3 animate-pulse">
            Please fill in job title and company to start the interview
          </p>
        )}
      </div>

      <div className="text-gray-500 text-sm text-center">
        You can stop the interview at any time, and your progress will be saved.
      </div>
    </div>
  );
};