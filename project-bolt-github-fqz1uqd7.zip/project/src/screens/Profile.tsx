export function Profile() {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Left column - Profile form */}
          <div className="md:w-2/3">
            <h1 className="text-2xl font-bold text-gray-900 mb-6">My Profile</h1>
            <div className="space-y-6">
              {/* Personal information form */}
              <ProfileForm />
              
              {/* Skills and certifications */}
              <SkillsManager />
            </div>
          </div>
          
          {/* Right column - Recent activity */}
          <div className="md:w-1/3 space-y-6">
            <RecentInterviews />
          </div>
        </div>
      </div>
    </div>
  );
}

// Import necessary components
import { ProfileForm } from '../components/profile/ProfileForm';
import { SkillsManager } from '../components/profile/SkillsManager';
import { RecentInterviews } from '../components/profile/RecentInterviews';

export function ProfileDetails() {
  const { user } = useAuth();
  const { 
    profile, 
    stats, 
    loading, 
    saving, 
    uploading,
    updateProfile,
    uploadProfilePhoto,
    uploadResume,
    exportData
  } = useProfile();
  
  const [editing, setEditing] = useState(false);
  const [editData, setEditData] = useState(profile || {});
  const [interviews, setInterviews] = useState<Interview[]>([]);
  const [scores, setScores] = useState<Score[]>([]);
  const [newSkill, setNewSkill] = useState('');
  const [newCertification, setNewCertification] = useState('');

  React.useEffect(() => {
    if (profile) {
      setEditData(profile);
    }
  }, [profile]);

  React.useEffect(() => {
    if (user) {
      loadInterviewData();
    }
  }, [user]);

  const loadInterviewData = async () => {
    if (!user) return;

    try {
      const [interviewsResult] = await Promise.all([
        db.interviews.getAll(user.id)
      ]);

      if (interviewsResult.data) {
        const interviewsList = interviewsResult.data;
        setInterviews(interviewsList);

        // Load scores for completed interviews
        const completedInterviews = interviewsList.filter(i => i.status === 'completed');
        const scoresPromises = completedInterviews.map(interview => 
          db.scores.getByInterviewId(interview.id)
        );
        
        const scoresResults = await Promise.all(scoresPromises);
        const validScores = scoresResults
          .filter(result => !result.error && result.data)
          .map(result => result.data!);
        
        setScores(validScores);
      }
    } catch (error) {
      console.error('Failed to load interview data:', error);
    }
  };

  const handleSave = async () => {
    try {
      await updateProfile(editData);
      setEditing(false);
    } catch (error) {
      // Error handling is done in the hook
    }
  };

  const handleCancel = () => {
    setEditData(profile || {});
    setEditing(false);
  };

  const handlePhotoUpload = async (file: File) => {
    try {
      const url = await uploadProfilePhoto(file);
      setEditData(prev => ({ ...prev, profile_photo_url: url }));
    } catch (error) {
      // Error handling is done in the hook
    }
  };

  const handleResumeUpload = async (file: File) => {
    try {
      const url = await uploadResume(file);
      setEditData(prev => ({ ...prev, resume_url: url }));
    } catch (error) {
      // Error handling is done in the hook
    }
  };

  const addSkill = () => {
    if (newSkill.trim()) {
      const skills = editData.skills || [];
      setEditData(prev => ({
        ...prev,
        skills: [...skills, newSkill.trim()]
      }));
      setNewSkill('');
    }
  };

  const removeSkill = (index: number) => {
    const skills = editData.skills || [];
    setEditData(prev => ({
      ...prev,
      skills: skills.filter((_, i) => i !== index)
    }));
  };

  const addCertification = () => {
    if (newCertification.trim()) {
      const certifications = editData.certifications || [];
      setEditData(prev => ({
        ...prev,
        certifications: [...certifications, newCertification.trim()]
      }));
      setNewCertification('');
    }
  };

  const removeCertification = (index: number) => {
    const certifications = editData.certifications || [];
    setEditData(prev => ({
      ...prev,
      certifications: certifications.filter((_, i) => i !== index)
    }));
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">My Profile</h1>
          <p className="text-gray-600">Manage your personal information and track your progress</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Profile Card */}
          <div className="lg:col-span-1">
            <div className="card p-6 mb-6">
              <div className="text-center">
                <div className="relative inline-block mb-4">
                  <div className="w-24 h-24 bg-gray-200 rounded-full overflow-hidden mx-auto">
                    <SafeImage
                      src={editing ? editData.profile_photo_url : profile?.profile_photo_url}
                      alt="Profile"
                      className="w-full h-full object-cover"
                      fallback={<User className="w-8 h-8 text-gray-400" />}
                    />
                  </div>
                  
                  {editing && (
                    <div className="absolute -bottom-2 -right-2">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            handlePhotoUpload(file);
                          }
                        }}
                        className="hidden"
                        id="profile-photo-upload"
                      />
                      <label
                        htmlFor="profile-photo-upload"
                        className="w-8 h-8 bg-primary-600 rounded-full flex items-center justify-center cursor-pointer hover:bg-primary-700 transition-colors"
                      >
                        <Camera className="w-4 h-4 text-white" />
                      </label>
                    </div>
                  )}
                </div>

                <h3 className="text-xl font-semibold text-gray-900 mb-1">
                  {profile?.first_name && profile?.last_name 
                    ? `${profile.first_name} ${profile.last_name}`
                    : 'Name not set'
                  }
                </h3>
                
                <div className="space-y-2 text-sm text-gray-600 mb-4">
                  {profile?.location && (
                    <div className="flex items-center justify-center space-x-1">
                      <MapPin className="w-4 h-4" />
                      <span>{profile.location}</span>
                    </div>
                  )}
                  
                  <div className="flex items-center justify-center space-x-1">
                    <Mail className="w-4 h-4" />
                    <span>{user?.email}</span>
                  </div>
                  
                  <div className="flex items-center justify-center space-x-1">
                    <Calendar className="w-4 h-4" />
                    <span>Joined {new Date(profile?.created_at || '').toLocaleDateString()}</span>
                  </div>
                </div>

                {!editing && (
                  <Button
                    onClick={() => setEditing(true)}
                    size="sm"
                    className="w-full"
                  >
                    <Edit2 className="w-4 h-4 mr-2" />
                    Edit Profile
                  </Button>
                )}
              </div>
            </div>

            {/* Statistics */}
            {stats && (
              <div className="card p-6 mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Statistics</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Award className="w-5 h-5 text-primary-600" />
                      <span className="text-gray-700">Interviews Completed</span>
                    </div>
                    <span className="font-semibold text-gray-900">{stats.completed_interviews}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <TrendingUp className="w-5 h-5 text-green-600" />
                      <span className="text-gray-700">Average Score</span>
                    </div>
                    <span className="font-semibold text-gray-900">
                      {stats.average_score > 0 ? stats.average_score.toFixed(1) : '—'}/10
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Clock className="w-5 h-5 text-blue-600" />
                      <span className="text-gray-700">Practice Time</span>
                    </div>
                    <span className="font-semibold text-gray-900">{stats.total_practice_time}m</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Target className="w-5 h-5 text-purple-600" />
                      <span className="text-gray-700">Best Score</span>
                    </div>
                    <span className="font-semibold text-green-600">
                      {stats.best_score > 0 ? stats.best_score.toFixed(1) : '—'}/10
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Quick Actions */}
            <div className="card p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <Button
                  onClick={exportData}
                  variant="outline"
                  size="sm"
                  className="w-full justify-start"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Export My Data
                </Button>
                
                {profile?.resume_url && (
                  <Button
                    onClick={() => window.open(profile.resume_url, '_blank')}
                    variant="outline"
                    size="sm"
                    className="w-full justify-start"
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    View Resume
                  </Button>
                )}
              </div>
            </div>
          </div>

          {/* Profile Details */}
          <div className="lg:col-span-2">
            <div className="card p-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-semibold text-gray-900">Profile Details</h2>
                {editing && (
                  <div className="flex space-x-2">
                    <Button
                      onClick={handleSave}
                      loading={saving}
                      size="sm"
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Save
                    </Button>
                    <Button
                      onClick={handleCancel}
                      variant="outline"
                      size="sm"
                    >
                      <X className="w-4 h-4 mr-2" />
                      Cancel
                    </Button>
                  </div>
                )}
              </div>

              <div className="space-y-8">
                {/* Personal Information */}
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
                    <User className="w-5 h-5 mr-2" />
                    Personal Information
                  </h3>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <Input
                      label="First Name"
                      value={editing ? (editData.first_name || '') : (profile?.first_name || 'Not set')}
                      onChange={(e) => editing && setEditData(prev => ({ ...prev, first_name: e.target.value }))}
                      disabled={!editing}
                    />
                    <Input
                      label="Last Name"
                      value={editing ? (editData.last_name || '') : (profile?.last_name || 'Not set')}
                      onChange={(e) => editing && setEditData(prev => ({ ...prev, last_name: e.target.value }))}
                      disabled={!editing}
                    />
                    <Input
                      label="Location"
                      value={editing ? (editData.location || '') : (profile?.location || 'Not set')}
                      onChange={(e) => editing && setEditData(prev => ({ ...prev, location: e.target.value }))}
                      disabled={!editing}
                    />
                    <Input
                      label="Country"
                      value={editing ? (editData.country || '') : (profile?.country || 'Not set')}
                      onChange={(e) => editing && setEditData(prev => ({ ...prev, country: e.target.value }))}
                      disabled={!editing}
                    />
                    <Input
                      label="Phone Number"
                      value={editing ? (editData.phone_number || '') : (profile?.phone_number || 'Not set')}
                      onChange={(e) => editing && setEditData(prev => ({ ...prev, phone_number: e.target.value }))}
                      disabled={!editing}
                    />
                    <Input
                      label="Time Zone"
                      value={editing ? (editData.timezone || '') : (profile?.timezone || 'Not set')}
                      onChange={(e) => editing && setEditData(prev => ({ ...prev, timezone: e.target.value }))}
                      disabled={!editing}
                    />
                  </div>
                </div>

                {/* Professional Information */}
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
                    <Briefcase className="w-5 h-5 mr-2" />
                    Professional Information
                  </h3>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Professional Experience
                      </label>
                      {editing ? (
                        <textarea
                          value={editData.professional_experience || ''}
                          onChange={(e) => setEditData(prev => ({ ...prev, professional_experience: e.target.value }))}
                          rows={6}
                          className="input-field resize-vertical"
                          placeholder="Describe your professional background, skills, and experience..."
                        />
                      ) : (
                        <div className="bg-gray-50 rounded-lg p-4 min-h-[100px]">
                          <p className="text-gray-700 whitespace-pre-wrap">
                            {profile?.professional_experience || 'No professional experience added yet.'}
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Social Links */}
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          LinkedIn URL
                        </label>
                        <div className="relative">
                          <Linkedin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                          <Input
                            value={editing ? (editData.linkedin_url || '') : (profile?.linkedin_url || 'Not set')}
                            onChange={(e) => editing && setEditData(prev => ({ ...prev, linkedin_url: e.target.value }))}
                            disabled={!editing}
                            className="pl-10"
                            placeholder="https://linkedin.com/in/username"
                          />
                          {!editing && profile?.linkedin_url && (
                            <button
                              onClick={() => window.open(profile.linkedin_url, '_blank')}
                              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                            >
                              <ExternalLink className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          GitHub URL
                        </label>
                        <div className="relative">
                          <Github className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                          <Input
                            value={editing ? (editData.github_url || '') : (profile?.github_url || 'Not set')}
                            onChange={(e) => editing && setEditData(prev => ({ ...prev, github_url: e.target.value }))}
                            disabled={!editing}
                            className="pl-10"
                            placeholder="https://github.com/username"
                          />
                          {!editing && profile?.github_url && (
                            <button
                              onClick={() => window.open(profile.github_url, '_blank')}
                              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                            >
                              <ExternalLink className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>

                      <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Portfolio URL
                        </label>
                        <div className="relative">
                          <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                          <Input
                            value={editing ? (editData.portfolio_url || '') : (profile?.portfolio_url || 'Not set')}
                            onChange={(e) => editing && setEditData(prev => ({ ...prev, portfolio_url: e.target.value }))}
                            disabled={!editing}
                            className="pl-10"
                            placeholder="https://yourportfolio.com"
                          />
                          {!editing && profile?.portfolio_url && (
                            <button
                              onClick={() => window.open(profile.portfolio_url, '_blank')}
                              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                            >
                              <ExternalLink className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <Input
                      label="How did you hear about us?"
                      value={editing ? (editData.referral_source || '') : (profile?.referral_source || 'Not specified')}
                      onChange={(e) => editing && setEditData(prev => ({ ...prev, referral_source: e.target.value }))}
                      disabled={!editing}
                    />

                    {editing && (
                      <div>
                        <FileUpload
                          onFileSelect={handleResumeUpload}
                          label="Resume"
                          helperText="Upload your latest resume (PDF, DOC, DOCX)"
                          accept=".pdf,.doc,.docx"
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Skills & Certifications */}
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Skills & Certifications</h3>
                  
                  <div className="grid md:grid-cols-2 gap-6">
                    {/* Skills */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Skills
                      </label>
                      
                      {editing && (
                        <div className="flex gap-2 mb-3">
                          <Input
                            value={newSkill}
                            onChange={(e) => setNewSkill(e.target.value)}
                            placeholder="Add a skill..."
                            className="flex-1"
                            onKeyPress={(e) => e.key === 'Enter' && addSkill()}
                          />
                          <Button
                            onClick={addSkill}
                            disabled={!newSkill.trim()}
                            size="sm"
                          >
                            <Plus className="w-4 h-4" />
                          </Button>
                        </div>
                      )}
                      
                      <div className="flex flex-wrap gap-2">
                        {(editing ? editData.skills : profile?.skills)?.map((skill, index) => (
                          <span
                            key={index}
                            className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-primary-100 text-primary-800"
                          >
                            {skill}
                            {editing && (
                              <button
                                onClick={() => removeSkill(index)}
                                className="ml-2 text-primary-600 hover:text-primary-800"
                              >
                                <X className="w-3 h-3" />
                              </button>
                            )}
                          </span>
                        )) || (
                          <p className="text-gray-500 text-sm">No skills added yet</p>
                        )}
                      </div>
                    </div>

                    {/* Certifications */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Certifications
                      </label>
                      
                      {editing && (
                        <div className="flex gap-2 mb-3">
                          <Input
                            value={newCertification}
                            onChange={(e) => setNewCertification(e.target.value)}
                            placeholder="Add a certification..."
                            className="flex-1"
                            onKeyPress={(e) => e.key === 'Enter' && addCertification()}
                          />
                          <Button
                            onClick={addCertification}
                            disabled={!newCertification.trim()}
                            size="sm"
                          >
                            <Plus className="w-4 h-4" />
                          </Button>
                        </div>
                      )}
                      
                      <div className="space-y-2">
                        {(editing ? editData.certifications : profile?.certifications)?.map((cert, index) => (
                          <div
                            key={index}
                            className="flex items-center justify-between p-2 bg-gray-50 rounded-lg"
                          >
                            <span className="text-sm text-gray-700">{cert}</span>
                            {editing && (
                              <button
                                onClick={() => removeCertification(index)}
                                className="text-red-500 hover:text-red-700"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        )) || (
                          <p className="text-gray-500 text-sm">No certifications added yet</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Recent Interviews */}
            <div className="card p-8 mt-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-6">Recent Interviews</h3>
              
              {interviews.length === 0 ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Briefcase className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className="text-gray-500 mb-2">No interviews yet</p>
                  <p className="text-sm text-gray-400">Start practicing to see your progress here</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {interviews.slice(0, 5).map((interview) => {
                    const interviewScore = scores.find(s => s.interview_id === interview.id);
                    
                    return (
                      <div
                        key={interview.id}
                        className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        <div className="flex items-center space-x-4">
                          <div className={`
                            w-10 h-10 rounded-lg flex items-center justify-center
                            ${interview.status === 'completed' 
                              ? 'bg-green-100 text-green-600' 
                              : 'bg-blue-100 text-blue-600'
                            }
                          `}>
                            <Briefcase className="w-5 h-5" />
                          </div>
                          <div>
                            <h4 className="font-medium text-gray-900">
                              {interview.job_title}
                            </h4>
                            <div className="flex items-center space-x-4 text-sm text-gray-600">
                              <span>{interview.company}</span>
                              <span>•</span>
                              <span>{new Date(interview.created_at).toLocaleDateString()}</span>
                              {interviewScore && (
                                <>
                                  <span>•</span>
                                  <span className="text-green-600 font-medium">
                                    Score: {interviewScore.overall_score}/10
                                  </span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <span className={`
                            px-2 py-1 text-xs font-medium rounded-full
                            ${interview.status === 'completed' 
                              ? 'bg-green-100 text-green-800' 
                              : interview.status === 'in_progress'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-gray-100 text-gray-800'
                            }
                          `}>
                            {interview.status.replace(/_/g, ' ')}
                          </span>
                          
                          {interview.status === 'completed' && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => window.open(`/results/${interview.id}`, '_blank')}
                            >
                              View Results
                            </Button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}