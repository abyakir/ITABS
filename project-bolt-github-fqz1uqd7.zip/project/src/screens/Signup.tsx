import React, { useState, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  User, 
  Phone, 
  MapPin,
  Globe,
  Briefcase,
  Linkedin,
  Github,
  ArrowRight,
  ArrowLeft,
  Camera
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { useAuth } from '../hooks/useAuth';
import { shouldUseMockAuth } from '../lib/mockAuth';
import { useProfile } from '../hooks/useProfile';
import toast from 'react-hot-toast';

export function Signup() {
  const navigate = useNavigate();
  const { signUp, isMockAuth } = useAuth();
  const { updateProfile } = useProfile();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  
  // Basic auth info
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Profile information
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState('');
  const [country, setCountry] = useState('');
  const [experience, setExperience] = useState('');
  const [linkedinUrl, setLinkedinUrl] = useState('');
  const [githubUrl, setGithubUrl] = useState('');
  
  // Skills and certifications
  const [skills, setSkills] = useState<string[]>([]);
  const [certifications, setCertifications] = useState<string[]>([]);
  const [newSkill, setNewSkill] = useState('');
  const [newCertification, setNewCertification] = useState('');

  // Photo upload (future implementation)
  const photoRef = useRef<HTMLInputElement>(null); 
  const [profilePhotoFile, setProfilePhotoFile] = useState<File | null>(null);

  // Handle profile photo selection
  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setProfilePhotoFile(file);
    }
  };

  // Common skills for easy selection
  const commonSkills = [
    'JavaScript', 'React', 'Node.js', 'Python', 'SQL', 
    'Communication', 'Leadership', 'Project Management'
  ];
  
  // Common certifications for easy selection
  const commonCertifications = [
    'AWS Certified Solutions Architect', 'PMP', 'Scrum Master', 
    'Google Cloud Professional', 'Microsoft Azure'
  ];

  const handleAddSkill = () => {
    if (newSkill.trim() && !skills.includes(newSkill.trim())) {
      setSkills([...skills, newSkill.trim()]);
      setNewSkill('');
    }
  };

  const handleAddCertification = () => {
    if (newCertification.trim() && !certifications.includes(newCertification.trim())) {
      setCertifications([...certifications, newCertification.trim()]);
      setNewCertification('');
    }
  };

  const validateStep1 = () => {
    if (!email.trim()) {
      toast.error('Please enter your email address');
      return false;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error('Please enter a valid email address');
      return false;
    }

    if (!password) {
      toast.error('Please enter a password');
      return false;
    }

    if (password.length < 8) {
      toast.error('Password must be at least 8 characters');
      return false;
    }

    if (password !== confirmPassword) {
      toast.error('Passwords do not match');
      return false;
    }

    return true;
  };

  const validateStep2 = () => {
    if (!firstName.trim() || !lastName.trim()) {
      toast.error('First name and last name are required');
      return false;
    }
    return true;
  };

  const handleNext = () => {
    if (step === 1 && validateStep1()) {
      setStep(2);
    } else if (step === 2 && validateStep2()) {
      setStep(3);
    }
  };

  const handlePrevious = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateStep1()) return;
    if (!validateStep2()) return;

    setLoading(true);
    try {
      console.log('Submitting signup form with email:', email);
      const { data, error } = await signUp(email, password);
      
      if (error) {
        toast.error(error);
        setLoading(false);
        return;
      }
      
      if (data?.user) {
        console.log('User created successfully, saving profile data for:', data.user.id);

        // Wait a moment to ensure the user record is fully created
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Prepare profile data from registration form
        const profileData = {
          first_name: firstName,
          last_name: lastName,
          phone_number: phone,
          location: location,
          country: country,
          professional_experience: experience,
          linkedin_url: linkedinUrl,
          github_url: githubUrl,
          skills: skills,
          certifications: certifications,
          onboarding_completed: true,
        };

        console.log('Updating profile with form data:', profileData);
        
        // Update the profile with the registration form data
        try {
          const result = await updateProfile(profileData);
          console.log('Profile update result:', result);
          
          // If there's a profile photo, upload it
          if (profilePhotoFile) {
            try {
              // TODO: Implement profile photo upload functionality
              console.log('Profile photo selected, will be implemented in future update');
            } catch (photoError) {
              console.error('Failed to upload profile photo:', photoError);
              // Continue with the signup process even if photo upload fails
            }
          }
          
          toast.success('Account created successfully! Welcome aboard!');
          navigate('/dashboard');
        } catch (profileError) {
          console.error('Failed to save profile data:', profileError);
          toast.error('Account created, but profile setup failed. Please update your profile later.');
          navigate('/dashboard');
        }
      } else {
        toast.error('Something went wrong. Please try again.');
      }
    } catch (error) {
      console.error('Signup error:', error);
      toast.error('An unexpected error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-indigo-800 py-12 px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-4xl mx-auto"
      >
        <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl overflow-hidden">
          <div className="md:flex">
            {/* Left side - Motivational content */}
            <div className="relative hidden md:block md:w-2/5 bg-gradient-to-br from-indigo-600 to-purple-700 p-12 text-white">
              <div className="absolute inset-0 opacity-20">
                <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:40px_40px]"></div>
              </div>
              
              <div className="relative z-10">
                <h2 className="text-2xl font-bold mb-6">Start Your Interview Practice Journey</h2>
                
                <ul className="space-y-4 mt-8">
                  {[
                    'Practice with AI-powered interviews',
                    'Get real-time feedback on your answers',
                    'Build confidence through regular practice',
                    'Track your progress over time',
                    'Land your dream job!'
                  ].map((item, i) => (
                    <motion.li 
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.2 + i * 0.1 }}
                      className="flex items-start"
                    >
                      <div className="mr-3 bg-white/20 rounded-full p-1 mt-0.5">
                        <svg width="12" height="12" viewBox="0 0 12 12">
                          <path 
                            fill="currentColor" 
                            d="M4.5 8.996l-2.147-2.146-1.06 1.06 3.207 3.208 6.854-6.854-1.061-1.06z"
                          />
                        </svg>
                      </div>
                      <span>{item}</span>
                    </motion.li>
                  ))}
                </ul>
                
                <div className="absolute bottom-10 left-10 right-10">
                  <p className="text-white/70 text-sm">
                    Already have an account?{' '}
                    <Link to="/login" className="text-white underline font-medium hover:text-indigo-200">
                      Sign in
                    </Link>
                  </p>
                </div>
              </div>
            </div>
            
            {/* Right side - Form */}
            <div className="md:w-3/5 p-8 md:p-12">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-gray-900">
                  {step === 1 ? 'Create Your Account' : 
                   step === 2 ? 'Personal Information' : 
                   'Professional Profile'}
                </h2>
                <p className="text-gray-600 mt-2">
                  {step === 1 ? 'Get started with Maximum Interview' : 
                   step === 2 ? 'Tell us about yourself' : 
                   'Add your professional details (optional)'}
                </p>
                
                {/* Step indicator */}
                <div className="flex items-center justify-center mt-6">
                  {[1, 2, 3].map((s) => (
                    <React.Fragment key={s}>
                      <div 
                        className={`w-7 h-7 rounded-full flex items-center justify-center font-medium text-sm
                          ${s === step 
                            ? 'bg-indigo-600 text-white shadow-md' 
                            : s < step 
                              ? 'bg-indigo-100 text-indigo-600' 
                              : 'bg-gray-100 text-gray-400'
                          }`}
                      >
                        {s}
                      </div>
                      {s < 3 && (
                        <div className={`w-10 h-1 mx-1 rounded-full ${s < step ? 'bg-indigo-600' : 'bg-gray-200'}`}></div>
                      )}
                    </React.Fragment>
                  ))}
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Step 1: Account Credentials */}
                {step === 1 && (
                  <div className="space-y-4 animate-fadeIn">
                    <div className="relative">
                      <Input
                        type="email"
                        label="Email Address"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        leftIcon={<Mail className="w-5 h-5" />}
                        required
                        autoFocus
                      />
                    </div>

                    <div className="relative">
                      <Input
                        type={showPassword ? 'text' : 'password'}
                        label="Create Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        leftIcon={<Lock className="w-5 h-5" />}
                        rightIcon={
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="text-gray-400 hover:text-gray-600"
                          >
                            {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                          </button>
                        }
                        helperText="Must be at least 8 characters long"
                        required
                      />
                    </div>

                    <div className="relative">
                      <Input
                        type={showPassword ? 'text' : 'password'}
                        label="Confirm Password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        leftIcon={<Lock className="w-5 h-5" />}
                        required
                      />
                    </div>

                    <div className="pt-4">
                      <Button
                        type="button"
                        onClick={handleNext}
                        className="w-full"
                        icon={<ArrowRight className="w-4 h-4" />}
                        iconPosition="right"
                      >
                        Continue
                      </Button>
                    </div>
                    
                    {/* Mobile version link */}
                    <div className="text-center mt-6 md:hidden">
                      <p className="text-gray-600">
                        Already have an account?{' '}
                        <Link
                          to="/login"
                          className="text-indigo-600 hover:text-indigo-800 font-medium"
                        >
                          Sign in
                        </Link>
                      </p>
                    </div>
                  </div>
                )}
                
                {/* Step 2: Personal Information */}
                {step === 2 && (
                  <div className="space-y-6 animate-fadeIn">
                    <div className="flex justify-center mb-6">
                      <div className="relative">
                        <div className="w-24 h-24 bg-gray-100 rounded-full overflow-hidden flex items-center justify-center border-2 border-white shadow-md">
                          {profilePhotoFile ? (
                            <img 
                              src={URL.createObjectURL(profilePhotoFile)} 
                              alt="Profile preview" 
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <User className="w-12 h-12 text-gray-400" />
                          )}
                        </div>
                        <button 
                          type="button"
                          onClick={() => photoRef.current?.click()}
                          className="absolute bottom-0 right-0 bg-indigo-600 rounded-full p-2 text-white shadow-md border-2 border-white hover:bg-indigo-700 transition-colors"
                        >
                          <Camera className="w-4 h-4" />
                        </button>
                        <input 
                          ref={photoRef}
                          type="file" 
                          accept="image/*" 
                          onChange={handlePhotoSelect}
                          className="hidden"
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Input
                        label="First Name"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        leftIcon={<User className="w-5 h-5" />}
                        required
                      />
                      <Input
                        label="Last Name"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        leftIcon={<User className="w-5 h-5" />}
                        required
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Input
                        type="tel"
                        label="Phone Number (optional)"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        leftIcon={<Phone className="w-5 h-5" />}
                      />
                      <Input
                        label="Location (optional)"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        leftIcon={<MapPin className="w-5 h-5" />}
                        placeholder="City, State"
                      />
                    </div>
                    
                    <Input
                      label="Country (optional)"
                      value={country}
                      onChange={(e) => setCountry(e.target.value)}
                      leftIcon={<Globe className="w-5 h-5" />}
                    />

                  
                  {isMockAuth && (
                    <div className="mt-6 p-3 bg-blue-50 border border-blue-100 rounded-lg">
                      <p className="text-xs text-blue-800 text-center">
                        <strong>Development Mode:</strong> All data will be stored locally and reset when you clear browser storage.
                      </p>
                    </div>
                  )}
                    <div className="flex flex-col-reverse md:flex-row justify-between gap-3 pt-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={handlePrevious}
                        icon={<ArrowLeft className="w-4 h-4" />}
                        iconPosition="left"
                      >
                        Back
                      </Button>
                      <Button
                        type="button"
                        onClick={handleNext}
                        icon={<ArrowRight className="w-4 h-4" />}
                        iconPosition="right"
                      >
                        Continue
                      </Button>
                    </div>
                  </div>
                )}
                
                {/* Step 3: Professional Information */}
                {step === 3 && (
                  <div className="space-y-6 animate-fadeIn">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Professional Experience (optional)
                      </label>
                      <div className="relative">
                        <Briefcase className="absolute left-3 top-3 text-gray-400 w-5 h-5" />
                        <textarea
                          value={experience}
                          onChange={(e) => setExperience(e.target.value)}
                          className="w-full pl-10 pr-3 py-2 min-h-[100px] border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 resize-none"
                          placeholder="Describe your professional background..."
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Input
                        label="LinkedIn URL (optional)"
                        value={linkedinUrl}
                        onChange={(e) => setLinkedinUrl(e.target.value)}
                        leftIcon={<Linkedin className="w-5 h-5" />}
                        placeholder="https://linkedin.com/in/username"
                      />
                      <Input
                        label="GitHub URL (optional)"
                        value={githubUrl}
                        onChange={(e) => setGithubUrl(e.target.value)}
                        leftIcon={<Github className="w-5 h-5" />}
                        placeholder="https://github.com/username"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Skills (optional)
                      </label>
                      <div className="flex flex-wrap gap-2 mb-2">
                        {commonSkills.map(skill => (
                          <Badge
                            key={skill}
                            variant={skills.includes(skill) ? "primary" : "default"}
                            onClick={() => {
                              if (skills.includes(skill)) {
                                setSkills(skills.filter(s => s !== skill));
                              } else {
                                setSkills([...skills, skill]);
                              }
                            }}
                            className="cursor-pointer"
                          >
                            {skill}
                          </Badge>
                        ))}
                      </div>
                      <div className="flex gap-2">
                        <Input
                          value={newSkill}
                          onChange={(e) => setNewSkill(e.target.value)}
                          placeholder="Add a custom skill..."
                          className="flex-grow"
                          onKeyPress={(e) => e.key === 'Enter' && handleAddSkill()}
                        />
                        <Button
                          type="button"
                          onClick={handleAddSkill}
                          disabled={!newSkill.trim()}
                          variant="outline"
                        >
                          Add
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-2 mt-3">
                        {skills.filter(skill => !commonSkills.includes(skill)).map((skill, index) => (
                          <Badge
                            key={index}
                            variant="primary"
                            className="cursor-pointer"
                            onClick={() => {
                              setSkills(skills.filter(s => s !== skill));
                            }}
                          >
                            {skill} ×
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Certifications (optional)
                      </label>
                      <div className="flex flex-wrap gap-2 mb-2">
                        {commonCertifications.map(cert => (
                          <Badge
                            key={cert}
                            variant={certifications.includes(cert) ? "primary" : "default"}
                            onClick={() => {
                              if (certifications.includes(cert)) {
                                setCertifications(certifications.filter(c => c !== cert));
                              } else {
                                setCertifications([...certifications, cert]);
                              }
                            }}
                            className="cursor-pointer"
                          >
                            {cert}
                          </Badge>
                        ))}
                      </div>
                      <div className="flex gap-2">
                        <Input
                          value={newCertification}
                          onChange={(e) => setNewCertification(e.target.value)}
                          placeholder="Add a custom certification..."
                          className="flex-grow"
                          onKeyPress={(e) => e.key === 'Enter' && handleAddCertification()}
                        />
                        <Button
                          type="button"
                          onClick={handleAddCertification}
                          disabled={!newCertification.trim()}
                          variant="outline"
                        >
                          Add
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-2 mt-3">
                        {certifications.filter(cert => !commonCertifications.includes(cert)).map((cert, index) => (
                          <Badge
                            key={index}
                            variant="primary"
                            className="cursor-pointer"
                            onClick={() => {
                              setCertifications(certifications.filter(c => c !== cert));
                            }}
                          >
                            {cert} ×
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="flex flex-col-reverse md:flex-row justify-between gap-3 pt-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={handlePrevious}
                        icon={<ArrowLeft className="w-4 h-4" />}
                        iconPosition="left"
                      >
                        Back
                      </Button>
                      <Button
                        type="submit"
                        loading={loading}
                        className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                      >
                        Create Account
                      </Button>
                    </div>
                    
                    <p className="text-sm text-gray-500 text-center pt-2">
                      By creating an account, you agree to our{' '}
                      <a href="#" className="text-indigo-600 hover:text-indigo-800">Terms of Service</a>{' '}
                      and{' '}
                      <a href="#" className="text-indigo-600 hover:text-indigo-800">Privacy Policy</a>
                    </p>
                  </div>
                )}
              </form>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}