import React, { useState } from 'react';
import { AccountSettings } from '../components/settings/AccountSettings';
import { NotificationSettings } from '../components/settings/NotificationSettings';
import { AppearanceSettings } from '../components/settings/AppearanceSettings';
import { InterviewSettings } from '../components/settings/InterviewSettings';
import { PrivacySettings } from '../components/settings/PrivacySettings';

export function Settings() {
  const [activeTab, setActiveTab] = useState('account');
  
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-6xl">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Settings</h1>
        
        <div className="grid grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="col-span-4 md:col-span-1">
            <div className="bg-white rounded-xl shadow-sm p-4">
              <nav className="space-y-1">
                {[
                  { id: 'account', label: 'Account' },
                  { id: 'notifications', label: 'Notifications' },
                  { id: 'appearance', label: 'Appearance' },
                  { id: 'interview', label: 'Interview Settings' },
                  { id: 'privacy', label: 'Privacy & Security' },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`
                      w-full flex items-center px-3 py-2 text-left rounded-lg transition-colors
                      ${activeTab === tab.id 
                        ? 'bg-indigo-50 text-indigo-700 font-medium' 
                        : 'text-gray-700 hover:bg-gray-100'
                      }
                    `}
                  >
                    {tab.label}
                  </button>
                ))}
              </nav>
            </div>
          </div>
          
          {/* Main content */}
          <div className="col-span-4 md:col-span-3 space-y-6">
            {activeTab === 'account' && <AccountSettings />}
            {activeTab === 'notifications' && <NotificationSettings />}
            {activeTab === 'appearance' && <AppearanceSettings />}
            {activeTab === 'interview' && <InterviewSettings />}
            {activeTab === 'privacy' && <PrivacySettings />}
          </div>
        </div>
      </div>
    </div>
  );
}