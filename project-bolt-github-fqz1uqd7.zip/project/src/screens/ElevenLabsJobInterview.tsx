import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, Settings, ArrowLeft, ChevronRight, Check, Award } from 'lucide-react';
import { InterviewManager } from '../components/interview/InterviewManager';
import { InterviewAssessment, generateMockAssessment } from '../components/interview/InterviewAssessment';
import { AIInterviewer } from '../components/interview/AIInterviewer';
import { Button } from '../components/ui/Button';
import { Card, CardContent, CardFooter } from '../components/ui/Card';
import { Dropdown } from '../components/ui/Dropdown';
import { useAuth } from '../hooks/useAuth';
import { db } from '../lib/supabase';
import { getInterviewData, isValidUUID, storeInterviewData } from '../lib/utils';
import { generateInterviewQuestions, industryPresets, companiesByIndustry } from '../lib/interviewData';
import toast from 'react-hot-toast';
import { useStageProgress } from '../hooks/useStageProgress';

export function ElevenLabsJobInterview() {
  const { id } = useParams<{ id: string }>();
  const isNewInterview = id === 'new';
  const { state } = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  
  // Interview data
  const [interviewData, setInterviewData] = useState(
    state?.interviewData || getInterviewData() || {
      jobTitle: '',
      company: '',
      duration: 30,
      experienceLevel: 'mid',
      customQuestions: [],
      focusAreas: []
    }
  );
  
  // Interview states
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [interview, setInterview] = useState<any | null>(null);
  const [interviewQuestions, setInterviewQuestions] = useState<any[]>([]);
  const [interviewStarted, setInterviewStarted] = useState(false);
  const [assessment, setAssessment] = useState<any | null>(null);
  
  // Setup stage management (before interview starts)
  const { 
    currentStage, 
    nextStage,
    prevStage,
    isFirstStage,
    isLastStage
  } = useStageProgress({
    minStage: 1,
    maxStage: 3,
    initialStage: 1,
    validateStage: (current, next) => {
      if (current === 1 && next === 2) {
        // Validate interview type settings
        if (!interviewData.jobTitle || !interviewData.company) {
          toast.error('Please provide a job title and company');
          return false;
        }
      }
      return true;
    }
  });
  
  // Interview settings
  const [interviewType, setInterviewType] = useState<string[]>(['behavioral', 'technical']);
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [industry, setIndustry] = useState<string>('technology');
  
  // Initialize or fetch interview data
  useEffect(() => {
    const initializeInterview = async () => {
      try {
        setLoading(true);
        setError(null);
        
        if (isNewInterview) {
          console.log('Setting up new interview with data:', interviewData);
          setLoading(false);
        } else if (isValidUUID(id as string)) {
          // Fetch existing interview
          const { data: existingInterview, error } = await db.interviews.getById(id as string);
          
          if (error) throw error;
          if (!existingInterview) throw new Error('Interview not found');
          
          // Verify ownership
          if (existingInterview.user_id !== user?.id) {
            throw new Error('You do not have permission to view this interview');
          }
          
          setInterview(existingInterview);
          setInterviewData({
            jobTitle: existingInterview.job_title,
            company: existingInterview.company,
            duration: existingInterview.duration_minutes || 30,
            experienceLevel: existingInterview.experience_level || 'mid',
            customQuestions: existingInterview.custom_questions || [],
            focusAreas: existingInterview.focus_areas || []
          });
          setLoading(false);
        } else {
          throw new Error('Invalid interview ID');
        }
      } catch (err: any) {
        console.error('Error initializing interview:', err);
        setError(err.message || 'Failed to initialize interview');
        setLoading(false);
      }
    };
    
    if (user) {
      initializeInterview();
    }
  }, [id, isNewInterview, user]);
  
  // Generate interview questions based on settings
  const generateQuestions = useCallback(async () => {
    try {
      setLoading(true);
      const questions = await generateInterviewQuestions(
        interviewData.jobTitle,
        interviewData.company,
        interviewData.experienceLevel as any,
        interviewType,
        difficulty,
        interviewData.customQuestions
      );
      
      setInterviewQuestions(questions);
      setLoading(false);
    } catch (err: any) {
      console.error('Error generating questions:', err);
      toast.error('Failed to generate interview questions');
      setLoading(false);
    }
  }, [interviewData, interviewType, difficulty]);
  
  // Handle interview completion
  const handleInterviewComplete = useCallback(async (assessmentData: any) => {
    try {
      setLoading(true);
      
      // If this is a new interview, create it in the database
      let interviewId = id;
      if (isNewInterview) {
        const { data: newInterview, error } = await db.interviews.create({
          user_id: user?.id as string,
          job_title: interviewData.jobTitle,
          company: interviewData.company,
          status: 'completed',
          experience_level: interviewData.experienceLevel,
          duration_minutes: assessmentData.interview_metrics.duration,
          custom_questions: interviewData.customQuestions,
          focus_areas: interviewData.focusAreas,
          completed_at: new Date().toISOString()
        });
        
        if (error) throw error;
        interviewId = newInterview.id;
      } else {
        // Update existing interview
        await db.interviews.update(id as string, {
          status: 'completed',
          completed_at: new Date().toISOString(),
          duration_minutes: assessmentData.interview_metrics.duration
        });
      }
      
      // Save assessment data
      await db.scores.create({
        interview_id: interviewId as string,
        clarity: Math.round(assessmentData.communication.score),
        confidence: Math.round(assessmentData.professional_demeanor.score),
        relevance: Math.round(assessmentData.technical_knowledge.score),
        communication: Math.round(assessmentData.communication.score),
        technical_skills: Math.round(assessmentData.technical_knowledge.score),
        overall_score: Math.round(assessmentData.overall_grade.score),
        professionalism: Math.round(assessmentData.professional_demeanor.score),
        behavioral_appropriateness: Math.round(assessmentData.professional_demeanor.score - 1 + Math.random() * 2),
        engagement_level: Math.round(assessmentData.communication.score - 1 + Math.random() * 2),
        response_quality_trend: 'improving',
        summary: assessmentData.overall_grade.feedback,
        recommendations: assessmentData.overall_grade.recommendation,
        strengths: assessmentData.communication.strengths
          .concat(assessmentData.technical_knowledge.strengths)
          .concat(assessmentData.problem_solving.strengths)
          .slice(0, 5),
        improvements: assessmentData.communication.areas_for_improvement
          .concat(assessmentData.technical_knowledge.areas_for_improvement)
          .concat(assessmentData.problem_solving.areas_for_improvement)
          .slice(0, 5)
      });
      
      setAssessment(assessmentData);
      setLoading(false);
      toast.success('Interview completed successfully!');
      
      // Navigate to results page
      navigate(`/results/${interviewId}`);
    } catch (err: any) {
      console.error('Error completing interview:', err);
      toast.error('Failed to save interview results');
      setLoading(false);
    }
  }, [id, isNewInterview, interviewData, user, navigate]);
  
  // Update interview settings
  const updateInterviewData = useCallback((key: string, value: any) => {
    setInterviewData(prev => {
      const updated = { ...prev, [key]: value };
      storeInterviewData(updated);
      return updated;
    });
  }, []);
  
  // Render different stages of the interview setup process
  const renderSetupStage = () => {
    switch (currentStage) {
      case 1: // Basic job info
        return (
          <Card className="max-w-3xl mx-auto">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold mb-6 text-center">Job Details</h2>
              
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">Industry</label>
                  <Dropdown
                    options={Object.keys(industryPresets).map(industry => ({
                      value: industry,
                      label: industry.charAt(0).toUpperCase() + industry.slice(1)
                    }))}
                    value={industry}
                    onChange={val => {
                      setIndustry(val);
                      // Auto-suggest a company from this industry
                      const companies = companiesByIndustry[val as keyof typeof companiesByIndustry] || [];
                      if (companies.length > 0) {
                        const randomCompany = companies[Math.floor(Math.random() * companies.length)];
                        updateInterviewData('company', randomCompany);
                      }
                    }}
                    placeholder="Select industry"
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">Job Title</label>
                  <input
                    type="text"
                    value={interviewData.jobTitle}
                    onChange={(e) => updateInterviewData('jobTitle', e.target.value)}
                    className="mt-1 block w-full rounded-md border border-gray-300 shadow-sm p-3 focus:border-indigo-500 focus:ring-indigo-500"
                    placeholder="e.g. Software Engineer, Product Manager"
                  />
                  {industry && (
                    <div className="mt-2">
                      <p className="text-sm text-gray-500 mb-2">Suggestions:</p>
                      <div className="flex flex-wrap gap-2">
                        {industryPresets[industry as keyof typeof industryPresets]?.slice(0, 5).map(job => (
                          <button
                            key={job}
                            className="px-3 py-1 text-sm bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-full"
                            onClick={() => updateInterviewData('jobTitle', job)}
                          >
                            {job}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">Company</label>
                  <input
                    type="text"
                    value={interviewData.company}
                    onChange={(e) => updateInterviewData('company', e.target.value)}
                    className="mt-1 block w-full rounded-md border border-gray-300 shadow-sm p-3 focus:border-indigo-500 focus:ring-indigo-500"
                    placeholder="e.g. Google, Microsoft, Acme Inc."
                  />
                  {industry && (
                    <div className="mt-2">
                      <p className="text-sm text-gray-500 mb-2">Suggestions:</p>
                      <div className="flex flex-wrap gap-2">
                        {companiesByIndustry[industry as keyof typeof companiesByIndustry]?.slice(0, 5).map(company => (
                          <button
                            key={company}
                            className="px-3 py-1 text-sm bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-full"
                            onClick={() => updateInterviewData('company', company)}
                          >
                            {company}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">Experience Level</label>
                  <div className="grid grid-cols-3 gap-3">
                    {['entry', 'mid', 'senior'].map((level) => (
                      <button
                        key={level}
                        className={`border-2 rounded-lg p-3 transition-colors ${
                          interviewData.experienceLevel === level
                            ? 'border-indigo-500 bg-indigo-50 text-indigo-700'
                            : 'border-gray-300 hover:border-gray-400'
                        }`}
                        onClick={() => updateInterviewData('experienceLevel', level)}
                      >
                        <div className="font-medium">
                          {level === 'entry' ? 'Entry Level' : level === 'mid' ? 'Mid Level' : 'Senior Level'}
                        </div>
                        <div className="text-xs text-gray-500">
                          {level === 'entry' ? '0-2 years' : level === 'mid' ? '3-7 years' : '8+ years'}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="bg-gray-50 p-4 flex justify-end">
              <Button onClick={nextStage} icon={<ChevronRight className="w-4 h-4" />} iconPosition="right">
                Continue
              </Button>
            </CardFooter>
          </Card>
        );
        
      case 2: // Interview type settings
        return (
          <Card className="max-w-3xl mx-auto">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold mb-6 text-center">Interview Settings</h2>
              
              <div className="space-y-6">
                <div className="space-y-3">
                  <label className="block text-sm font-medium text-gray-700">Interview Type</label>
                  <p className="text-sm text-gray-500">Select the types of questions you want to practice</p>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {[
                      { id: 'behavioral', label: 'Behavioral Questions' },
                      { id: 'technical', label: 'Technical Questions' },
                      { id: 'situational', label: 'Situational Questions' },
                      { id: 'leadership', label: 'Leadership Questions' },
                      { id: 'problem_solving', label: 'Problem Solving' }
                    ].map((type) => (
                      <button
                        key={type.id}
                        className={`border-2 rounded-lg p-3 flex items-center transition-colors ${
                          interviewType.includes(type.id)
                            ? 'border-indigo-500 bg-indigo-50 text-indigo-700'
                            : 'border-gray-300 hover:border-gray-400'
                        }`}
                        onClick={() => {
                          if (interviewType.includes(type.id)) {
                            setInterviewType(interviewType.filter(t => t !== type.id));
                          } else {
                            setInterviewType([...interviewType, type.id]);
                          }
                        }}
                      >
                        <div className="mr-2 w-5 h-5 flex-shrink-0">
                          {interviewType.includes(type.id) && (
                            <Check className="w-5 h-5 text-indigo-500" />
                          )}
                        </div>
                        <span className="text-sm font-medium">{type.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-3">
                  <label className="block text-sm font-medium text-gray-700">Difficulty Level</label>
                  <p className="text-sm text-gray-500">Set how challenging the interview questions will be</p>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      { id: 'easy', label: 'Easy', desc: 'Beginner friendly' },
                      { id: 'medium', label: 'Medium', desc: 'Standard interview' },
                      { id: 'hard', label: 'Hard', desc: 'Challenging questions' }
                    ].map((level) => (
                      <button
                        key={level.id}
                        className={`border-2 rounded-lg p-3 transition-colors ${
                          difficulty === level.id
                            ? 'border-indigo-500 bg-indigo-50 text-indigo-700'
                            : 'border-gray-300 hover:border-gray-400'
                        }`}
                        onClick={() => setDifficulty(level.id as any)}
                      >
                        <div className="font-medium">{level.label}</div>
                        <div className="text-xs text-gray-500">{level.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-3">
                  <label className="block text-sm font-medium text-gray-700">Interview Duration</label>
                  <p className="text-sm text-gray-500">Approximate length of the interview session</p>
                  <div className="grid grid-cols-3 gap-3">
                    {[15, 30, 45].map((duration) => (
                      <button
                        key={duration}
                        className={`border-2 rounded-lg p-3 transition-colors ${
                          interviewData.duration === duration
                            ? 'border-indigo-500 bg-indigo-50 text-indigo-700'
                            : 'border-gray-300 hover:border-gray-400'
                        }`}
                        onClick={() => updateInterviewData('duration', duration)}
                      >
                        <div className="font-medium">{duration} min</div>
                        <div className="text-xs text-gray-500">
                          {duration === 15 ? 'Short' : duration === 30 ? 'Standard' : 'Extended'}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="bg-gray-50 p-4 flex justify-between">
              <Button variant="outline" onClick={prevStage}>
                Back
              </Button>
              <Button onClick={nextStage} icon={<ChevronRight className="w-4 h-4" />} iconPosition="right">
                Continue
              </Button>
            </CardFooter>
          </Card>
        );
        
      case 3: // Interview preview
        return (
          <Card className="max-w-3xl mx-auto">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold mb-6 text-center">Start Your Interview</h2>
              
              <div className="space-y-6">
                <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
                  <h3 className="font-semibold text-lg mb-4 flex items-center">
                    <Award className="w-5 h-5 mr-2 text-indigo-600" />
                    Interview Details
                  </h3>
                  <dl className="divide-y divide-gray-200">
                    <div className="py-3 flex justify-between">
                      <dt className="text-sm font-medium text-gray-500">Position</dt>
                      <dd className="text-sm font-bold text-gray-900">{interviewData.jobTitle}</dd>
                    </div>
                    <div className="py-3 flex justify-between">
                      <dt className="text-sm font-medium text-gray-500">Company</dt>
                      <dd className="text-sm font-bold text-gray-900">{interviewData.company}</dd>
                    </div>
                    <div className="py-3 flex justify-between">
                      <dt className="text-sm font-medium text-gray-500">Experience Level</dt>
                      <dd className="text-sm font-bold text-gray-900 capitalize">{interviewData.experienceLevel}</dd>
                    </div>
                    <div className="py-3 flex justify-between">
                      <dt className="text-sm font-medium text-gray-500">Question Types</dt>
                      <dd className="text-sm font-bold text-gray-900 capitalize">
                        {interviewType.join(', ').replace(/_/g, ' ')}
                      </dd>
                    </div>
                    <div className="py-3 flex justify-between">
                      <dt className="text-sm font-medium text-gray-500">Difficulty</dt>
                      <dd className="text-sm font-bold text-gray-900 capitalize">{difficulty}</dd>
                    </div>
                    <div className="py-3 flex justify-between">
                      <dt className="text-sm font-medium text-gray-500">Duration</dt>
                      <dd className="text-sm font-bold text-gray-900">{interviewData.duration} minutes</dd>
                    </div>
                  </dl>
                </div>
                
                <div className="bg-indigo-50 rounded-lg p-6 border border-indigo-100">
                  <h3 className="font-semibold text-indigo-800 mb-2">What to Expect</h3>
                  <ul className="space-y-2 text-sm text-indigo-700">
                    <li className="flex items-start">
                      <Check className="w-5 h-5 text-indigo-500 mr-2 flex-shrink-0" />
                      <span>Verify your connection before starting the interview</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="w-5 h-5 text-indigo-500 mr-2 flex-shrink-0" />
                      <span>AI interviewer will ask {difficulty === 'easy' ? 'simpler' : difficulty === 'medium' ? 'standard' : 'challenging'} questions</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="w-5 h-5 text-indigo-500 mr-2 flex-shrink-0" />
                      <span>Click to respond when the interviewer finishes speaking</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="w-5 h-5 text-indigo-500 mr-2 flex-shrink-0" />
                      <span>Receive a detailed assessment of your performance at the end</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="w-5 h-5 text-indigo-500 mr-2 flex-shrink-0" />
                      <span>Your interview will be saved for future reference</span>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
            <CardFooter className="bg-gray-50 p-4 flex flex-col sm:flex-row gap-3 sm:justify-between">
              <div className="flex gap-3">
                <Button variant="outline" onClick={prevStage} icon={<ArrowLeft className="w-4 h-4" />}>
                  Back
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => navigate('/setup')}
                  className="border-gray-300 text-gray-700"
                >
                  Cancel
                </Button>
              </div>
              
              <Button
                onClick={() => {
                  // First generate questions, then start interview
                  setLoading(true);
                  generateQuestions().then(() => {
                    setInterviewStarted(true);
                    setLoading(false);
                  }).catch(err => {
                    console.error('Failed to start interview:', err);
                    setLoading(false);
                    toast.error('Failed to start interview. Please try again.');
                  });
                }}
                loading={loading}
                className="w-full sm:w-auto bg-gradient-to-r from-indigo-600 to-purple-600 text-white"
                icon={<Play className="w-4 h-4 mr-2" />}
              >
                Start Interview
              </Button>
            </CardFooter>
          </Card>
        );
      
      default:
        return <div>Unknown stage</div>;
    }
  };
  
  // If there's an error, display it
  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-indigo-900 py-12 px-4 flex items-center justify-center">
        <div className="bg-white rounded-xl shadow-lg p-8 max-w-md w-full">
          <div className="text-center">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="w-8 h-8 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Interview Error</h2>
            <p className="text-gray-600 mb-6">{error}</p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button variant="outline" onClick={() => navigate('/setup')}>
                Back to Setup
              </Button>
              <Button onClick={() => window.location.reload()}>
                Try Again
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  // If loading, show a loading state
  if (loading && !interviewStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-indigo-900 py-12 px-4 flex items-center justify-center">
        <div className="text-center text-white">
          <div className="w-16 h-16 border-4 border-indigo-400 border-t-indigo-200 rounded-full animate-spin mx-auto mb-6"></div>
          <h2 className="text-2xl font-semibold mb-2">Preparing Your Interview</h2>
          <p className="text-indigo-200">Setting up your AI interview experience...</p>
        </div>
      </div>
    );
  }
  
  // If interview has started, show the interview manager
  if (interviewStarted) {
    return (
      <InterviewManager
        candidateName={user?.email?.split('@')[0] || 'Candidate'}
        interviewerName="Alex"
        jobTitle={interviewData.jobTitle}
        companyName={interviewData.company}
        questionSet={interviewQuestions}
        onComplete={handleInterviewComplete}
        onCancel={() => {
          if (window.confirm('Are you sure you want to cancel this interview? Your progress will be lost.')) {
            navigate('/setup');
          }
        }}
      />
    );
  }
  
  // If interview has an assessment, show it
  if (assessment) {
    return (
      <InterviewAssessment
        assessment={assessment}
        onExport={() => {
          alert('Export functionality would generate a PDF of your results.');
        }}
        onRetake={() => {
          // Reset state and restart interview
          setAssessment(null);
          setInterviewStarted(false);
          generateQuestions().then(() => {
            setInterviewStarted(true);
          });
        }}
        onShare={() => {
          alert('Share functionality would allow you to share your results.');
        }}
      />
    );
  }
  
  // Otherwise, show the setup stages
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-indigo-900 py-12 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="mb-10 text-center">
          <button
            onClick={() => navigate('/setup')}
            className="inline-flex items-center text-white hover:text-indigo-200 transition-colors mb-6"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Setup
          </button>
          
          <h1 className="text-4xl font-bold text-white mb-4">Interactive Interview Experience</h1>
          <p className="text-xl text-indigo-200 max-w-3xl mx-auto">
            Practice with our advanced AI interviewer and receive detailed feedback on your performance
          </p>
        </div>
        
        {/* Setup progress indicator */}
        <div className="flex justify-center mb-10">
          <div className="flex items-center space-x-4 sm:space-x-8">
            {[
              { label: 'Job Details', icon: <Settings className="w-5 h-5" /> },
              { label: 'Interview Settings', icon: <Settings className="w-5 h-5" /> },
              { label: 'Review & Start', icon: <Play className="w-5 h-5" /> }
            ].map((step, index) => (
              <React.Fragment key={index}>
                {index > 0 && (
                  <div className={`w-12 sm:w-20 h-1 ${currentStage > index + 1 ? 'bg-indigo-400' : 'bg-indigo-800'}`}></div>
                )}
                <div className="flex flex-col items-center">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 ${
                    currentStage === index + 1
                      ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/30'
                      : currentStage > index + 1
                        ? 'bg-indigo-400 text-white'
                        : 'bg-indigo-800 text-indigo-400'
                  }`}>
                    {currentStage > index + 1 ? (
                      <Check className="w-6 h-6" />
                    ) : (
                      <span>{index + 1}</span>
                    )}
                  </div>
                  <span className="mt-2 text-xs font-medium text-indigo-200">{step.label}</span>
                </div>
              </React.Fragment>
            ))}
          </div>
        </div>
        
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStage}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4 }}
          >
            {renderSetupStage()}
          </motion.div>
        </AnimatePresence>
        
        {/* Preview of AI interviewer */}
        {!interviewStarted && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            className="mt-12 max-w-sm mx-auto h-96"
          >
            <AIInterviewer
              isActive={true}
              isSpeaking={false}
              interviewerName="Alex"
              companyName={interviewData.company || "Company"}
              statusText="Ready for interview"
              className="h-full w-full"
            />
          </motion.div>
        )}
      </div>
    </div>
  );
}