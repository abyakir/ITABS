import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, Lock, Eye, EyeOff, Brain, Sparkles, ArrowRight } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { useAuth } from '../hooks/useAuth';
import { shouldUseMockAuth } from '../lib/mockAuth';
import toast from 'react-hot-toast';

export function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const { signIn, isMockAuth } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    console.log('Login attempt with:', { email });
    
    if (!email || !password) {
      toast.error('Please fill in all fields');
      return;
    }

    // Demo credentials validation - ensure using correct demo password
    if (email === 'demo@example.com' && password !== 'password123') {
      toast.error('For demo account, please use password123');
      setPassword('password123');
      return;
    }

    setLoading(true);
    try {
      const { data = null, error } = await signIn(email, password);
      console.log('Sign in result:', { success: !!data, hasError: !!error });
      
      if (error) {
        toast.error(error);
      } else {
        // Wait a moment before redirecting to ensure any auth state is updated
        toast.success(`Welcome${email === 'demo@example.com' ? ' to the demo' : ' back'}!`);
        await new Promise(resolve => setTimeout(resolve, 300));
        navigate('/dashboard');
      }
    } catch (error) {
      console.error('Unexpected login error:', error);
      toast.error('An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-indigo-800 py-12 px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-4xl mx-auto"
      >
        <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl overflow-hidden">
          <div className="md:flex">
            {/* Left side - Motivational content */}
            <div className="relative hidden md:block md:w-2/5 bg-gradient-to-br from-indigo-600 to-purple-700 p-12 text-white">
              <div className="absolute inset-0 opacity-20">
                <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:40px_40px]"></div>
              </div>
              
              <div className="relative z-10">
                <h2 className="text-2xl font-bold mb-6">Welcome Back!</h2>
                
                <p className="mb-6">Sign in to continue practicing your interview skills and track your progress.</p>
                
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.3, duration: 0.8 }}
                  className="bg-white/10 rounded-xl p-5 backdrop-blur-sm border border-white/20 mt-10"
                >
                  <div className="flex items-start mb-4">
                    <div className="bg-white/20 p-2 rounded-full mr-3">
                      <Sparkles className="w-5 h-5 text-indigo-200" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-white mb-1">Track Your Progress</h3>
                      <p className="text-sm text-indigo-100">See your improvement over time with detailed performance analytics.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-white/20 p-2 rounded-full mr-3">
                      <Brain className="w-5 h-5 text-indigo-200" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-white mb-1">AI Powered Feedback</h3>
                      <p className="text-sm text-indigo-100">Receive personalized coaching based on your interview responses.</p>
                    </div>
                  </div>
                </motion.div>
              </div>
              
              <div className="absolute bottom-10 left-10 right-10">
                <p className="text-white/70 text-sm">
                  Don't have an account yet?{' '}
                  <Link to="/signup" className="text-white underline font-medium hover:text-indigo-200">
                    Create an account
                  </Link>
                </p>
              </div>
            </div>
            
            {/* Right side - Form */}
            <div className="md:w-3/5 p-8 md:p-12">
              <div className="flex flex-col items-center md:items-start md:ml-6">
                <div className="text-center md:text-left mb-8 w-full">
                  <h2 className="text-3xl font-bold text-gray-900 mb-2">Welcome Back</h2>
                  <p className="text-gray-600">Sign in to continue your interview practice</p>
                </div>

                {isMockAuth && (
                  <div className="my-4 p-3 bg-blue-50 border border-blue-100 rounded-lg">
                    <p className="text-xs text-blue-800">
                      <strong>Development Mode:</strong> Use the demo credentials below or register with any email/password combination.
                    </p>
                    <div className="mt-2 space-x-4">
                      <button
                        type="button"
                        onClick={() => {
                          setEmail('demo@example.com');
                          setPassword('password123');
                        }}
                        className="text-xs bg-white px-2 py-1 rounded border border-blue-200 hover:bg-blue-50"
                      >
                        Use Demo Credentials
                      </button>
                      <Link to="/signup" className="text-xs text-blue-600 hover:text-blue-800 underline">Register new account</Link>
                    </div>
                  </div>
                )}

                {!isMockAuth && (
                  <div className="my-4 p-3 bg-amber-50 border border-amber-100 rounded-lg">
                    <p className="text-xs text-amber-800">
                      <strong>Connected to Supabase:</strong> Use your registered credentials or try demo credentials for development.
                    </p>
                    <div className="mt-2 space-x-4">
                      <button
                        type="button"
                        onClick={() => {
                          setEmail('demo@example.com');
                          setPassword('password123');
                        }}
                        className="text-xs bg-white px-2 py-1 rounded border border-amber-200 hover:bg-amber-50"
                      >
                        Try Demo Mode
                      </button>
                    </div>
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-6 w-full max-w-md">
                  <div className="space-y-4">
                    <Input
                      label="Email Address"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      leftIcon={<Mail className="w-5 h-5" />}
                      placeholder={isMockAuth ? "demo@example.com" : "Enter your email"}
                      required
                      autoFocus
                    />

                  
                  {/* Additional guidance when connection failed */}
                  {email && password && (
                    <div className="mt-2 text-xs text-gray-500">
                      Having trouble signing in? Try using the demo credentials.
                    </div>
                  )}
                    <div className="space-y-1">
                      <Input
                        label="Password"
                        type={showPassword ? 'text' : 'password'}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        leftIcon={<Lock className="w-5 h-5" />}
                        placeholder={isMockAuth ? "password123" : "Enter your password"}
                        rightIcon={
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="text-gray-400 hover:text-gray-600"
                          >
                            {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                          </button>
                        }
                        required
                        placeholder="Your password"
                      />
                      <div className="flex justify-end">
                        <Link
                          to="/forgot-password" 
                          className="text-sm font-medium text-indigo-600 hover:text-indigo-800"
                        >
                          Forgot password?
                        </Link>
                      </div>
                    </div>
                  </div>

                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                      size="lg"
                      loading={loading}
                      icon={<ArrowRight className="w-5 h-5" />}
                      iconPosition="right"
                    >
                      Sign In
                    </Button>
                  </motion.div>

                  {/* Mobile-only signup link */}
                  <div className="text-center mt-6 md:hidden">
                    <p className="text-gray-600">
                      Don't have an account?{' '}
                      <Link
                        to="/signup"
                        className="text-indigo-600 hover:text-indigo-800 font-medium"
                      >
                        Create account
                      </Link>
                    </p>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}