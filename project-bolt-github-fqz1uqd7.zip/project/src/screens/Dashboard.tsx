import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mic, Users, Award, BarChart3, Clock, TrendingUp, Activity } from 'lucide-react';
import DashboardLayout from '../components/layout/DashboardLayout';
import { StatCard } from '../components/dashboard/StatCard';
import { ActivityChart } from '../components/dashboard/ActivityChart';
import { InterviewCard } from '../components/dashboard/InterviewCard';
import { SkillsRadarChart, SkillData } from '../components/dashboard/SkillsRadarChart';
import { Button } from '../components/ui/Button';
import { useProfile } from '../hooks/useProfile';
import { db } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import type { Interview } from '../types';
import toast from 'react-hot-toast';

export function Dashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { stats, refreshStats } = useProfile();
  const [interviews, setInterviews] = useState<Interview[]>([]);
  const [loading, setLoading] = useState(true);
  const [activityData, setActivityData] = useState<any[]>([]);
  const [skillsData, setSkillsData] = useState<SkillData[]>([]);

  useEffect(() => {
    if (user) {
      fetchInterviews();
      refreshStats();
    }
  }, [user]);

  useEffect(() => {
    if (stats) {
      // Generate activity data based on recent activity
      if (stats.recent_activity && stats.recent_activity.length > 0) {
        const chartData = stats.recent_activity.map(activity => ({
          date: activity.date,
          value: activity.score || 0,
          label: 'Score'
        })).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
        
        setActivityData(chartData);
      }
      
      // Generate skills data based on skill progress
      if (stats.skill_progress && stats.skill_progress.length > 0) {
        const radarData = stats.skill_progress.map(skill => ({
          subject: skill.skill,
          value: skill.current_level,
          fullMark: 10
        }));
        
        setSkillsData(radarData);
      }
    }
  }, [stats]);

  const fetchInterviews = async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      const { data, error } = await db.interviews.getAll(user.id);
      
      if (error) throw error;
      
      setInterviews(data);
    } catch (error) {
      console.error('Failed to fetch interviews:', error);
      toast.error('Failed to load interviews');
    } finally {
      setLoading(false);
    }
  };

  const handleStartInterview = () => {
    navigate('/setup');
  };

  const handleViewResults = (id: string) => {
    navigate(`/results/${id}`);
  };

  const handleResumeInterview = (id: string) => {
    navigate(`/elevenlabs-interview/${id}`);
  };

  return (
    <DashboardLayout>
      {/* Page header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1">
            Monitor your interview performance and track your progress
          </p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button
            onClick={handleStartInterview}
            icon={<Mic className="w-5 h-5" />}
          >
            Start New Interview
          </Button>
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          title="Total Interviews"
          value={stats?.total_interviews || 0}
          icon={<Users className="w-6 h-6" />}
          color="blue"
        />
        <StatCard
          title="Completed Interviews"
          value={stats?.completed_interviews || 0}
          icon={<Award className="w-6 h-6" />}
          color="purple"
        />
        <StatCard
          title="Average Score"
          value={stats?.average_score ? stats.average_score.toFixed(1) : '0.0'}
          icon={<BarChart3 className="w-6 h-6" />}
          color="green"
          trend={stats?.improvement_trend > 0 ? {
            direction: 'up',
            value: `${stats?.improvement_trend.toFixed(1)}%`
          } : stats?.improvement_trend < 0 ? {
            direction: 'down',
            value: `${Math.abs(stats?.improvement_trend).toFixed(1)}%`
          } : undefined}
        />
        <StatCard
          title="Practice Time"
          value={`${stats?.total_practice_time || 0} min`}
          icon={<Clock className="w-6 h-6" />}
          color="yellow"
        />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2">
          <ActivityChart
            data={activityData.length > 0 ? activityData : [
              { date: '2023-01-01', value: 6.5, label: 'Score' },
              { date: '2023-01-15', value: 7.2, label: 'Score' },
              { date: '2023-02-01', value: 7.8, label: 'Score' },
              { date: '2023-02-15', value: 7.3, label: 'Score' },
              { date: '2023-03-01', value: 8.1, label: 'Score' },
              { date: '2023-03-15', value: 8.5, label: 'Score' }
            ]}
            title="Interview Performance"
            description="Your interview scores over time"
            yAxisLabel="Score"
            tooltipFormatter={(value) => `${value.toFixed(1)}/10`}
          />
        </div>
        <div>
          <SkillsRadarChart
            data={skillsData.length > 0 ? skillsData : [
              { subject: 'Clarity', value: 8, fullMark: 10 },
              { subject: 'Confidence', value: 7, fullMark: 10 },
              { subject: 'Relevance', value: 9, fullMark: 10 },
              { subject: 'Technical', value: 7, fullMark: 10 },
              { subject: 'Communication', value: 8, fullMark: 10 },
            ]}
            title="Skill Breakdown"
            description="Your performance across key interview competencies"
          />
        </div>
      </div>

      {/* Recent interviews */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-900 flex items-center">
            <Activity className="w-5 h-5 mr-2 text-indigo-600" />
            Recent Interviews
          </h2>
          {interviews.length > 5 && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/interviews')}
            >
              View All
            </Button>
          )}
        </div>

        {loading ? (
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, index) => (
              <div key={index} className="animate-pulse h-24 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        ) : interviews.length > 0 ? (
          <div className="space-y-4">
            {interviews
              .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
              .slice(0, 5)
              .map((interview) => (
                <InterviewCard
                  key={interview.id}
                  id={interview.id}
                  position={interview.job_title}
                  company={interview.company}
                  date={interview.created_at}
                  duration={interview.duration_minutes || 0}
                  status={interview.status as any}
                  score={interview.status === 'completed' ? 7.8 : undefined}
                  onViewResults={handleViewResults}
                  onResume={handleResumeInterview}
                />
              ))}
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
            <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Mic className="w-8 h-8 text-indigo-600" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No interviews yet</h3>
            <p className="text-gray-500 mb-6">
              Start practicing to see your interview history and performance metrics
            </p>
            <Button onClick={handleStartInterview}>
              Start Your First Interview
            </Button>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}