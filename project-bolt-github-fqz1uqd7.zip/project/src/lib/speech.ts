import { getEventManager } from './interviewEvents';

interface SpeechRecognitionOptions {
  lang?: string;
  continuous?: boolean;
  interimResults?: boolean;
  maxAlternatives?: number;
}

interface ContinuousListeningOptions extends SpeechRecognitionOptions {
  onResult?: (transcript: string, isFinal: boolean) => void;
  onError?: (error: any) => void;
  onStart?: () => void;
  onEnd?: () => void;
  emitEvents?: boolean; // Whether to emit client events
}

class SpeechService {
  private recognition: any = null;
  private isListening = false;
  private recognitionStartTime: number = 0;

  constructor() {
    this.initializeRecognition();
  }

  private initializeRecognition() {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      this.recognition = new SpeechRecognition();
      
      this.recognition.continuous = false;
      this.recognition.interimResults = false;
      this.recognition.lang = 'en-US';
      this.recognition.maxAlternatives = 1;
    }
  }

  async startListening(options: SpeechRecognitionOptions = {}): Promise<string> {
    if (!this.recognition) {
      throw new Error('Speech recognition not supported in this browser');
    }

    if (this.isListening) {
      throw new Error('Already listening');
    }

    return new Promise((resolve, reject) => {
      this.isListening = true;

      // Configure recognition
      this.recognition.lang = options.lang || 'en-US';
      this.recognition.continuous = options.continuous || false;
      this.recognition.interimResults = options.interimResults || false;
      this.recognition.maxAlternatives = options.maxAlternatives || 1;

      this.recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        this.isListening = false;
        resolve(transcript.trim());
      };

      this.recognition.onerror = (event: any) => {
        this.isListening = false;
        reject(new Error(`Speech recognition error: ${event.error}`));
      };

      this.recognition.onend = () => {
        this.isListening = false;
      };

      try {
        this.recognition.start();
      } catch (error) {
        this.isListening = false;
        reject(error);
      }
    });
  }

  // Continuous listening with real-time callbacks
  startContinuousListening(options: ContinuousListeningOptions = {}): any {
    if (!this.recognition) {
      throw new Error('Speech recognition not supported in this browser');
    }

    if (this.isListening) {
      this.stopListening();
    }

    // Configure recognition for continuous listening
    this.recognition.lang = options.lang || 'en-US';
    this.recognition.continuous = true;
    this.recognition.interimResults = true;
    this.recognition.maxAlternatives = options.maxAlternatives || 1;

    this.recognition.onstart = () => {
      this.isListening = true;
      this.recognitionStartTime = Date.now();
      console.log('Speech recognition started');
      if (options.onStart) options.onStart();
    };

    this.recognition.onresult = (event: any) => {
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        const transcript = result[0].transcript;
        const isFinal = result.isFinal;
        const confidence = result[0].confidence || 0.8;

        // Emit user transcript event if enabled
        if (options.emitEvents !== false) {
          const eventManager = getEventManager();
          if (eventManager) {
            const duration = Date.now() - (this.recognitionStartTime || Date.now());
            eventManager.emitUserTranscript(transcript, isFinal, confidence, duration);

            // Emit VAD score based on transcript length and confidence
            const vadScore = Math.min(1.0, (transcript.length / 50) * confidence);
            eventManager.emitVADScore(vadScore);
          }
        }

        if (options.onResult) {
          options.onResult(transcript, isFinal);
        }
      }
    };

    this.recognition.onerror = (event: any) => {
      console.warn('Speech recognition error:', event.error);
      if (options.onError) {
        options.onError(event);
      }
    };

    this.recognition.onend = () => {
      this.isListening = false;
      console.log('Speech recognition ended');
      if (options.onEnd) options.onEnd();
    };

    try {
      this.recognition.start();
      return this.recognition;
    } catch (error) {
      this.isListening = false;
      throw error;
    }
  }

  stopListening(): void {
    if (this.recognition && this.isListening) {
      this.recognition.stop();
      this.isListening = false;
    }
  }

  getIsListening(): boolean {
    return this.isListening;
  }

  isSupported(): boolean {
    return 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
  }
}

export const speechService = new SpeechService();