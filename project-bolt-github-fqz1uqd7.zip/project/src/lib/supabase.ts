import { createClient } from '@supabase/supabase-js';
import type { User, UserProfile, UserPreferences, Interview, Message, Score } from '../types';
import { shouldUseMockAuth, mockAuth } from './mockAuth';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://placeholder.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'placeholder-anon-key';

// Check if Supabase is properly configured
const isSupabaseConfigured = () => {
  // First check if we should use mock auth
  if (shouldUseMockAuth()) {
    return false;
  }
  
  // Additional validation for real Supabase configuration
  const isValidUrl = supabaseUrl && 
                     supabaseUrl !== 'https://placeholder.supabase.co' && 
                     supabaseUrl !== 'https://your-project.supabase.co' &&
                     supabaseUrl.includes('supabase.co') &&
                     !supabaseUrl.includes('placeholder') &&
                     !supabaseUrl.includes('your-project');
                     
  const isValidKey = supabaseAnonKey && 
                     supabaseAnonKey !== 'placeholder-anon-key' &&
                     supabaseAnonKey !== 'your-anon-key' &&
                     supabaseAnonKey.length > 10 &&
                     !supabaseAnonKey.includes('placeholder') &&
                     !supabaseAnonKey.includes('your-');
                     
  return isValidUrl && isValidKey;
};

// Track if we've detected connection issues
let hasConnectionIssues = false;

// Helper to detect if we should fall back to mock mode due to connection issues
const shouldFallbackToMock = () => {
  return hasConnectionIssues || !isSupabaseConfigured();
};

// Helper to handle Supabase operation with automatic fallback
const withFallback = async <T>(
  operation: () => Promise<T>, 
  mockFallback: () => Promise<T> | T,
  operationName: string = 'operation'
): Promise<T> => {
  if (shouldFallbackToMock()) {
    console.log(`🔧 Using mock mode for ${operationName}`);
    return await mockFallback();
  }

  try {
    return await operation();
  } catch (error: any) {
    // Extract error details from nested error object if it exists
    const errorMessage = error.error?.message || error.message;
    const errorCode = error.error?.code || error.code;
    const errorName = error.error?.name || error.name;
    
    // Check if it's a network/connection error
    if (errorMessage?.includes('Failed to fetch') || 
        errorMessage?.includes('NetworkError') ||
        errorMessage?.includes('fetch') ||
        errorName === 'TypeError' ||
        errorCode === 'NETWORK_ERROR') {
      console.warn(`🔧 Supabase connection failed for ${operationName}, falling back to mock mode:`, errorMessage);
      hasConnectionIssues = true;
      return await mockFallback();
    }
    // Re-throw other errors
    throw error;
  }
};

if (!isSupabaseConfigured()) {
  console.info('🔧 Supabase not configured or using placeholder values.');
  console.info('🔧 Using mock authentication for development.');
  console.info('🔧 To use real Supabase, set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY with actual values.');
}

// Create a mock Supabase client for development when not configured
const createMockSupabaseClient = () => {
  return {
    auth: {
      signUp: () => Promise.resolve({ data: null, error: { message: 'Mock mode' } }),
      signInWithPassword: () => Promise.resolve({ data: null, error: { message: 'Mock mode' } }),
      signOut: () => Promise.resolve({ error: null }),
      getUser: () => Promise.resolve({ data: null, error: { message: 'Mock mode' } }),
      getSession: () => Promise.resolve({ data: null, error: { message: 'Mock mode' } }),
      onAuthStateChange: () => ({ data: { subscription: null } }),
      updateUser: () => Promise.resolve({ data: null, error: { message: 'Mock mode' } }),
      resetPasswordForEmail: () => Promise.resolve({ data: null, error: { message: 'Mock mode' } }),
      mfa: {
        enroll: () => Promise.resolve({ data: null, error: { message: 'Mock mode' } }),
        verify: () => Promise.resolve({ data: null, error: { message: 'Mock mode' } }),
        challenge: () => Promise.resolve({ data: null, error: { message: 'Mock mode' } })
      }
    },
    from: () => ({
      select: () => ({ 
        eq: () => ({ 
          single: () => Promise.resolve({ data: null, error: { message: 'Mock mode' } }),
          order: () => Promise.resolve({ data: [], error: { message: 'Mock mode' } }),
          limit: () => ({ single: () => Promise.resolve({ data: null, error: { message: 'Mock mode' } }) }),
          in: () => Promise.resolve({ data: [], error: { message: 'Mock mode' } })
        }),
        in: () => Promise.resolve({ data: [], error: { message: 'Mock mode' } }),
        order: () => Promise.resolve({ data: [], error: { message: 'Mock mode' } }),
        single: () => Promise.resolve({ data: null, error: { message: 'Mock mode' } })
      }),
      insert: () => ({ 
        select: () => ({ 
          single: () => Promise.resolve({ data: null, error: { message: 'Mock mode' } }) 
        }) 
      }),
      update: () => ({ 
        eq: () => ({ 
          select: () => ({ 
            single: () => Promise.resolve({ data: null, error: { message: 'Mock mode' } }) 
          }) 
        }) 
      }),
      delete: () => ({ 
        eq: () => Promise.resolve({ data: null, error: { message: 'Mock mode' } }) 
      }),
      upsert: () => ({ 
        select: () => ({ 
          single: () => Promise.resolve({ data: null, error: { message: 'Mock mode' } }) 
        }) 
      })
    }),
    storage: {
      from: () => ({
        upload: () => Promise.resolve({ data: null, error: { message: 'Mock mode' } }),
        getPublicUrl: () => ({ data: { publicUrl: 'mock-url' } }),
        remove: () => Promise.resolve({ data: null, error: { message: 'Mock mode' } })
      })
    },
    channel: () => ({
      on: () => {
        const mockChannel = {
          subscribe: () => Promise.resolve()
        };
        return mockChannel;
      },
      subscribe: () => Promise.resolve()
    })
  };
};

// Conditionally create the Supabase client
export const supabase = isSupabaseConfigured() 
  ? createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        autoRefreshToken: true,
        persistSession: true,
        detectSessionInUrl: true,
        storageKey: 'interview-ai-auth-token',
        storage: localStorage
      }
    })
  : createMockSupabaseClient() as any;

// Export realtime functionality
export const realtime = {
  subscribeToInterview: (interviewId: string, callback: (payload: any) => void) => {
    try {
      const subscription = supabase
        .channel(`interview:${interviewId}`)
        .on('postgres_changes', {
          event: '*',
          schema: 'public',
          table: 'messages',
          filter: `interview_id=eq.${interviewId}`
        }, callback)
        .subscribe();
      
      return subscription;
    } catch (error) {
      console.error('Error setting up real-time subscription:', error);
      // Return a no-op subscription object as fallback
      return {
        unsubscribe: () => console.log('Mock unsubscribe called - no actual subscription existed')
      };
    }
  },

  subscribeToUserSessions: (userId: string, callback: (payload: any) => void) => {
    try {
      const subscription = supabase
        .channel(`user_sessions:${userId}`)
        .on('postgres_changes', {
          event: '*',
          schema: 'public',
          table: 'user_sessions',
          filter: `user_id=eq.${userId}`
        }, callback)
        .subscribe();
      
      return subscription;
    } catch (error) {
      console.error('Error setting up user sessions subscription:', error);
      // Return a no-op subscription object as fallback
      return {
        unsubscribe: () => console.log('Mock unsubscribe called - no actual subscription existed')
      };
    }
  }
};

// Auth helpers
export const auth = {
  // Using the mock auth service when Supabase is not configured
  signUp: async (email: string, password: string) => {
    if (shouldUseMockAuth() || !isSupabaseConfigured()) {
      console.log('🔧 Using mock auth for signup');
      return await mockAuth.signUp(email, password);
    }

    try {
      return await supabase.auth.signUp({ 
        email, 
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/auth/callback`
        }
      });
    } catch (error) {
      console.error('Supabase signup failed, falling back to mock auth:', error);
      return await mockAuth.signUp(email, password);
    }
  },
  
  signIn: async (email: string, password: string) => {
    if (shouldUseMockAuth() || !isSupabaseConfigured()) {
      console.log('🔧 Using mock auth for signin');
      return await mockAuth.signIn(email, password);
    }

    try {
      console.log('Attempting Supabase authentication...');
      const result = await supabase.auth.signInWithPassword({ email, password });
      
      if (result.error) {
        console.warn('Supabase auth error:', result.error.message);
        
        // Check if it's a demo/mock scenario 
        if ((email === 'demo@example.com' || 
             email.includes('test') || 
             email.includes('mock') ||
             password === 'password123') && 
             (result.error.message.includes('Invalid login credentials') || 
              result.error.message.includes('Failed'))) {
            console.log('Demo credentials detected, switching to mock auth mode');
            return await mockAuth.signIn(email, password);
         }
       }
       
       return result;
     } catch (error) {
       console.error('Supabase signin failed:', error);
       
       // For demo accounts, always fall back to mock auth
       if (email === 'demo@example.com' || password === 'password123') {
         console.log('Demo credentials detected during error, using mock auth');
         try {
           // Ensure the demo user exists in mock auth
           await mockAuth.signUp(email, password);
           return await mockAuth.signIn(email, password);
         } catch (mockError) {
           console.error('Even mock auth failed:', mockError);
           return { data: null, error: { message: 'Authentication failed completely' } };
         }
       }
       
       // For non-demo accounts, throw the error
       return { 
         data: null, 
         error: { 
           message: error instanceof Error 
             ? error.message 
             : 'Failed to connect to authentication service' 
         }
       };
     }
   },
  
  signOut: async () => {
    if (shouldUseMockAuth() || !isSupabaseConfigured()) {
      console.log('🔧 Using mock auth for signout');
      return await mockAuth.signOut();
    }
    
    return await supabase.auth.signOut();
  },
  
  getCurrentUser: async () => {
    if (shouldUseMockAuth() || !isSupabaseConfigured()) {
      console.log('🔧 Using mock auth for getCurrentUser');
      return await mockAuth.getCurrentUser();
    }
    
    return await supabase.auth.getUser();
  },
  
  onAuthStateChange: (callback: (event: string, session: any) => void) => {
    if (shouldUseMockAuth() || !isSupabaseConfigured()) {
      console.log('🔧 Using mock auth for onAuthStateChange');
      return mockAuth.onAuthStateChange(callback);
    }
    
    return supabase.auth.onAuthStateChange(callback);
  },

  // TOTP methods
  enrollMFA: async () => {
    return await supabase.auth.mfa.enroll({ factorType: 'totp' });
  },

  getSession: async () => {
    return await supabase.auth.getSession();
  },

  verifyMFA: async (factorId: string, code: string) => {
    return await supabase.auth.mfa.verify({ factorId, code });
  },

  challengeMFA: async (factorId: string) => {
    return await supabase.auth.mfa.challenge({ factorId });
  },

  // Password reset
  resetPassword: async (email: string) => {
    return await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`
    });
  },

  // Update password
  updatePassword: async (password: string) => {
    if (shouldUseMockAuth() || !isSupabaseConfigured()) {
      console.log('🔧 Using mock auth for updatePassword');
      return await mockAuth.updatePassword(password);
    }
    
    return await supabase.auth.updateUser({ password });
  },

  // Update email
  updateEmail: async (email: string) => {
    if (shouldUseMockAuth() || !isSupabaseConfigured()) {
      console.log('🔧 Using mock auth for updateEmail');
      return await mockAuth.updateEmail(email);
    }
    
    return await supabase.auth.updateUser({ email });
  }
};

// Enhanced security and error handling functions
export const security = {
  validateAuthentication: async () => {
    const { data, error } = await supabase.auth.getSession();
    if (error || !data.session) {
      return {
        authenticated: false,
        error: error?.message || 'Not authenticated'
      };
    }
    return {
      authenticated: true,
      session: data.session
    };
  },
  
  handleDatabaseError: (error: any) => {
    // Format and categorize database errors for better user feedback
    if (!error) return 'Unknown error';
    
    console.error('Database error:', error);
    
    const errorMap: Record<string, string> = {
      '23505': 'This record already exists.',
      '23503': 'Referenced record does not exist.',
      '23502': 'Required field is missing.',
      '42P01': 'Database table not found.',
      '42501': 'Insufficient permissions.',
      'PGRST301': 'Database connection error.'
    };
    
    // Return user-friendly message based on error code
    if (error.code && errorMap[error.code]) {
      return errorMap[error.code];
    }
    
    // Generic error message for other cases
    return error.message || 'An unexpected database error occurred.';
  }
};

// Database helpers
export const db = {
  // Mock database operations are not implemented yet
  // This is a placeholder for future mock implementations
  _isMockMode: shouldUseMockAuth() || !isSupabaseConfigured(),
  
  // User Profiles
  userProfiles: {
    get: async (userId: string) => {
      return await withFallback(
        async () => {
          console.log('Fetching profile for user:', userId);
          return await supabase
            .from('user_profiles')
            .select('*')
            .eq('id', userId)
            .single();
        },
        () => {
          console.log('🔧 Mock mode: Simulating profile fetch for user:', userId);
          return {
            data: {
              id: userId,
              first_name: 'Demo',
              last_name: 'User',
              onboarding_completed: true,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString()
            },
            error: null
          };
        },
        'userProfiles.get'
      );
    },
    
    create: async (userId: string, data: Partial<UserProfile>) => {
      return await withFallback(
        async () => {
          console.log('Creating profile for user:', userId, 'with data:', data);
          return await supabase
            .from('user_profiles')
            .insert({ id: userId, ...data })
            .select()
            .single();
        },
        () => {
          console.log('🔧 Mock mode: Simulating profile creation for user:', userId);
          return {
            data: {
              id: userId,
              ...data,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString()
            },
            error: null
          };
        },
        'userProfiles.create'
      );
    },
    
    update: async (userId: string, data: Partial<UserProfile>) => {
      return await withFallback(
        async () => {
          console.log('Updating profile for user:', userId, 'with data:', data);
          return await supabase
            .from('user_profiles')
            .update({ 
              ...data, 
              updated_at: new Date().toISOString() 
            })
            .eq('id', userId)
            .select()
            .single();
        },
        () => {
          console.log('🔧 Mock mode: Simulating profile update for user:', userId);
          return {
            data: {
              id: userId,
              ...data,
              updated_at: new Date().toISOString()
            },
            error: null
          };
        },
        'userProfiles.update'
      );
    },

    delete: async (userId: string) => {
      return await withFallback(
        async () => {
          return await supabase
            .from('user_profiles')
            .delete()
            .eq('id', userId);
        },
        () => {
          console.log('🔧 Mock mode: Simulating profile deletion for user:', userId);
          return { data: null, error: null };
        },
        'userProfiles.delete'
      );
    },

    // Get user statistics
    getStats: async (userId: string) => {
      return await withFallback(
        async () => {
          const interviewsResult = await supabase
            .from('interviews')
            .select('*')
            .eq('user_id', userId);

          if (interviewsResult.error) {
            throw interviewsResult.error;
          }

          const interviews = interviewsResult.data || [];
          
          if (interviews.length === 0) {
            return { interviews: [], scores: [] };
          }

          const interviewIds = interviews.map(i => i.id);
          
          const scoresResult = await supabase
            .from('scores')
            .select('*')
            .in('interview_id', interviewIds);

          if (scoresResult.error) {
            throw scoresResult.error;
          }

          return {
            interviews,
            scores: scoresResult.data || []
          };
        },
        () => {
          console.log('🔧 Mock mode: Simulating stats fetch for user:', userId);
          return {
            interviews: [],
            scores: []
          };
        },
        'userProfiles.getStats'
      );
    }
  },
  
  // User Preferences
  userPreferences: {
    get: async (userId: string) => {
      return await withFallback(
        async () => {
          return await supabase
            .from('user_preferences')
            .select('*')
            .eq('user_id', userId)
            .single();
        },
        () => {
          console.log('🔧 Mock mode: Simulating preferences fetch for user:', userId);
          return {
            data: {
              user_id: userId,
              email_notifications: true,
              theme_preference: 'light',
              language: 'en',
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString()
            },
            error: null
          };
        },
        'userPreferences.get'
      );
    },
    
    create: async (userId: string, data: Partial<UserPreferences>) => {
      return await withFallback(
        async () => {
          return await supabase
            .from('user_preferences')
            .insert({ user_id: userId, ...data })
            .select()
            .single();
        },
        () => {
          console.log('🔧 Mock mode: Simulating preferences creation for user:', userId);
          return {
            data: {
              user_id: userId,
              ...data,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString()
            },
            error: null
          };
        },
        'userPreferences.create'
      );
    },
    
    update: async (userId: string, data: Partial<UserPreferences>) => {
      return await withFallback(
        async () => {
          return await supabase
            .from('user_preferences')
            .update({ ...data, updated_at: new Date().toISOString() })
            .eq('user_id', userId)
            .select()
            .single();
        },
        () => {
          console.log('🔧 Mock mode: Simulating preferences update for user:', userId);
          return {
            data: {
              user_id: userId,
              ...data,
              updated_at: new Date().toISOString()
            },
            error: null
          };
        },
        'userPreferences.update'
      );
    },

    // Initialize default preferences
    initializeDefaults: async (userId: string) => {
      const defaultPreferences = {
        user_id: userId,
        email_notifications: true,
        interview_reminders: true,
        performance_insights: true,
        camera_verification_enabled: true,
        face_detection_enabled: true,
        privacy_mode: 'standard' as const,
        theme_preference: 'light' as const,
        language: 'en',
        font_size: 'medium',
        high_contrast: false,
        reduce_motion: false,
        voice_id: '21m00Tcm4TlvDq8ikWAM',
        speech_speed: 1.0,
        microphone_sensitivity: 75,
        noise_cancellation: 'auto',
        video_quality: 'auto',
        mirror_video: true
      };

      return await withFallback(
        async () => {
          return await supabase
            .from('user_preferences')
            .upsert(defaultPreferences)
            .select()
            .single();
        },
        () => {
          console.log('🔧 Mock mode: Simulating default preferences initialization for user:', userId);
          return {
            data: defaultPreferences,
            error: null
          };
        },
        'userPreferences.initializeDefaults'
      );
    }
  },
  
  // Interviews
  interviews: {
    create: async (data: Omit<Interview, 'id' | 'created_at' | 'duration_minutes'>) => {
     if (shouldUseMockAuth() || !isSupabaseConfigured()) {
       console.log('🔧 Mock mode: Simulating interview creation');
       // Return mock interview
       return {
         data: {
           id: `mock-interview-${Date.now()}`,
           ...data,
           created_at: new Date().toISOString(),
           duration_minutes: 0
         },
         error: null
       };
     }
     
      // Validate required fields
      if (!data.job_title || !data.company) {
        console.error('Missing required fields for interview creation');
        return { 
          data: null, 
          error: { message: 'Missing required fields: job_title and company are required' } 
        };
      }
      
      return await supabase.from('interviews').insert({
        ...data,
        status: data.status || 'pending',
        experience_level: data.experience_level || 'mid',
        interview_phase: data.interview_phase || 'opening'
      }).select().single();
    },
    
    getAll: async (userId: string) => {
     if (shouldUseMockAuth() || !isSupabaseConfigured()) {
       console.log('🔧 Mock mode: Simulating interview fetch for user:', userId);
       // Return empty array of interviews
       return {
         data: [],
         error: null
       };
     }
     
      return await supabase
        .from('interviews')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
    },
    
    getById: async (id: string) => {
     if (shouldUseMockAuth() || !isSupabaseConfigured()) {
       console.log('🔧 Mock mode: Simulating interview fetch by ID:', id);
       // Return mock interview
       return {
         data: {
           id,
           user_id: 'mock-user',
           job_title: 'Mock Job',
           company: 'Mock Company',
           status: 'in_progress',
           created_at: new Date().toISOString(),
           duration_minutes: 0
         },
         error: null
       };
     }
     
      return await supabase
        .from('interviews')
        .select('*')
        .eq('id', id)
        .single();
    },
    
    update: async (id: string, data: Partial<Interview>) => {
     if (shouldUseMockAuth() || !isSupabaseConfigured()) {
       console.log('🔧 Mock mode: Simulating interview update for ID:', id);
       // Return mock updated interview
       return {
         data: {
           id,
           user_id: 'mock-user',
           job_title: 'Mock Job',
           company: 'Mock Company',
           ...data,
           created_at: new Date().toISOString()
         },
         error: null
       };
     }
     
      return await supabase
        .from('interviews')
        .update(data)
        .eq('id', id)
        .select()
        .single();
    },

    delete: async (id: string) => {
     if (shouldUseMockAuth() || !isSupabaseConfigured()) {
       console.log('🔧 Mock mode: Simulating interview deletion for ID:', id);
       return { data: null, error: null };
     }
     
      return await supabase
        .from('interviews')
        .delete()
        .eq('id', id);
    },

    // Get interview with related data
    getWithDetails: async (id: string) => {
     if (shouldUseMockAuth() || !isSupabaseConfigured()) {
       console.log('🔧 Mock mode: Simulating interview details fetch for ID:', id);
       // Return mock interview with details
       return {
         interview: {
           id,
           user_id: 'mock-user',
           job_title: 'Mock Job',
           company: 'Mock Company',
           status: 'in_progress',
           created_at: new Date().toISOString(),
           duration_minutes: 0
         },
         messages: [],
         score: null,
         errors: {
           interview: null,
           messages: null,
           score: null
         }
       };
     }
     
      const [interview, messages, score] = await Promise.all([
        supabase.from('interviews').select('*').eq('id', id).single(),
        supabase.from('messages').select('*').eq('interview_id', id).order('created_at'),
        supabase.from('scores').select('*').eq('interview_id', id).single()
      ]);

      return {
        interview: interview.data,
        messages: messages.data || [],
        score: score.data,
        errors: {
          interview: interview.error,
          messages: messages.error,
          score: score.error
        }
      };
    }
  },
  
  // Messages
  messages: {
    create: async (data: Omit<Message, 'id' | 'created_at'>) => {
      return await supabase.from('messages').insert(data).select().single();
    },
    
    getByInterviewId: async (interviewId: string) => {
      return await supabase
        .from('messages')
        .select('*')
        .eq('interview_id', interviewId)
        .order('created_at', { ascending: true });
    },

    update: async (id: number, data: Partial<Message>) => {
      return await supabase
        .from('messages')
        .update(data)
        .eq('id', id)
        .select()
        .single();
    },

    delete: async (id: number) => {
      return await supabase
        .from('messages')
        .delete()
        .eq('id', id);
    }
  },
  
  // Scores
  scores: {
    create: async (data: Omit<Score, 'created_at'>) => {
      // Map the enhanced Score interface to the database schema
      const dbData = {
        interview_id: data.interview_id,
        clarity: data.clarity,
        confidence: data.confidence,
        relevance: data.relevance,
        communication: data.communication,
        technical_skills: data.technical_skills,
        overall_score: data.overall_score,
        summary: data.summary,
        recommendations: data.recommendations,
        // Enhanced scoring fields
        professionalism: data.professionalism,
        behavioral_appropriateness: data.behavioral_appropriateness,
        engagement_level: data.engagement_level,
        screen_sharing_quality: data.screen_sharing_quality || null,
        presentation_skills: data.presentation_skills || null,
        response_quality_trend: data.response_quality_trend || 'stable',
        // JSON fields
        strengths: data.strengths || [],
        improvements: data.improvements || [],
        industry_comparison: data.industry_comparison || null,
        real_time_scores: data.real_time_scores || [],
        behavioral_incidents: data.behavioral_incidents || [],
        screen_share_analysis: data.screen_share_analysis || []
      };
      return await supabase.from('scores').insert(dbData).select().single();
    },
    
    getByInterviewId: async (interviewId: string) => {
      return await supabase
        .from('scores')
        .select('*')
        .eq('interview_id', interviewId)
        .single();
    },

    update: async (interviewId: string, data: Partial<Score>) => {
      return await supabase
        .from('scores')
        .update(data)
        .eq('interview_id', interviewId)
        .select()
        .single();
    },

    delete: async (interviewId: string) => {
      return await supabase
        .from('scores')
        .delete()
        .eq('interview_id', interviewId);
    },

    // Get user's score history
    getUserScores: async (userId: string) => {
      return await supabase
        .from('scores')
        .select(`
          *,
          interviews!inner(
            id,
            job_title,
            company,
            created_at,
            user_id
          )
        `)
        .eq('interviews.user_id', userId)
        .order('created_at', { ascending: false });
    }
  },

  // User Sessions
  userSessions: {
    create: async (data: {
      user_id: string;
      session_type: 'interview' | 'practice' | 'assessment';
      camera_verified?: boolean;
      face_detected?: boolean;
    }) => {
      return await supabase
        .from('user_sessions')
        .insert(data)
        .select()
        .single();
    },

    update: async (id: string, data: {
      ended_at?: string;
      camera_verified?: boolean;
      face_detected?: boolean;
      verification_screenshots?: any[];
    }) => {
      return await supabase
        .from('user_sessions')
        .update(data)
        .eq('id', id)
        .select()
        .single();
    },

    getActive: async (userId: string) => {
      return await supabase
        .from('user_sessions')
        .select('*')
        .eq('user_id', userId)
        .is('ended_at', null)
        .order('started_at', { ascending: false })
        .limit(1)
        .single();
    }
  }
};

// Storage helpers
export const storage = {
  uploadProfilePhoto: async (userId: string, file: File) => {
    return await withFallback(
      async () => {
        const fileExt = file.name.split('.').pop();
        const fileName = `${userId}/profile.${fileExt}`;
        
        const { data, error } = await supabase.storage
          .from('profile-photos')
          .upload(fileName, file, { upsert: true });
        
        if (error) throw error;
        
        const { data: { publicUrl } } = supabase.storage
          .from('profile-photos')
          .getPublicUrl(fileName);
        
        return { publicUrl };
      },
      () => {
        console.log('🔧 Mock mode: Simulating profile photo upload');
        return { publicUrl: `https://mock-storage.com/profile-photos/${userId}/profile.jpg` };
      },
      'storage.uploadProfilePhoto'
    );
  },

  uploadResume: async (userId: string, file: File) => {
    return await withFallback(
      async () => {
        const fileExt = file.name.split('.').pop();
        const fileName = `${userId}/resume.${fileExt}`;
        
        const { data, error } = await supabase.storage
          .from('resumes')
          .upload(fileName, file, { upsert: true });
        
        if (error) throw error;
        
        const { data: { publicUrl } } = supabase.storage
          .from('resumes')
          .getPublicUrl(fileName);
        
        return { publicUrl };
      },
      () => {
        console.log('🔧 Mock mode: Simulating resume upload');
        return { publicUrl: `https://mock-storage.com/resumes/${userId}/resume.pdf` };
      },
      'storage.uploadResume'
    );
  },
  exportUserData: async (userId: string) => {
    return await withFallback(
      async () => {
        // Get user profile
        const { data: profile } = await db.userProfiles.get(userId);
        
        // Get user preferences
        const { data: preferences } = await db.userPreferences.get(userId);
        
        // Get user interviews
        const { data: interviews } = await db.interviews.getAll(userId);
        
        // Get user stats
        const stats = await db.userProfiles.getStats(userId);
        
        return {
          profile,
          preferences,
          interviews,
          stats,
          exportDate: new Date().toISOString()
        };
      },
      () => {
        console.log('🔧 Mock mode: Simulating user data export');
        return {
          profile: { id: userId, first_name: 'Demo', last_name: 'User' },
          preferences: { user_id: userId, theme_preference: 'light' },
          interviews: [],
          stats: { interviews: [], scores: [] },
          exportDate: new Date().toISOString()
        };
      },
      'storage.exportUserData'
    );
  }
};