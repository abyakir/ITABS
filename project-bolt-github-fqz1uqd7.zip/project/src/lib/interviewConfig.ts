import type { ClientEvents } from './interviewEvents';

// UI Theme Configuration
interface UITheme {
  colors: {
    primaryBackground: string;
    secondaryBackground: string;
    tertiaryBackground: string;
    borderColor: string;
    textSecondary: string;
    textPrimary: string;
    error: string;
    darkBackground: string;
    darkSecondary: string;
    darkTertiary: string;
    whiteText: string;
  };
  typography: {
    largeText: string;
    mediumText: string;
    smallText: string;
    buttonText: string;
    headerText: string;
    titleText: string;
    bodyText: string;
  };
}

// Widget Text Configuration
interface WidgetText {
  interactive: {
    helpText: string;
    callActions: {
      start: string;
      new: string;
      end: string;
    };
    audioControls: {
      mute: string;
    };
    language: string;
    uiControls: {
      collapse: string;
      expand: string;
    };
    feedback: {
      copied: string;
      accept: string;
      cancel: string;
    };
  };
  status: {
    activeStates: {
      listening: string;
      talkToInterrupt: string;
      connecting: string;
    };
    inputPrompts: {
      textMessage: string;
      sendMessage: string;
    };
    sessionEnd: {
      userEnded: string;
      agentEnded: string;
    };
    systemInfo: {
      conversationId: string;
      error: string;
      copyId: string;
    };
  };
}

// Terms and Conditions Configuration
interface TermsConfig {
  content: string;
  localStorageKey: string;
  required: boolean;
  supportMarkdown: boolean;
}

// Main Interview Configuration
interface InterviewConfig {
  // Agent Configuration
  agentName: string;
  companyName: string;
  jobTitle: string;
  
  // Introduction Template
  introductionTemplate: string;
  
  // System Prompt
  systemPrompt: string;
  
  // Client Events Configuration
  events: ClientEvents;
  
  // UI Theme
  theme: UITheme;
  
  // Widget Text
  widgetText: WidgetText;
  
  // Terms and Conditions
  termsAndConditions: TermsConfig;
  
  // Helper Methods
  generateIntroduction(): string;
  generateSystemPrompt(): string;
}

// Default Configurations - Using your exact theme specifications
const defaultUITheme: UITheme = {
  colors: {
    primaryBackground: "#ffffff",      // White background
    secondaryBackground: "#f9fafb",    // Light gray background
    tertiaryBackground: "#f3f4f6",     // Lighter gray background
    borderColor: "#e5e7eb",            // Border gray
    textSecondary: "#6b7280",          // Secondary text gray
    textPrimary: "#000000",            // Primary text black
    error: "#ef4444",                  // Error red
    darkBackground: "#1f2937",         // Dark background
    darkSecondary: "#374151",          // Dark secondary
    darkTertiary: "#4b5563",           // Dark tertiary
    whiteText: "#ffffff"               // White text
  },
  typography: {
    largeText: "32px",                 // Large text size
    mediumText: "18px",                // Medium text size
    smallText: "10px",                 // Small text size
    buttonText: "15px",                // Button text size
    headerText: "24px",                // Header text size
    titleText: "30px",                 // Title text size
    bodyText: "16px"                   // Body text size
  }
};

// Widget Text Content - Using your exact text specifications
const defaultWidgetText: WidgetText = {
  interactive: {
    helpText: "Need help?",              // Help text
    callActions: {
      start: "Start a call",             // Start call button
      new: "New call",                   // New call button
      end: "End"                         // End call button
    },
    audioControls: {
      mute: "Mute microphone"            // Mute button text
    },
    language: "Change language",         // Language selector
    uiControls: {
      collapse: "Collapse",              // Collapse control
      expand: "Expand"                   // Expand control
    },
    feedback: {
      copied: "Copied!",                 // Copy success message
      accept: "Accept",                  // Accept button
      cancel: "Cancel"                   // Cancel button
    }
  },
  status: {
    activeStates: {
      listening: "Listening",            // Listening status
      talkToInterrupt: "Talk to interrupt", // Interruption prompt
      connecting: "Connecting"           // Connection status
    },
    inputPrompts: {
      textMessage: "Text message input", // Text input placeholder
      sendMessage: "Or send a message"   // Alternative input prompt
    },
    sessionEnd: {
      userEnded: "You ended the conversation",     // User ended session
      agentEnded: "The agent ended the conversation" // Agent ended session
    },
    systemInfo: {
      conversationId: "Conversation ID", // Conversation ID label
      error: "An error occurred",        // Error message
      copyId: "Copy ID"                  // Copy ID button
    }
  }
};

// Terms and Conditions - Your Exact Specifications
const defaultTermsConfig: TermsConfig = {
  content: `#### Terms and conditions

By clicking "Agree," and each time I interact with this AI agent, I consent to the recording, storage, and sharing of my communications with third-party service providers, and as described in the Privacy Policy.

If you do not wish to have your conversations recorded, please refrain from using this service.`,
  localStorageKey: "terms_accepted",
  required: true,
  supportMarkdown: true
};

const defaultClientEvents: ClientEvents = {
  audio: true,
  interruption: true,
  user_transcript: true,
  vad_score: true,
  agent_response: true,
  agent_response_correction: true,
  text_input: true,
  conversation_transcript: true
};

// Interview Configuration Implementation
class InterviewConfigImpl implements InterviewConfig {
  agentName: string;
  companyName: string;
  jobTitle: string;
  introductionTemplate: string;
  systemPrompt: string;
  events: ClientEvents;
  theme: UITheme;
  widgetText: WidgetText;
  termsAndConditions: TermsConfig;

  constructor(
    agentName: string = 'Alex',
    companyName: string = 'ITABS',
    jobTitle: string = 'Software Engineer',
    events: ClientEvents = defaultClientEvents,
    theme: UITheme = defaultUITheme,
    widgetText: WidgetText = defaultWidgetText,
    termsAndConditions: TermsConfig = defaultTermsConfig
  ) {
    this.agentName = agentName;
    this.companyName = companyName;
    this.jobTitle = jobTitle;
    this.events = events;
    this.theme = theme;
    this.widgetText = widgetText;
    this.termsAndConditions = termsAndConditions;
    
    this.introductionTemplate = "Hi there! I'm {AGENT_NAME} from {COMPANY_NAME}. I'll be conducting your interview today for the {JOB_TITLE} position. Let's begin!";
    this.systemPrompt = this.generateSystemPrompt();
  }

  generateIntroduction(): string {
    return this.introductionTemplate
      .replace('{AGENT_NAME}', this.agentName)
      .replace('{COMPANY_NAME}', this.companyName)
      .replace('{JOB_TITLE}', this.jobTitle);
  }

  generateSystemPrompt(): string {
    return `## 🧠 System Prompt: Interviewer AI Agent (for ${this.companyName})

You are **${this.agentName}**, a personable, intelligent, and emotionally-aware **interviewer agent** powered by advanced Conversational AI from **${this.companyName}**.

Your role is to **simulate a human-like job interviewer**, guiding candidates through realistic interview sessions—evaluating both **technical competence** and **soft skills** such as clarity, confidence, adaptability, and reasoning.

### Core Responsibilities:
- Conduct professional, structured interviews with natural conversation flow
- Assess technical skills relevant to the ${this.jobTitle} position
- Evaluate soft skills including communication, problem-solving, and cultural fit
- Provide real-time dynamic scoring based on candidate responses and behavior
- Maintain professional standards and detect inappropriate conduct
- Adapt questioning style based on candidate experience level and responses

### Interview Guidelines:
- Begin with warm, professional greeting: "Hi there! I'm ${this.agentName} from ${this.companyName}."
- Ask follow-up questions to dive deeper into candidate responses
- Maintain conversational tone while staying focused on evaluation criteria
- Conclude interviews naturally when sufficient information is gathered
- Provide constructive feedback and next steps

### Evaluation Criteria:
- Technical Skills: Domain knowledge, problem-solving ability, technical depth
- Communication: Clarity, articulation, professional language use
- Confidence: Self-assurance, decisiveness, composure under pressure
- Adaptability: Flexibility, learning mindset, handling of unexpected questions
- Cultural Fit: Alignment with company values, teamwork, collaboration
- Professionalism: Appropriate conduct, respect, interview etiquette

### Response Style:
- Use natural, conversational language
- Ask one question at a time
- Provide encouraging feedback when appropriate
- Maintain professional boundaries
- Show genuine interest in candidate responses
- Use follow-up questions to explore depth of knowledge

Remember: You are representing ${this.companyName} and should embody the company's values of professionalism, innovation, and excellence in all interactions.`;
  }
}

// Configuration Builder Pattern
class InterviewConfigBuilder {
  private config: InterviewConfigImpl;

  constructor() {
    this.config = new InterviewConfigImpl();
  }

  setAgent(name: string): InterviewConfigBuilder {
    this.config.agentName = name;
    this.config.systemPrompt = this.config.generateSystemPrompt();
    return this;
  }

  setCompany(name: string): InterviewConfigBuilder {
    this.config.companyName = name;
    this.config.systemPrompt = this.config.generateSystemPrompt();
    return this;
  }

  setJobTitle(title: string): InterviewConfigBuilder {
    this.config.jobTitle = title;
    this.config.systemPrompt = this.config.generateSystemPrompt();
    return this;
  }

  setEvents(events: Partial<ClientEvents>): InterviewConfigBuilder {
    this.config.events = { ...this.config.events, ...events };
    return this;
  }

  setTheme(theme: Partial<UITheme>): InterviewConfigBuilder {
    this.config.theme = { ...this.config.theme, ...theme };
    return this;
  }

  setWidgetText(widgetText: Partial<WidgetText>): InterviewConfigBuilder {
    this.config.widgetText = { ...this.config.widgetText, ...widgetText };
    return this;
  }

  setTermsAndConditions(terms: Partial<TermsConfig>): InterviewConfigBuilder {
    this.config.termsAndConditions = { ...this.config.termsAndConditions, ...terms };
    return this;
  }

  build(): InterviewConfig {
    return this.config;
  }
}

// Theme application utility
export function applyThemeToDocument(theme: UITheme): void {
  const root = document.documentElement;
  
  // Apply color variables
  Object.entries(theme.colors).forEach(([key, value]) => {
    const cssVar = `--color-${key.replace(/([A-Z])/g, '-$1').toLowerCase()}`;
    root.style.setProperty(cssVar, value);
  });
  
  // Apply typography variables
  Object.entries(theme.typography).forEach(([key, value]) => {
    const cssVar = `--font-size-${key.replace(/([A-Z])/g, '-$1').toLowerCase()}`;
    root.style.setProperty(cssVar, value);
  });
}

// Default configuration instance
export const defaultInterviewConfig = new InterviewConfigBuilder().build();

// Exports
export type { InterviewConfig, UITheme, WidgetText, TermsConfig };
export { InterviewConfigBuilder, InterviewConfigImpl };
export { defaultUITheme, defaultWidgetText, defaultTermsConfig, defaultClientEvents };
