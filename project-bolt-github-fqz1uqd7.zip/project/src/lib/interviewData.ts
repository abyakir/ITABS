import { delayPromise } from './utils';

/**
 * Industry preset job roles for interview customization
 */
export const industryPresets = {
  technology: [
    'Software Engineer',
    'Frontend Developer',
    'Backend Developer',
    'Full Stack Developer', 
    'DevOps Engineer',
    'Data Scientist',
    'UX/UI Designer',
    'Product Manager',
    'QA Engineer',
    'Security Engineer'
  ],
  finance: [
    'Financial Analyst',
    'Investment Banker',
    'Financial Advisor',
    'Risk Analyst',
    'Compliance Officer',
    'Accountant',
    'Controller',
    'Treasurer',
    'Credit Analyst',
    'Actuary'
  ],
  healthcare: [
    'Nurse',
    'Medical Doctor',
    'Physical Therapist',
    'Healthcare Administrator',
    'Clinical Research Associate',
    'Medical Technologist',
    'Pharmacist',
    'Health Information Manager',
    'Occupational Therapist',
    'Physician Assistant'
  ],
  marketing: [
    'Marketing Manager',
    'Digital Marketing Specialist',
    'Brand Manager',
    'Content Strategist',
    'SEO Specialist',
    'Social Media Manager',
    'Marketing Analyst',
    'Public Relations Specialist',
    'Email Marketing Specialist',
    'Growth Marketer'
  ],
  sales: [
    'Sales Representative',
    'Account Executive',
    'Sales Manager',
    'Business Development Representative',
    'Customer Success Manager',
    'Sales Engineer',
    'Territory Manager',
    'Inside Sales Representative',
    'Sales Operations Manager',
    'Channel Sales Manager'
  ]
};

/**
 * Companies by industry for simulating realistic interview scenarios
 */
export const companiesByIndustry = {
  technology: [
    'Google', 'Microsoft', 'Apple', 'Amazon', 'Meta', 
    'Salesforce', 'Adobe', 'Oracle', 'IBM', 'Intel',
    'Netflix', 'Spotify', 'Twitter', 'Dropbox', 'Slack'
  ],
  finance: [
    'JPMorgan Chase', 'Goldman Sachs', 'Bank of America', 'Morgan Stanley', 'Wells Fargo',
    'Citigroup', 'BlackRock', 'Visa', 'Mastercard', 'American Express'
  ],
  healthcare: [
    'Johnson & Johnson', 'UnitedHealth Group', 'CVS Health', 'Pfizer', 'Merck',
    'Anthem', 'Cigna', 'HCA Healthcare', 'Medtronic', 'Abbott Laboratories'
  ],
  marketing: [
    'Ogilvy', 'McCann', 'Wieden+Kennedy', 'BBDO', 'Leo Burnett',
    'Edelman', 'Weber Shandwick', 'Publicis', 'Omnicom Group', 'WPP'
  ],
  sales: [
    'Salesforce', 'Oracle', 'SAP', 'HubSpot', 'Zendesk',
    'Adobe', 'IBM', 'Microsoft', 'Cisco', 'Dell Technologies'
  ]
};

/**
 * Predefined interview questions by type
 */
export const questionsByType = {
  behavioral: [
    "Tell me about a time when you faced a difficult challenge at work. How did you overcome it?",
    "Describe a situation where you had to work with a difficult team member. How did you handle it?",
    "Give me an example of a time you showed leadership skills.",
    "Tell me about a time when you failed. What did you learn from it?",
    "Describe a situation where you had to work under pressure or tight deadlines.",
    "Tell me about a time when you had to adapt to a significant change at work.",
    "Give me an example of a time you resolved a conflict in your team.",
    "Describe a situation where you went above and beyond your job responsibilities.",
    "Tell me about a time when you had to make an important decision with limited information.",
    "Give me an example of how you've contributed to improving a process or procedure."
  ],
  technical: [
    "What programming languages or technical skills are you proficient in and how have you applied them?",
    "Describe a complex technical problem you've solved recently. What was your approach?",
    "How do you stay updated with the latest technologies and developments in your field?",
    "Explain a technical concept related to your field to someone without technical background.",
    "What's your approach to debugging or troubleshooting technical issues?",
    "Describe a project where you had to learn a new technology quickly. How did you approach it?",
    "How do you ensure code quality and maintainability in your projects?",
    "What tools or methodologies do you use for version control and collaboration?",
    "Explain your experience with cloud services or distributed systems.",
    "How would you optimize a system or application that's running slowly?"
  ],
  situational: [
    "How would you handle a situation where your project deadline is moved up unexpectedly?",
    "If you noticed a colleague making a significant mistake, how would you address it?",
    "How would you prioritize multiple projects with competing deadlines?",
    "If you disagreed with your manager's decision, how would you approach the situation?",
    "How would you handle receiving critical feedback from a supervisor or colleague?",
    "If you were assigned a project in an area you're not familiar with, how would you proceed?",
    "How would you react if a team member wasn't contributing their fair share to a project?",
    "What would you do if you realized you couldn't meet a commitment you made?",
    "How would you handle a situation where you identified a more efficient way to complete a task?",
    "If a client or stakeholder was unhappy with your work, how would you address their concerns?"
  ],
  leadership: [
    "How do you motivate team members to achieve goals?",
    "Describe your leadership style and how you adapt it to different situations.",
    "Tell me about a time when you had to lead a team through a difficult situation.",
    "How do you delegate tasks and responsibilities effectively?",
    "How do you handle conflicts between team members?",
    "Describe how you've mentored or developed others in your team.",
    "How do you communicate vision and strategy to your team?",
    "What's your approach to giving feedback to team members?",
    "How do you ensure your team meets deadlines and delivers quality work?",
    "Tell me about a time when you had to make an unpopular decision as a leader."
  ],
  problem_solving: [
    "Describe your approach to problem-solving in a professional setting.",
    "Tell me about a complex problem you solved through innovative thinking.",
    "How do you gather and analyze information when tackling a problem?",
    "Describe a situation where you had to think outside the box to reach a solution.",
    "How do you approach problems that don't have clear solutions?",
    "Tell me about a time when your first solution to a problem didn't work. What did you do next?",
    "How do you break down complex problems into manageable components?",
    "Describe how you've used data or metrics to solve a problem.",
    "How do you balance quick decision-making with thorough analysis?",
    "Tell me about a time when you anticipated a problem before it occurred."
  ]
};

/**
 * Generate appropriate follow-up questions based on interview context
 */
export function generateFollowUpQuestions(
  questionType: keyof typeof questionsByType,
  jobTitle: string,
  experienceLevel: string
): string[] {
  // Generic follow-ups that work for most questions
  const genericFollowUps = [
    "Could you provide a specific example of that?",
    "How did that experience change your approach going forward?",
    "What was the most significant challenge you faced in that situation?",
    "What would you do differently if you encountered a similar situation again?",
    "How did you measure the success or impact of your actions?"
  ];
  
  // Role-specific follow-ups
  const roleSpecificFollowUps: Record<string, string[]> = {
    developer: [
      "What technologies or frameworks did you use in that project?",
      "How did you ensure code quality during that process?",
      "Did you encounter any performance issues, and how did you address them?",
      "How did you collaborate with other team members during development?",
      "What was your testing strategy for that feature or project?"
    ],
    designer: [
      "How did you validate your design decisions with users or stakeholders?",
      "What design tools did you use for that project?",
      "How did you ensure your designs were accessible and inclusive?",
      "What was your process for incorporating feedback into your designs?",
      "How did you balance user needs with business requirements?"
    ],
    manager: [
      "How did you communicate expectations to your team members?",
      "What metrics did you use to track progress and success?",
      "How did you handle any resistance or challenges from team members?",
      "What was your approach to delegating tasks in that situation?",
      "How did you ensure accountability while supporting your team?"
    ],
    analyst: [
      "What data sources or tools did you use for that analysis?",
      "How did you ensure the accuracy and reliability of your findings?",
      "How did you communicate complex analytical results to non-technical stakeholders?",
      "What unexpected patterns or insights did you discover?",
      "How did your analysis influence business decisions or strategies?"
    ]
  };

  // Experience-level-specific follow-ups
  const experienceLevelFollowUps: Record<string, string[]> = {
    entry: [
      "How did this experience prepare you for this role?",
      "What resources did you use to learn the skills needed?",
      "Who did you seek guidance from during this process?",
      "What was the most important lesson you learned?",
      "How do you plan to build on this experience in your career?"
    ],
    mid: [
      "How did you apply your previous experience to this situation?",
      "What leadership or mentoring opportunities arose from this experience?",
      "How did you balance multiple responsibilities during this time?",
      "What technical or professional skills did you develop through this?",
      "How did this experience contribute to your career progression?"
    ],
    senior: [
      "How did this experience influence your leadership approach?",
      "What strategic decisions did you make in this situation?",
      "How did you ensure knowledge transfer to more junior team members?",
      "What organizational impact resulted from your actions?",
      "How did you align this work with broader business objectives?"
    ]
  };
  
  // Type-specific follow-ups
  const typeSpecificFollowUps: Record<string, string[]> = {
    behavioral: [
      "How did that experience affect your professional development?",
      "What feedback did you receive from others involved in the situation?",
      "How did this situation align with your professional values?",
      "What support did you seek or receive during this challenge?",
      "How has this experience influenced your approach to similar situations since then?"
    ],
    technical: [
      "Can you elaborate on the technical details of your solution?",
      "What alternative approaches did you consider?",
      "How did you validate that your solution was effective?",
      "What technical constraints did you have to work within?",
      "How would you approach this differently with today's technologies?"
    ],
    situational: [
      "What principles guide your decision-making in these scenarios?",
      "How would your approach change if you had more/fewer resources?",
      "What potential risks would you need to mitigate in this situation?",
      "How would you communicate your plan to stakeholders?",
      "What would be your contingency plan if your initial approach failed?"
    ],
    leadership: [
      "How do you measure success as a leader in that context?",
      "How did you ensure your team remained motivated during challenges?",
      "What feedback mechanisms did you implement?",
      "How did you address performance issues within the team?",
      "How did you balance operational needs with strategic objectives?"
    ],
    problem_solving: [
      "What frameworks or methodologies guided your problem-solving approach?",
      "How did you evaluate the effectiveness of your solution?",
      "What constraints or limitations did you have to work within?",
      "How did you involve others in the problem-solving process?",
      "What was the most critical insight that led to your solution?"
    ]
  };
  
  // Determine which role-specific follow-ups to use based on job title
  let roleFollowUps = roleSpecificFollowUps.developer; // Default
  if (jobTitle.toLowerCase().includes('design')) {
    roleFollowUps = roleSpecificFollowUps.designer;
  } else if (jobTitle.toLowerCase().includes('manage') || jobTitle.toLowerCase().includes('lead')) {
    roleFollowUps = roleSpecificFollowUps.manager;
  } else if (jobTitle.toLowerCase().includes('analyst') || jobTitle.toLowerCase().includes('data')) {
    roleFollowUps = roleSpecificFollowUps.analyst;
  }
  
  // Combine follow-ups with appropriate weighting
  const followUps = [
    ...genericFollowUps,
    ...roleFollowUps,
    ...experienceLevelFollowUps[experienceLevel] || experienceLevelFollowUps.mid,
    ...typeSpecificFollowUps[questionType] || typeSpecificFollowUps.behavioral
  ];
  
  // Shuffle and pick 3 follow-up questions
  return shuffleArray(followUps).slice(0, 3);
}

/**
 * Generate customized interview questions based on job role and experience
 */
export async function generateInterviewQuestions(
  jobTitle: string, 
  company: string, 
  experienceLevel: 'entry' | 'mid' | 'senior',
  interviewType: string[] = ['behavioral', 'technical'],
  difficulty: 'easy' | 'medium' | 'hard' = 'medium',
  customQuestions: string[] = []
): Promise<any[]> {
  // Generate a random delay to simulate API call
  await delayPromise(800);
  
  // Introduction question (always first)
  const intro = {
    id: 'intro-1',
    type: 'introduction',
    text: `Hello! I'm Alex from ${company}. I'll be conducting your interview for the ${jobTitle} position today. To get started, could you tell me a bit about yourself and your background?`
  };
  
  // Select questions from each selected type based on difficulty
  const selectedQuestions = [];
  const numQuestionsPerType = difficulty === 'easy' ? 2 : difficulty === 'medium' ? 3 : 4;
  
  for (const type of interviewType) {
    if (questionsByType[type as keyof typeof questionsByType]) {
      const typeQuestions = questionsByType[type as keyof typeof questionsByType];
      const shuffled = shuffleArray([...typeQuestions]);
      const selected = shuffled.slice(0, numQuestionsPerType).map((text, index) => ({
        id: `${type}-${index + 1}`,
        type,
        text,
        followUps: generateFollowUpQuestions(type as keyof typeof questionsByType, jobTitle, experienceLevel)
      }));
      selectedQuestions.push(...selected);
    }
  }
  
  // Add custom questions if provided
  const customQuestionsFormatted = customQuestions.map((text, index) => ({
    id: `custom-${index + 1}`,
    type: 'custom',
    text,
    followUps: []
  }));
  
  // Closing questions (always last)
  const closing = [
    {
      id: 'closing-1',
      type: 'closing',
      text: `I've asked you a number of questions today about your experience and skills. Do you have any questions for me about the ${jobTitle} role or about working at ${company}?`
    },
    {
      id: 'closing-2',
      type: 'closing',
      text: `Thank you for your time today. It was great learning more about your background and experience. We'll be in touch soon with next steps.`
    }
  ];
  
  // Combine all questions
  const allQuestions = [
    intro,
    ...shuffleArray(selectedQuestions),
    ...customQuestionsFormatted,
    ...closing
  ];
  
  return allQuestions;
}

/**
 * Shuffle array elements (Fisher-Yates algorithm)
 */
function shuffleArray<T>(array: T[]): T[] {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
}