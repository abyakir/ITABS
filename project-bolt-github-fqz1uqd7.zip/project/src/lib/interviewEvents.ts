// Client Events Configuration
interface ClientEvents {
  audio: boolean;                    // Enable/disable text-to-speech responses
  interruption: boolean;             // Enable/disable user interruption handling
  user_transcript: boolean;          // Real-time transcription of candidate speech
  vad_score: boolean;                // Voice Activity Detection scoring
  agent_response: boolean;           // AI interviewer's generated responses
  agent_response_correction: boolean; // Real-time response corrections
  text_input: boolean;               // Manual text input capability
  conversation_transcript: boolean;  // Complete interview transcript
}

// Event Types
type InterviewEventType = 
  | AudioEvent
  | InterruptionEvent
  | UserTranscriptEvent
  | VADScoreEvent
  | AgentResponseEvent
  | AgentResponseCorrectionEvent
  | TextInputEvent
  | ConversationTranscriptEvent;

interface BaseEvent {
  type: string;
  timestamp: number;
  sessionId: string;
}

interface AudioEvent extends BaseEvent {
  type: 'audio';
  data: {
    enabled: boolean;
    volume?: number;
    quality?: string;
  };
}

interface InterruptionEvent extends BaseEvent {
  type: 'interruption';
  data: {
    interrupted: boolean;
    interruptionTime?: number;
  };
}

interface UserTranscriptEvent extends BaseEvent {
  type: 'user_transcript';
  data: {
    transcript: string;
    isFinal: boolean;
    confidence: number;
    duration: number;
  };
}

interface VADScoreEvent extends BaseEvent {
  type: 'vad_score';
  data: {
    score: number;
    isActive: boolean;
    threshold: number;
  };
}

interface AgentResponseEvent extends BaseEvent {
  type: 'agent_response';
  data: {
    response: string;
    questionNumber: number;
    phase: string;
    responseTime: number;
  };
}

interface AgentResponseCorrectionEvent extends BaseEvent {
  type: 'agent_response_correction';
  data: {
    originalResponse: string;
    correctedResponse: string;
    correctionReason: string;
  };
}

interface TextInputEvent extends BaseEvent {
  type: 'text_input';
  data: {
    text: string;
    source: 'manual' | 'voice';
  };
}

interface ConversationTranscriptEvent extends BaseEvent {
  type: 'conversation_transcript';
  data: {
    transcript: Array<{
      speaker: 'interviewer' | 'candidate';
      text: string;
      timestamp: number;
    }>;
    totalDuration: number;
  };
}

// Event Manager Class
class InterviewEventManager {
  private events: ClientEvents;
  private sessionId: string;
  private listeners: Map<string, Array<(event: InterviewEventType) => void>> = new Map();

  constructor(events: ClientEvents, sessionId: string) {
    this.events = events;
    this.sessionId = sessionId;
  }

  // Subscribe to specific event types
  subscribe(eventType: string, callback: (event: InterviewEventType) => void): () => void {
    if (!this.listeners.has(eventType)) {
      this.listeners.set(eventType, []);
    }
    
    this.listeners.get(eventType)!.push(callback);
    
    // Return unsubscribe function
    return () => {
      const callbacks = this.listeners.get(eventType);
      if (callbacks) {
        const index = callbacks.indexOf(callback);
        if (index > -1) {
          callbacks.splice(index, 1);
        }
      }
    };
  }

  // Emit events with automatic filtering based on configuration
  emit(event: Omit<InterviewEventType, 'timestamp' | 'sessionId'>): void {
    // Check if this event type is enabled
    const eventKey = event.type as keyof ClientEvents;
    if (this.events[eventKey] === false) {
      console.log(`Event ${event.type} is disabled, skipping emission`);
      return;
    }

    const fullEvent: InterviewEventType = {
      ...event,
      timestamp: Date.now(),
      sessionId: this.sessionId
    } as InterviewEventType;

    console.log(`Emitting event: ${event.type}`, fullEvent);

    // Notify all listeners for this event type
    const callbacks = this.listeners.get(event.type);
    if (callbacks) {
      callbacks.forEach(callback => {
        try {
          callback(fullEvent);
        } catch (error) {
          console.error(`Error in event listener for ${event.type}:`, error);
        }
      });
    }

    // Also notify listeners subscribed to 'all' events
    const allCallbacks = this.listeners.get('all');
    if (allCallbacks) {
      allCallbacks.forEach(callback => {
        try {
          callback(fullEvent);
        } catch (error) {
          console.error(`Error in 'all' event listener:`, error);
        }
      });
    }
  }

  // Helper methods for common events
  emitAudioState(enabled: boolean, volume?: number, quality?: string): void {
    this.emit({
      type: 'audio',
      data: { enabled, volume, quality }
    });
  }

  emitInterruption(interrupted: boolean, interruptionTime?: number): void {
    this.emit({
      type: 'interruption',
      data: { interrupted, interruptionTime }
    });
  }

  emitUserTranscript(transcript: string, isFinal: boolean, confidence: number, duration: number): void {
    this.emit({
      type: 'user_transcript',
      data: { transcript, isFinal, confidence, duration }
    });
  }

  emitVADScore(score: number, threshold: number = 0.5): void {
    this.emit({
      type: 'vad_score',
      data: { score, isActive: score > threshold, threshold }
    });
  }

  emitAgentResponse(response: string, questionNumber: number, phase: string, responseTime: number): void {
    this.emit({
      type: 'agent_response',
      data: { response, questionNumber, phase, responseTime }
    });
  }

  emitAgentResponseCorrection(originalResponse: string, correctedResponse: string, correctionReason: string): void {
    this.emit({
      type: 'agent_response_correction',
      data: { originalResponse, correctedResponse, correctionReason }
    });
  }

  emitTextInput(text: string, source: 'manual' | 'voice' = 'manual'): void {
    this.emit({
      type: 'text_input',
      data: { text, source }
    });
  }

  emitConversationTranscript(transcript: Array<{speaker: 'interviewer' | 'candidate'; text: string; timestamp: number}>, totalDuration: number): void {
    this.emit({
      type: 'conversation_transcript',
      data: { transcript, totalDuration }
    });
  }

  // Get current configuration
  getConfiguration(): ClientEvents {
    return { ...this.events };
  }

  // Update configuration
  updateConfiguration(newEvents: Partial<ClientEvents>): void {
    this.events = { ...this.events, ...newEvents };
    console.log('Event configuration updated:', this.events);
  }
}

// Global event manager instance
let globalEventManager: InterviewEventManager | null = null;

// Factory function to create event manager
export function createEventManager(events: ClientEvents, sessionId: string): InterviewEventManager {
  globalEventManager = new InterviewEventManager(events, sessionId);
  return globalEventManager;
}

// Get current event manager
export function getEventManager(): InterviewEventManager | null {
  return globalEventManager;
}

// Default client events configuration
export const defaultClientEvents: ClientEvents = {
  audio: true,
  interruption: true,
  user_transcript: true,
  vad_score: true,
  agent_response: true,
  agent_response_correction: true,
  text_input: true,
  conversation_transcript: true
};

// Export types
export type {
  ClientEvents,
  InterviewEventType,
  AudioEvent,
  InterruptionEvent,
  UserTranscriptEvent,
  VADScoreEvent,
  AgentResponseEvent,
  AgentResponseCorrectionEvent,
  TextInputEvent,
  ConversationTranscriptEvent
};

export { InterviewEventManager };
