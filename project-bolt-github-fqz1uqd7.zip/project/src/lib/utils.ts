import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

/**
 * Utility for combining class names with Tailwind CSS
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Validates if a string is a valid UUID
 * Used for database ID validation
 */
export function isValidUUID(uuid: string): boolean {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  return uuidRegex.test(uuid);
}

/**
 * Store interview data in localStorage to persist between navigation
 */
export function storeInterviewData(data: any): void {
  try {
    localStorage.setItem('interview_setup_data', JSON.stringify(data));
  } catch (error) {
    console.error('Failed to store interview data:', error);
  }
}

/**
 * Retrieve interview data from localStorage
 */
export function getInterviewData(): any {
  try {
    const data = localStorage.getItem('interview_setup_data');
    return data ? JSON.parse(data) : null;
  } catch (error) {
    console.error('Failed to retrieve interview data:', error);
    return null;
  }
}

/**
 * Clear interview data from localStorage
 */
export function clearInterviewData(): void {
  try {
    localStorage.removeItem('interview_setup_data');
  } catch (error) {
    console.error('Failed to clear interview data:', error);
  }
}

/**
 * Safely validates and sanitizes image URLs to prevent XSS
 */
export function sanitizeImageUrl(url: string | undefined): string | undefined {
  if (!url || typeof url !== 'string') return undefined;

  // Check for common XSS patterns
  const xssPatterns = [
    /javascript:/i,
    /data:/i,
    /vbscript:/i,
    /on\w+=/i,
    /<script/i
  ];

  if (xssPatterns.some(pattern => pattern.test(url))) {
    return undefined;
  }

  try {
    const urlObj = new URL(url);
    // Only allow http/https protocols
    if (!['https:', 'http:'].includes(urlObj.protocol)) {
      return undefined;
    }

    // Reconstruct URL to ensure it's clean
    return `${urlObj.protocol}//${urlObj.host}${urlObj.pathname}${urlObj.search}`;
  } catch {
    return undefined;
  }
}

/**
 * Format seconds into MM:SS format
 */
export function formatSeconds(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
}

/**
 * Format duration in minutes to a human-readable string
 */
export function formatDuration(minutes: number): string {
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return `${hours}h ${mins}m`;
}

/**
 * Format date to a human-readable string
 */
export function formatDate(dateString: string, format: 'short' | 'long' = 'short'): string {
  const date = new Date(dateString);
  
  if (format === 'short') {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric'
    }).format(date);
  }
  
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  }).format(date);
}

/**
 * Generates a greeting message based on job details
 */
export function generateInterviewGreeting(jobTitle: string, company: string, experienceLevel: string = 'mid'): string {
  const greetings = [
    `Hello! I'm your AI interviewer for the ${jobTitle} position at ${company}. Thank you for joining me today.`,
    `Welcome to your interview for the ${jobTitle} role at ${company}. I'll be conducting your interview today.`,
    `Hi there! I'm excited to interview you for the ${jobTitle} position at ${company} today.`
  ];
  
  const experiencePhrases = {
    'entry': 'Since this is an entry-level position, I\'ll focus on your foundational skills and potential.',
    'mid': 'For this mid-level role, I\'ll be exploring both your technical knowledge and previous experience.',
    'senior': 'As this is a senior position, I\'ll be asking about your leadership experience and advanced technical expertise.'
  };
  
  // Select a random greeting
  const greeting = greetings[Math.floor(Math.random() * greetings.length)];
  const experiencePhrase = experiencePhrases[experienceLevel as keyof typeof experiencePhrases] || experiencePhrases.mid;
  
  return `${greeting} ${experiencePhrase} Let's start with you telling me a little bit about yourself.`;
}
/**
 * Creates a promise that resolves after the specified delay
 */
export function delayPromise(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Error utility to show developer-friendly error messages
 */
export function formatDevError(error: any): string {
  if (!error) return 'Unknown error';
  
  // If it's a string, return it directly
  if (typeof error === 'string') return error;
  
  // If it has a message property, use that
  if (error.message) return error.message;
  
  // If it has code and details, format them together
  if (error.code && error.details) {
    return `Error ${error.code}: ${error.details}`;
  }
  
  // Last resort, stringify the error
  try {
    return JSON.stringify(error);
  } catch (e) {
    return 'Unformattable error object';
  }
}