// Mock authentication service for development when Supabase is not configured
export interface MockAuthResponse {
  data: {
    user?: {
      id: string;
      email: string;
      created_at: string;
    };
    session?: any;
  } | null;
  error?: {
    message: string;
  } | null;
}

// Check if we should use mock authentication
export const shouldUseMockAuth = (): boolean => {
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
  
  // Use mock auth if:
  // 1. No environment variables are set
  // 2. Environment variables contain placeholder values
  // 3. URLs point to placeholder domains
  if (!supabaseUrl || !supabaseKey) {
    return true;
  }
  
  const placeholderPatterns = [
    'placeholder',
    'your-project',
    'your-anon-key',
    'example.com',
    'localhost'
  ];
  
  return placeholderPatterns.some(pattern => 
    supabaseUrl.includes(pattern) || supabaseKey.includes(pattern)
  );
};

class MockAuthService {
  private mockUsers: Array<{
    id: string;
    email: string;
    password: string;
    created_at: string;
  }> = [];
  
  constructor() {
    // Initialize with default demo user
    this.mockUsers.push({
      id: 'mock-user-1',
      email: 'demo@example.com',
      password: 'password123',
      created_at: new Date().toISOString()
    });
    
    // Load any saved users from localStorage
    try {
      const savedUsers = localStorage.getItem('mock-auth-users');
      if (savedUsers) {
        const parsedUsers = JSON.parse(savedUsers);
        if (Array.isArray(parsedUsers)) {
          // Merge with existing users, avoiding duplicates
          parsedUsers.forEach(user => {
            if (!this.mockUsers.some(u => u.email === user.email)) {
              this.mockUsers.push(user);
            }
          });
        }
      }
    } catch (e) {
      console.warn('Failed to load mock users from localStorage:', e);
    }
    
    console.log('🔧 Mock auth initialized with users:', this.mockUsers.map(u => u.email));
  }
  
  // Save users to localStorage
  private saveUsers() {
    try {
      localStorage.setItem('mock-auth-users', JSON.stringify(this.mockUsers));
    } catch (e) {
      console.warn('Failed to save mock users to localStorage:', e);
    }
  }

  async signUp(email: string, password: string): Promise<MockAuthResponse> {
    console.log('🔧 Mock signup for:', email);
    
    // Check if user already exists
    const existingUser = this.mockUsers.find(u => u.email === email);
    if (existingUser) {
      return {
        data: null,
        error: { message: 'User already registered' }
      };
    }
    
    // Create new mock user
    const newUser = {
      id: `mock-user-${Date.now()}`,
      email,
      password,
      created_at: new Date().toISOString()
    };
    
    this.mockUsers.push(newUser);
    this.saveUsers(); // Persist to localStorage
    
    return {
      data: {
        user: {
          id: newUser.id,
          email: newUser.email,
          created_at: newUser.created_at
        }
      },
      error: null
    };
  }

  async signIn(email: string, password: string): Promise<MockAuthResponse> {
    console.log('🔧 Mock signin for:', email);
    
    // Special handling for demo credentials
    if (email === 'demo@example.com' && password === 'password123') {
      // Ensure the demo user exists (might have been cleared)
      const existingUser = this.mockUsers.find(u => u.email === 'demo@example.com');
      if (!existingUser) {
        const newDemoUser = {
          id: 'mock-user-demo',
          email: 'demo@example.com',
          password: 'password123',
          created_at: new Date().toISOString()
        };
        this.mockUsers.push(newDemoUser);
        this.saveUsers();
        
        // Store current user in localStorage for persistence
        localStorage.setItem('mock-auth-user', JSON.stringify({
          id: newDemoUser.id,
          email: newDemoUser.email,
          created_at: newDemoUser.created_at
        }));
        
        return {
          data: {
            user: {
              id: newDemoUser.id,
              email: newDemoUser.email,
              created_at: newDemoUser.created_at
            }
          },
          error: null
        };
      }
    }
    
    // Try exact match first
    let user = this.mockUsers.find(u => u.email === email && u.password === password);
    
    // If no match and we're in development mode, be more lenient with demo accounts
    if (!user && (email.includes('demo') || email.includes('test') || password === 'password123')) {
      console.log('🔧 No exact match found, using lenient matching for demo credentials');
      // Create a temporary user for demo purposes
      const tempUser = {
        id: `mock-user-${Date.now()}`,
        email,
        password,
        created_at: new Date().toISOString()
      };
      
      this.mockUsers.push(tempUser);
      this.saveUsers();
      user = tempUser;
    }
    
    if (!user) {
      return {
        data: null,
        error: { message: 'Invalid login credentials' }
      };
    }
    
    // Store current user in localStorage for persistence across page refreshes
    localStorage.setItem('mock-auth-user', JSON.stringify({ id: user.id, email: user.email, created_at: user.created_at }));
    return {
      data: {
        user: {
          id: user.id,
          email: user.email,
          created_at: user.created_at
        }
      },
      error: null
    };
  }

  async signOut(): Promise<MockAuthResponse> {
    console.log('🔧 Mock signout');
    return {
      data: null,
      error: null
    };
  }

  async getCurrentUser(): Promise<MockAuthResponse> {
    const userStr = localStorage.getItem('mock-auth-user');
    if (!userStr) {
      return {
        data: { user: null },
        error: null
      };
    }
    
    try {
      const user = JSON.parse(userStr);
      return {
        data: { user },
        error: null
      };
    } catch {
      return {
        data: { user: null },
        error: null
      };
    }
  }

  onAuthStateChange(callback: (event: string, session: any) => void) {
    // Simple mock implementation
    return {
      data: {
        subscription: {
          unsubscribe: () => console.log('🔧 Mock auth state change unsubscribed')
        }
      }
    };
  }

  async updatePassword(password: string): Promise<MockAuthResponse> {
    console.log('🔧 Mock password update');
    return {
      data: { user: null },
      error: null
    };
  }

  async updateEmail(email: string): Promise<MockAuthResponse> {
    console.log('🔧 Mock email update');
    return {
      data: { user: null },
      error: null
    };
  }
}

export const mockAuth = new MockAuthService();