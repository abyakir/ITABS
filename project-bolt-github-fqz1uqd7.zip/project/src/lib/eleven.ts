import { getEventManager } from './interviewEvents';

const ELEVEN_API_KEY = import.meta.env.VITE_ELEVEN_API_KEY;
const ELEVEN_VOICE_ID = import.meta.env.VITE_ELEVEN_VOICE_ID || '21m00Tcm4TlvDq8ikWAM';

interface VoiceSettings {
  stability: number;
  similarity_boost: number;
  style?: number;
  use_speaker_boost?: boolean;
}

class ElevenLabsService {
  private currentAudio: HTMLAudioElement | null = null;

  async speak(text: string, settings: VoiceSettings = {
    stability: 0.7,
    similarity_boost: 0.8,
    style: 0.0,
    use_speaker_boost: true
  }): Promise<void> {
    // Check if audio events are enabled
    const eventManager = getEventManager();
    const audioEnabled = eventManager?.getConfiguration().audio !== false;

    if (!audioEnabled) {
      console.log('Audio events disabled, skipping speech synthesis');
      return Promise.resolve();
    }

    if (!ELEVEN_API_KEY) {
      console.warn('ElevenLabs API key not configured, skipping speech synthesis');
      return Promise.resolve();
    }

    // Stop any currently playing audio
    this.stop();

    // Emit audio start event
    if (eventManager) {
      eventManager.emitAudioState(true, 1.0, 'high');
    }

    try {
      const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${ELEVEN_VOICE_ID}`, {
        method: 'POST',
        headers: {
          'Accept': 'audio/mpeg',
          'Content-Type': 'application/json',
          'xi-api-key': ELEVEN_API_KEY
        },
        body: JSON.stringify({
          text,
          model_id: 'eleven_flash_v2_5',
          voice_settings: settings
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`ElevenLabs API error: ${response.status} - ${errorText}`);
        return Promise.resolve();
      }

      const audioBlob = await response.blob();
      const audioUrl = URL.createObjectURL(audioBlob);
      
      return new Promise((resolve, reject) => {
        this.currentAudio = new Audio(audioUrl);
        
        this.currentAudio.onended = () => {
          URL.revokeObjectURL(audioUrl);
          this.currentAudio = null;

          // Emit audio stop event
          if (eventManager) {
            eventManager.emitAudioState(false, 0, 'stopped');
          }

          resolve();
        };

        this.currentAudio.onerror = () => {
          URL.revokeObjectURL(audioUrl);
          this.currentAudio = null;
          console.warn('Audio playback failed');

          // Emit audio stop event
          if (eventManager) {
            eventManager.emitAudioState(false, 0, 'error');
          }

          resolve();
        };
        
        this.currentAudio.play().catch((error) => {
          console.warn('Audio play failed:', error);
          resolve();
        });
      });
    } catch (error) {
      console.error('ElevenLabs TTS error:', error);
      return Promise.resolve();
    }
  }

  stop(): void {
    if (this.currentAudio) {
      this.currentAudio.pause();
      this.currentAudio.currentTime = 0;
      this.currentAudio = null;

      // Emit audio stop event
      const eventManager = getEventManager();
      if (eventManager) {
        eventManager.emitAudioState(false, 0, 'stopped');
      }
    }
  }

  isPlaying(): boolean {
    return this.currentAudio !== null && !this.currentAudio.paused;
  }
}

export const elevenLabsService = new ElevenLabsService();