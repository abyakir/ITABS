import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  optimizeDeps: {
    exclude: ['lucide-react'],
    include: ['react', 'react-dom']
  },
  server: {
    port: 5173,
    host: true,
    hmr: {
      overlay: true,
      clientPort: 5173
    },
    watch: {
      usePolling: true
    }
  },
  define: {
    // Fix for __WS_TOKEN__ undefined error in HMR
    __WS_TOKEN__: JSON.stringify('dev-token'),
    // Ensure global is defined for browser compatibility
    global: 'globalThis',
    // Define process.env for compatibility
    'process.env': {}
  },
  build: {
    rollupOptions: {
      external: (id) => {
        // Exclude problematic fingerprint icon that gets blocked by ad blockers
        return id.includes('fingerprint.js');
      }
    },
    sourcemap: true
  },
  esbuild: {
    // Ensure proper handling of JSX and modern JS features
    target: 'es2020'
  }
});